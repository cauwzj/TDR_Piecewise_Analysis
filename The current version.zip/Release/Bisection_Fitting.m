function varargout = Bisection_Fitting(varargin)
% BISECTION_FITTING MATLAB code for Bisection_Fitting.fig
%      BISECTION_FITTING, by itself, creates a new BISECTION_FITTING or raises the existing
%      singleton*.
%
%      H = BISECTION_FITTING returns the handle to a new BISECTION_FITTING or the handle to
%      the existing singleton*.
%
%      BISECTION_FITTING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BISECTION_FITTING.M with the given input arguments.
%
%      BISECTION_FITTING('Property','Value',...) creates a new BISECTION_FITTING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Bisection_Fitting_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Bisection_Fitting_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Bisection_Fitting

% Last Modified by GUIDE v2.5 17-Feb-2020 20:09:36

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Bisection_Fitting_OpeningFcn, ...
                   'gui_OutputFcn',  @Bisection_Fitting_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Bisection_Fitting is made visible.
function Bisection_Fitting_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Bisection_Fitting (see VARARGIN)

% Choose default command line output for Bisection_Fitting
handles.output = hObject;

axes(handles.PIC_TDR_PROBE);
hold on
imshow(imread('PIC_TDR_SENSOR.PNG'));
axis off

% Data Handles
handles.FileName=0;
handles.FilePath=0;
handles.Panel_Index=1;
handles.DataLength=0;
handles.DataWidth=0;
handles.ProbeParR=0;
handles.ProbeParL=0;
handles.ProbeParC=0;
handles.ProbeParG=0;

% constant
handles.LightSpeed=299792458;     %m/s
handles.RELATIVEPERMITTIVITY_0=8.854e-12;   %F/m
handles.MagnPerm=0.0000004*pi;  %H/m
handles.TimeInterval=0;

% -----------------------------------------------
% STEP 1

    handles.WaveformData=0;
   
% the cable properties
    handles.CablePropVelo=0.00;
    handles.CableImped=0;
    handles.SelfCable=0;
% the probe properties    
    handles.ProbeLength=150.00;
    handles.PropDist=30.00;
    handles.PropDiam=3.00;
    handles.PROBERSKIN=0.00;
    handles.ProbeResist=0.00;
    handles.ProbeRelaMagnPerm=0.00;
    handles.SelfProbe=0;
% the measurement properties    
    handles.WindLength=2500.00;
    handles.VeloProp=99;   % maximize the resolution
    handles.InputVoltage=0.00;
    handles.InputRiseTime=0.00;
    handles.InputTimeReso=0.00;
    handles.ResisSource=0.00;
    handles.ResisLoad=2000.00;
    handles.SelfSystem=0;
    
% -----------------------------------------------
% STEP 2
    
% plot boolean variable (plot handles)
    handles.Step2PlotWater=0;
    handles.Step2PlotBtc=0;
    handles.Step2PlotWaterSmooth=0;
    handles.Step2PlotBtcSmooth=0;
    handles.Step2PlotWaterBMO=0;
    handles.Step2PlotBtcBMO=0;
    handles.Step2PlotWaterBMOSmooth=0;
    handles.Step2PlotBtcBMOSmooth=0;
    handles.Step2PlotWaterRef1=0;
    handles.Step2PlotBtcRef1=0;
    handles.Step2PlotWaterRef2=0;
    handles.Step2PlotBtcRef2=0;
    handles.STEP3PLOTWATERWAVE=0;
    handles.STEP3PLOTWATERWAVEFIT=0;
    handles.STEP3PLOTBTCWAVE=0;
    handles.STEP3PLOTBTCWAVEFIT=0;
      
% water / btc number
    handles.WaterWaveNum=0;
    handles.BtcWaveNum=0;
% waveform settings
    handles.Setting_WaterBtc=0;   
    handles.Manual_Ref1_Water_Check=0;
    handles.Manual_Ref1_Btc_Check=0;
    handles.Manual_Water_Ref1=20;
    handles.Manual_Btc_Ref1=20;
    handles.Waveform_Water_Smooth_Check=0;
    handles.Waveform_Btc_Smooth_Check=0;
    handles.Smooth_Water_Intensity=0.1;
    handles.Smooth_Btc_Intensity=0.1;
    handles.Sensitivity_Water=0.2;
    handles.Sensitivity_Btc=0.2;
% waveform results
    handles.WaveformBMO_Water=0;
    handles.WaveformBMO_Btc=0;
    handles.WaveformBMO_Water_Smooth=0;
    handles.WaveformBMO_Btc_Smooth=0;
    handles.Waveform_Water_Smooth=0;
    handles.Waveform_Btc_Smooth=0;
% waveform analysis results
	handles.WaveformData_Ref1=0;
    handles.WaveformData_Ref2=0;
    handles.WaveformData_Prem=0;
    handles.WaveformData_EC=0;
    handles.WaveformData_EC_Correction=0;
    handles.WaveformData_Theta=0;
    handles.PropLength_Cali=0;
    handles.PropLength_Cali_Check=0;
    
guidata(hObject, handles);

% set items initial values
% cable part
    set(handles.EDT_SEN_IMPED,'string','0.00');
    set(handles.EDT_SEN_VP,'string','0.00');
% sensor part
    set(handles.EDT_SEN_SEPDIST,'string','30.00');
    set(handles.EDT_SEN_DIAM,'string','3.00');
    set(handles.EDT_SEN_PROBELENGTH,'string','150.00');
    set(handles.EDT_SEN_RESISTIVITY,'string','0.00');
    set(handles.EDT_SEN_MUR,'string','0.00');
% measure part    
    set(handles.EDT_MEASURE_WINDOWLENGTH,'string','2500.00');
    set(handles.EDT_MEASURE_VP,'string','99');
    set(handles.EDT_MEASURE_INPUT_VOLTAGE,'string','0.00');
    set(handles.EDT_MEASURE_INPUT_RISINGTIME,'string','0.00');
    set(handles.EDT_MEASURE_INPUT_TIMERESO,'string','0.00');
    set(handles.EDT_MEASURE_R_SOURCE,'string','0.00');
    set(handles.EDT_MEASURE_R_LOAD,'string','2000.00');
    
guidata(hObject, handles);

% start parallel
AnyPar=gcp('nocreate');
if(isempty(AnyPar))
    ParFit=parpool('local');
    handles.ParFit=ParFit;
else
    delete(gcp('nocreate'));
    ParFit=parpool('local');
    handles.ParFit=ParFit;
end
guidata(hObject, handles);

% UIWAIT makes Bisection_Fitting wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Bisection_Fitting_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in PBT_TAB_NEXT.
function PBT_TAB_NEXT_Callback(hObject, eventdata, handles)
% hObject    handle to PBT_TAB_NEXT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if handles.Panel_Index==1
    set(handles.PAN_SEN,'visible','off');
    set(handles.PAN_WAVE,'visible','on');
    handles.Panel_Index=2;

% ***********************************************************************
% finalize the process for step 1    

% calculate the time interval for each sampling point.
% use the velocity of propagation from the measurement panel, i.e. 99% to
% maximize the resolution.
% unit: sec
    handles.TimeInterval=handles.WindLength/(handles.DataWidth-1)...
        /(handles.LightSpeed)/1000;

% handles.TimeInterval=handles.InputTimeReso
% need to have the initial Rs (source) Rl (load)
% already done in the related editors

% need to calculate the initial L, R,
% initial C and G will be calculated after we first analysis the TDR
% waveforms

% evaluate the skin resistence
% http://chemandy.com/calculators/round-wire-ac-resistance-calculator.htm
    
    pl=handles.ProbeLength*0.001;            % (m)
    rho=handles.ProbeResist;                % Ohm m^-1
    mur=handles.ProbeRelaMagnPerm;          % 
    mu=mur*handles.MagnPerm;
    freq=1/handles.InputRiseTime;           % (Hz)
    diam=handles.PropDiam*0.001;            % (m)
    sepdist=handles.PropDist*0.001;         % (m)

% Skin depth (m)
    delta=sqrt(rho/pi/freq/mu);               

% The effective area (m^2)
    delta_pro=delta*(1-exp(-diam/2/delta));
    Z=0.62006*diam/2/delta;
    Y=0.189774/((1+0.272481*((Z^1.82938)-(Z^(-0.99457)))^2)^1.0941);
    Aeff=pi*(diam*delta_pro-delta_pro^2)*(1+Y);
    rskin=rho*pl/Aeff;
    handles.PROBERSKIN=rskin;

% finish evaluate the skin resistence
% need to check the rskin calculation
% they are just initial values, need to be fitted using the waveforms
    r_pro=(2*rskin/pi/diam)*(sepdist/diam)/sqrt((sepdist/diam)^2-1);
    l_pro=(mu/pi)*acosh(sepdist/diam);
    handles.ProbeParR=r_pro;
    handles.ProbeParL=l_pro;
    guidata(hObject, handles);
% *******************************************************************
% begin the process for Step 2

    set(handles.EDT_WAVEINFO_TOTALNUM,'string',num2str(handles.DataLength));
    set(handles.EDT_WAVEINFO_WATERNUM,'string',num2str(handles.WaterWaveNum));
    set(handles.EDT_WAVEINFO_BTCNUM,'string',num2str(handles.BtcWaveNum));

    guidata(hObject, handles);

elseif handles.Panel_Index==2
    
    set(handles.PAN_IVE,'visible','on');
    set(handles.PAN_WAVE,'visible','off');
    handles.Panel_Index=3;
    
    set(handles.EDT_FITTING_WATER_R_SOURCE,'string',num2str(handles.ResisSource));
    set(handles.EDT_FITTING_WATER_R_LOAD,'string',num2str(handles.ResisLoad));
    set(handles.EDT_FITTING_WATER_RELAPERM,'string',...
        num2str(mean(handles.WaveformData_Prem(1:handles.WaterWaveNum,1))));
    set(handles.EDT_FITTING_WATER_EC,'string',...
        num2str(mean(handles.WaveformData_EC(1:handles.WaterWaveNum,1))));
    set(handles.EDT_FITTING_WATER_PROBELENGTH,'string',num2str(handles.ProbeLength));
    
    handles.FittingBTCIndex=1;
    handles.MaxIterStep=50;
    handles.NODevision=4;
    guidata(hObject, handles);
    set(handles.EDT_FITTING_BTC_INDEX,'string',num2str(handles.FittingBTCIndex));
    set(handles.EDT_FITTING_BTC_MAXITER,'string',num2str(handles.MaxIterStep));
    set(handles.EDT_FITTING_NO_DEVISION,'string',num2str(handles.NODevision));
    
    axes(handles.PIC_TDR_INV)
    set(handles.PIC_TDR_INV,'xTick',[]);
    set(handles.PIC_TDR_INV,'yTick',[]);
    box on

else
end


% --- Executes on button press in PBT_TAB_PREV.
function PBT_TAB_PREV_Callback(hObject, eventdata, handles)
% hObject    handle to PBT_TAB_PREV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.Panel_Index==1
    
elseif handles.Panel_Index==2
    set(handles.PAN_SEN,'visible','on');
    set(handles.PAN_WAVE,'visible','off');
    handles.Panel_Index=1;
elseif handles.Panel_Index==3
    set(handles.PAN_IVE,'visible','off');
    set(handles.PAN_WAVE,'visible','on');
    handles.Panel_Index=2;
else
end
guidata(hObject, handles);


% --- Executes on selection change in POP_SEN_CABLE.
function POP_SEN_CABLE_Callback(hObject, eventdata, handles)
% hObject    handle to POP_SEN_CABLE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns POP_SEN_CABLE contents as cell array
%        contents{get(hObject,'Value')} returns selected item from POP_SEN_CABLE
switch get(hObject,'Value')
    case 1
% No Cable Defined
        handles.SelfCable=0;
    case 2
% RG187A/U (75 Ohm)
        handles.SelfCable=0;

        handles.CablePropVelo=69.5; % Percentage of Light Speed
        handles.CableImped=75;      % Ohm
        handles.ResisSource=75;     % Ohm
        handles.VeloProp=69.5;      % Percentage of Light Speed
        guidata(hObject, handles);
        
    otherwise
        handles.SelfCable=1;
        
end
set(handles.EDT_SEN_IMPED,'string',num2str(handles.CableImped));
set(handles.EDT_SEN_VP,'string',num2str(handles.CablePropVelo));
set(handles.EDT_MEASURE_R_SOURCE,'string',num2str(handles.ResisSource));
set(handles.EDT_MEASURE_VP,'string',num2str(handles.VeloProp));
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function POP_SEN_CABLE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to POP_SEN_CABLE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_SEN_IMPED_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_IMPED (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_SEN_IMPED as text
%        str2double(get(hObject,'String')) returns contents of EDT_SEN_IMPED as a double

if handles.SelfCable==0
    set(handles.EDT_SEN_IMPED,'string',num2str(handles.CableImped));
else
    IMPEDENCE=str2double(get(hObject,'String'));
    if IMPEDENCE>0
        handles.CableImped=IMPEDENCE;
        handles.ResisSource=IMPEDENCE;
        guidata(hObject, handles);
    end 
    set(handles.EDT_SEN_IMPED,'string',num2str(handles.CableImped));
    set(handles.EDT_MEASURE_R_SOURCE,'string',num2str(handles.ResisSource));
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function EDT_SEN_IMPED_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_IMPED (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_SEN_VP_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_VP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_SEN_VP as text
%        str2double(get(hObject,'String')) returns contents of EDT_SEN_VP as a double

if handles.SelfCable==0
    set(handles.EDT_SEN_VP,'string',num2str(handles.CablePropVelo));
else
    Vp=str2double(get(hObject,'String'));
    if (Vp<=100&&Vp>=0)
        handles.CablePropVelo=Vp;
        handles.VeloProp=Vp;
        guidata(hObject, handles);
    end
    set(handles.EDT_SEN_VP,'string',num2str(handles.CablePropVelo));
    set(handles.EDT_MEASURE_VP,'string',num2str(handles.VeloProp));
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function EDT_SEN_VP_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_VP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in POP_SEN_MATERIAL.
function POP_SEN_MATERIAL_Callback(hObject, eventdata, handles)
% hObject    handle to POP_SEN_MATERIAL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns POP_SEN_MATERIAL contents as cell array
%        contents{get(hObject,'Value')} returns selected item from POP_SEN_MATERIAL

switch get(hObject,'Value')
    case 1
% No Cable Defined
        handles.SelfProbe=0;
    case 2
% Stainless Steel
        handles.SelfProbe=0;
% RESISTIVITY        
        handles.ProbeResist=0.00000069;
% RELATIVE PERMEABILITY       
        handles.ProbeRelaMagnPerm=696.3029;
        guidata(hObject, handles);
        
    otherwise
% Input the user materials
        handles.SelfProbe=1;
        
end
set(handles.EDT_SEN_RESISTIVITY,'string',num2str(handles.ProbeResist));
set(handles.EDT_SEN_MUR,'string',num2str(handles.ProbeRelaMagnPerm));
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function POP_SEN_MATERIAL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to POP_SEN_MATERIAL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_SEN_SEPDIST_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_SEPDIST (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_SEN_SEPDIST as text
%        str2double(get(hObject,'String')) returns contents of EDT_SEN_SEPDIST as a double
SpeD=str2double(get(hObject,'String'));
if SpeD>0
    handles.PropDist=SpeD;
    guidata(hObject, handles);
else
    set(hObject,'String',num2str(handles.PropDist));
end

% --- Executes during object creation, after setting all properties.
function EDT_SEN_SEPDIST_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_SEPDIST (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_SEN_DIAM_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_DIAM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_SEN_DIAM as text
%        str2double(get(hObject,'String')) returns contents of EDT_SEN_DIAM as a double
DiamD=str2double(get(hObject,'String'));
if DiamD>0
    handles.PropDiam=DiamD;
    guidata(hObject, handles);
else
    set(hObject,'String',num2str(handles.PropDiam));
end

% --- Executes during object creation, after setting all properties.
function EDT_SEN_DIAM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_DIAM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_MEASURE_WINDOWLENGTH_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_WINDOWLENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_MEASURE_WINDOWLENGTH as text
%        str2double(get(hObject,'String')) returns contents of EDT_MEASURE_WINDOWLENGTH as a double
WindL=str2double(get(hObject,'String'));
if WindL>0
    handles.WindLength=WindL;
    guidata(hObject, handles);
else
    set(hObject,'String',num2str(handles.WindLength));
end

% --- Executes during object creation, after setting all properties.
function EDT_MEASURE_WINDOWLENGTH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_WINDOWLENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_MEASURE_VP_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_VP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_MEASURE_VP as text
%        str2double(get(hObject,'String')) returns contents of EDT_MEASURE_VP as a double
VP=str2double(get(hObject,'String'));
if VP>0
    handles.VeloProp=VP;
    guidata(hObject, handles);
else
    set(hObject,'String',num2str(handles.VeloProp));
end


% --- Executes during object creation, after setting all properties.
function EDT_MEASURE_VP_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_VP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_MEASURE_RPRO_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_RPRO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_MEASURE_RPRO as text
%        str2double(get(hObject,'String')) returns contents of EDT_MEASURE_RPRO as a double


% --- Executes during object creation, after setting all properties.
function EDT_MEASURE_RPRO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_RPRO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_MEASURE_LPRO_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_LPRO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_MEASURE_LPRO as text
%        str2double(get(hObject,'String')) returns contents of EDT_MEASURE_LPRO as a double


% --- Executes during object creation, after setting all properties.
function EDT_MEASURE_LPRO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_LPRO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PBT_SEN_RESTORE.
function PBT_SEN_RESTORE_Callback(hObject, eventdata, handles)
% hObject    handle to PBT_SEN_RESTORE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function EDT_SEN_RESISTIVITY_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_RESISTIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_SEN_RESISTIVITY as text
%        str2double(get(hObject,'String')) returns contents of EDT_SEN_RESISTIVITY as a double
if handles.SelfProbe==0
    set(handles.EDT_SEN_RESISTIVITY,'string',num2str(handles.ProbeResist));
else
    rho=str2double(get(hObject,'String'));
    if rho>0
        handles.ProbeResist=rho;
        guidata(hObject, handles);
    end 
    set(handles.EDT_SEN_RESISTIVITY,'string',num2str(handles.ProbeResist));
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function EDT_SEN_RESISTIVITY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_RESISTIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_SEN_MUR_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_MUR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_SEN_MUR as text
%        str2double(get(hObject,'String')) returns contents of EDT_SEN_MUR as a double
if handles.SelfProbe==0
    set(handles.EDT_SEN_MUR,'string',num2str(handles.ProbeRelaMagnPerm));
else
    mur=str2double(get(hObject,'String'));
    if mur>0
        handles.ProbeRelaMagnPerm=mur;
        guidata(hObject, handles);
    end 
    set(handles.EDT_SEN_MUR,'string',num2str(handles.ProbeRelaMagnPerm));
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function EDT_SEN_MUR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_MUR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_SEN_PROBELENGTH_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_PROBELENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_SEN_PROBELENGTH as text
%        str2double(get(hObject,'String')) returns contents of EDT_SEN_PROBELENGTH as a double
ProbL=str2double(get(hObject,'String'));
if ProbL>0
    handles.ProbeLength=ProbL;
    guidata(hObject, handles);
else
    set(hObject,'String',num2str(handles.ProbeLength));
end


% --- Executes during object creation, after setting all properties.
function EDT_SEN_PROBELENGTH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_SEN_PROBELENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function MENU_FILE_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function MENU_OPEN_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_OPEN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Clean_Figures(handles)
handles.Step2PlotWater=0;
handles.Step2PlotBtc=0;
handles.Step2PlotWaterBMO=0;
handles.Step2PlotBtcBMO=0;
handles.Step2PlotWaterRef1=0;
handles.Step2PlotBtcRef1=0;
handles.Step2PlotWaterSmooth=0;
handles.Step2PlotBtcSmooth=0;
handles.Step2PlotWaterBMOSmooth=0;
handles.Step2PlotBtcBMOSmooth=0;

[FileName,PathName]=uigetfile({'*.xlsx';'*.xls';'*.*'},'Select a data file','MultiSelect', 'off');
if FileName==0
else
    
    handles.WaveformData=0;
    handles.WaveformData_Ref1=0;
    handles.WaveformData_Ref2=0;
    handles.WaveformData_Prem=0;
    handles.WaveformData_EC=0;
    handles.WaveformData_Theta=0;
    
    DataFile=sprintf('%s%s',PathName,FileName);
    handles.FileName=FileName;
    handles.FilePath=PathName;
    Waveform=xlsread(DataFile,'sheet1');
    [L,W]=size(Waveform);
    handles.WaveformData=Waveform;
    handles.DataLength=L;
    handles.WaterWaveNum=floor(L/2);
    handles.BtcWaveNum=L-floor(L/2);
    handles.DataWidth=W;
    
    handles.WaveformData_Ref1=zeros(L,1);
    handles.WaveformData_Ref2=zeros(L,1);
    handles.WaveformData_Prem=zeros(L,1);
    handles.WaveformData_Theta=zeros(L,1);
    handles.WaveformData_EC=zeros(L,1);
    handles.WaveformData_EC_Fitted=zeros(L,50);
    handles.Waveform_Fitted=zeros(L,W);
    
    guidata(hObject, handles);
        
    % initialize the result vector
    % set result sequence
%    handles.ProbeParC=zeros(L,16);
    handles.ProbeParG_Fitted=zeros(L,20);
    guidata(hObject, handles);
       
% initiate some plots and slide bars
    set(handles.SL_MANUAL_FIRSTREF,'Max',W-1);
    [Plot_Water_Wave,Plot_Btc_Wave]=PlotWaveForms(handles);
    handles.Step2PlotWater=Plot_Water_Wave;
    handles.Step2PlotBtc=Plot_Btc_Wave;

     guidata(hObject, handles);
 end


% --------------------------------------------------------------------
function MENU_SAVE_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_SAVE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[FileName,PathName]=uiputfile({'*.xlsx';'*.xls';'*.*'},'Save to data file');
if FileName==0
else 
    DataFile=sprintf('%s%s',PathName,FileName);
    xlswrite(DataFile,handles.WaveformData_EC_Fitted,'sheet1');
    xlswrite(DataFile,handles.Waveform_Water_Fitted,'sheet2');
    xlswrite(DataFile,handles.Waveform_Fitted,'sheet3');
end




% --------------------------------------------------------------------
function MENU_QUIT_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_QUIT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function MENU_ABOUT_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_ABOUT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function MENU_BISFIT_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_BISFIT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function EDT_MEASURE_INPUT_VOLTAGE_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_INPUT_VOLTAGE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_MEASURE_INPUT_VOLTAGE as text
%        str2double(get(hObject,'String')) returns contents of EDT_MEASURE_INPUT_VOLTAGE as a double
V0=str2double(get(hObject,'String'));
if handles.SelfSystem==1
    if V0>0
        handles.InputVoltage=V0;
        guidata(hObject, handles);
    else
        set(hObject,'String',num2str(handles.InputVoltage));
    end
else
    set(hObject,'String',num2str(handles.InputVoltage));
end

% --- Executes during object creation, after setting all properties.
function EDT_MEASURE_INPUT_VOLTAGE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_INPUT_VOLTAGE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_MEASURE_INPUT_RISINGTIME_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_INPUT_RISINGTIME (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_MEASURE_INPUT_RISINGTIME as text
%        str2double(get(hObject,'String')) returns contents of EDT_MEASURE_INPUT_RISINGTIME as a double
RisingTime=str2double(get(hObject,'String'))*1.0e-12;
if handles.SelfSystem==1
    if RisingTime>0
        handles.InputRiseTime=RisingTime;
        guidata(hObject, handles);
    else
        set(hObject,'String',num2str(handles.InputRiseTime*1.0e+12));
    end
else
    set(hObject,'String',num2str(handles.InputRiseTime*1.0e+12));
end

% --- Executes during object creation, after setting all properties.
function EDT_MEASURE_INPUT_RISINGTIME_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_INPUT_RISINGTIME (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_MEASURE_R_SOURCE_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_R_SOURCE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_MEASURE_R_SOURCE as text
%        str2double(get(hObject,'String')) returns contents of EDT_MEASURE_R_SOURCE as a double
r_source=str2double(get(hObject,'String'));
if handles.SelfSystem==1
    if r_source>=0
        handles.ResisSource=r_source;
        guidata(hObject, handles);
    else
        set(hObject,'String',num2str(handles.ResisSource));
    end
else
    set(hObject,'String',num2str(handles.ResisSource));
end


% --- Executes during object creation, after setting all properties.
function EDT_MEASURE_R_SOURCE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_R_SOURCE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_MEASURE_R_LOAD_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_R_LOAD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_MEASURE_R_LOAD as text
%        str2double(get(hObject,'String')) returns contents of EDT_MEASURE_R_LOAD as a double
r_load=str2double(get(hObject,'String'));
if r_load>=0
    handles.ResisLoad=r_load;
    guidata(hObject, handles);
else
    set(hObject,'String',num2str(handles.ResisLoad));
end

% --- Executes during object creation, after setting all properties.
function EDT_MEASURE_R_LOAD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_R_LOAD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in POP_MEASURE.
function POP_MEASURE_Callback(hObject, eventdata, handles)
% hObject    handle to POP_MEASURE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns POP_MEASURE contents as cell array
%        contents{get(hObject,'Value')} returns selected item from POP_MEASURE
switch get(hObject,'Value')
    case 1
% No Cable Defined
        handles.SelfSystem=0;
    case 2
% RG187A/U (75 Ohm)
        handles.SelfSystem=0;
        
            
        handles.InputVoltage=250;
        handles.InputRiseTime=140*1.0e-12;
        handles.InputTimeReso=12.2*1.0e-12;
        handles.ResisSource=50.00;
        guidata(hObject, handles);
        
    otherwise
        handles.SelfSystem=1;
        
end
set(handles.EDT_MEASURE_INPUT_VOLTAGE,'string',num2str(handles.InputVoltage));
set(handles.EDT_MEASURE_INPUT_RISINGTIME,'string',num2str(handles.InputRiseTime*1.0e+12));
set(handles.EDT_MEASURE_INPUT_TIMERESO,'string',num2str(handles.InputTimeReso*1.0e+12));
set(handles.EDT_MEASURE_R_SOURCE,'string',num2str(handles.ResisSource));
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function POP_MEASURE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to POP_MEASURE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit27_Callback(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit27 as text
%        str2double(get(hObject,'String')) returns contents of edit27 as a double


% --- Executes during object creation, after setting all properties.
function edit27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit28_Callback(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit28 as text
%        str2double(get(hObject,'String')) returns contents of edit28 as a double


% --- Executes during object creation, after setting all properties.
function edit28_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_WAVEINFO_WATERNUM_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEINFO_WATERNUM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_WAVEINFO_WATERNUM as text
%        str2double(get(hObject,'String')) returns contents of EDT_WAVEINFO_WATERNUM as a double
water=str2double(get(hObject,'String'));
water=min(max(1,water),handles.DataLength);
btc=handles.DataLength-water;
handles.WaterWaveNum=water;
handles.BtcWaveNum=btc;
set(handles.EDT_WAVEINFO_BTCNUM,'string',num2str(btc));
set(handles.EDT_WAVEINFO_WATERNUM,'string',num2str(water));
guidata(hObject, handles);

Clean_Figures(handles);
handles.Step2PlotWater=0;
handles.Step2PlotBtc=0;
handles.Step2PlotWaterBMO=0; 
handles.Step2PlotBtcBMO=0;
handles.Step2PlotWaterRef1=0;
handles.Step2PlotBtcRef1=0;
handles.Step2PlotWaterRef2=0;
handles.Step2PlotBtcRef2=0;
handles.Step2PlotWaterSmooth=0;
handles.Step2PlotBtcSmooth=0;
handles.Step2PlotWaterBMOSmooth=0;
handles.Step2PlotBtcBMOSmooth=0;

[Plot_Water_Wave,Plot_Btc_Wave]=PlotWaveForms(handles);
handles.Step2PlotWater=Plot_Water_Wave;
handles.Step2PlotBtc=Plot_Btc_Wave;

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function EDT_WAVEINFO_WATERNUM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEINFO_WATERNUM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_WAVEINFO_BTCNUM_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEINFO_BTCNUM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_WAVEINFO_BTCNUM as text
%        str2double(get(hObject,'String')) returns contents of EDT_WAVEINFO_BTCNUM as a double

btc=str2double(get(hObject,'String'));
btc=max(min(1,btc),handles.DataLength);
water=handles.DataLength-btc;
handles.WaterWaveNum=water;
handles.BtcWaveNum=btc;
set(handles.EDT_WAVEINFO_BTCNUM,'string',num2str(btc));
set(handles.EDT_WAVEINFO_WATERNUM,'string',num2str(water));
guidata(hObject, handles);

Clean_Figures(handles);
handles.Step2PlotWater=0;
handles.Step2PlotBtc=0;
handles.Step2PlotWaterBMO=0; 
handles.Step2PlotBtcBMO=0;
handles.Step2PlotWaterRef1=0;
handles.Step2PlotBtcRef1=0;
handles.Step2PlotWaterRef2=0;
handles.Step2PlotBtcRef2=0;
handles.Step2PlotWaterSmooth=0;
handles.Step2PlotBtcSmooth=0;
handles.Step2PlotWaterBMOSmooth=0;
handles.Step2PlotBtcBMOSmooth=0;
    
[Plot_Water_Wave,Plot_Btc_Wave]=PlotWaveForms(handles);
handles.Step2PlotWater=Plot_Water_Wave;
handles.Step2PlotBtc=Plot_Btc_Wave;

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function EDT_WAVEINFO_BTCNUM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEINFO_BTCNUM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_WAVEINFO_TOTALNUM_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEINFO_TOTALNUM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_WAVEINFO_TOTALNUM as text
%        str2double(get(hObject,'String')) returns contents of EDT_WAVEINFO_TOTALNUM as a double
set(hObject,'String',num2str(handles.DataLength));


% --- Executes during object creation, after setting all properties.
function EDT_WAVEINFO_TOTALNUM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEINFO_TOTALNUM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit32_Callback(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit32 as text
%        str2double(get(hObject,'String')) returns contents of edit32 as a double


% --- Executes during object creation, after setting all properties.
function edit32_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_MANUAL_FIRSTREF_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_MANUAL_FIRSTREF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_MANUAL_FIRSTREF as text
%        str2double(get(hObject,'String')) returns contents of EDT_MANUAL_FIRSTREF as a double


mode=handles.Setting_WaterBtc;
DataWidth=handles.DataWidth;
if mode==1
    FirstRef=max(min(str2double(get(hObject,'String')),DataWidth-1),0);
    handles.Manual_Water_Ref1=FirstRef;
    guidata(hObject, handles);
    if handles.Manual_Ref1_Water_Check==1
        if(handles.Step2PlotWaterRef1~=0)
            delete(handles.Step2PlotWaterRef1);
            handles.Step2PlotWaterRef1=0;
        end
        PlotFirRef=PlotWaveFirstRef(handles,mode);
            handles.Step2PlotWaterRef1=PlotFirRef;
    end
    
    guidata(hObject, handles);
    set(handles.SL_MANUAL_FIRSTREF,'value',handles.Manual_Water_Ref1);
    set(handles.EDT_MANUAL_FIRSTREF,'string',num2str(handles.Manual_Water_Ref1));

elseif mode==2
    FirstRef=max(min(str2double(get(hObject,'String')),handles.DataWidth-1),0);
    handles.Manual_Btc_Ref1=FirstRef;
    guidata(hObject, handles);
    if handles.Manual_Ref1_Btc_Check==1
        if(handles.Step2PlotBtcRef1~=0)
            delete(handles.Step2PlotBtcRef1);
            handles.Step2PlotBtcRef1=0;
        end
        PlotFirRef=PlotWaveFirstRef(handles,mode);
            handles.Step2PlotBtcRef1=PlotFirRef;
    end
    
    guidata(hObject, handles);
    set(handles.SL_MANUAL_FIRSTREF,'value',handles.Manual_Btc_Ref1);
    set(handles.EDT_MANUAL_FIRSTREF,'string',num2str(handles.Manual_Btc_Ref1));
    
else
end



% --- Executes during object creation, after setting all properties.
function EDT_MANUAL_FIRSTREF_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_MANUAL_FIRSTREF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit34_Callback(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit34 as text
%        str2double(get(hObject,'String')) returns contents of edit34 as a double


% --- Executes during object creation, after setting all properties.
function edit34_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in PB_WATER_WAVE_SETTINGS.
function PB_WATER_WAVE_SETTINGS_Callback(hObject, eventdata, handles)
% hObject    handle to PB_WATER_WAVE_SETTINGS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
mode=1;
handles.Setting_WaterBtc=mode;

Clean_Figures(handles);
handles.Step2PlotWater=0;
handles.Step2PlotBtc=0;
handles.Step2PlotWaterBMO=0;
handles.Step2PlotBtcBMO=0;
handles.Step2PlotWaterRef1=0;
handles.Step2PlotBtcRef1=0;
handles.Step2PlotWaterSmooth=0;
handles.Step2PlotBtcSmooth=0;
handles.Step2PlotWaterBMOSmooth=0;
handles.Step2PlotBtcBMOSmooth=0;
handles.Step2PlotWaterRef2=0;
handles.Step2PlotBtcRef2=0;

%-----------------------------------------------------------
%   plot the BMO for all water waveforms
%   mode=1
%-----------------------------------------------------------  
[BMO,PWave,PBMO]=PlotWaveFormBMO(handles,mode);
    handles.WaveformBMO_Water=BMO;
    handles.Step2PlotWater=PWave;
    handles.Step2PlotWaterBMO=PBMO; 
%-----------------------------------------------------------
%   plot the first reflection position
%   the initial value for check is 0
%   i.e., for the first run check is 0
%-----------------------------------------------------------
if handles.Manual_Ref1_Water_Check==1  
    set(handles.CB_MANUAL_FIRSTREF,'value',1);
    PlotFirRef=PlotWaveFirstRef(handles,mode);
    handles.Step2PlotWaterRef1=PlotFirRef;
else
    set(handles.CB_MANUAL_FIRSTREF,'value',0);
end
set(handles.SL_MANUAL_FIRSTREF,'value',handles.Manual_Water_Ref1);
set(handles.EDT_MANUAL_FIRSTREF,'string',num2str(handles.Manual_Water_Ref1));
%------------------------------------------------------------
%   check for smooth method
%   the initial value for check is 0
%   i.e., for the first run check is 0
%------------------------------------------------------------
if handles.Waveform_Water_Smooth_Check==1
    set(handles.CB_WAVE_SMOOTH,'value',1);
    [PWave_SMOOTH,PBMO_SMOOTH]=PlotWaveFormBMO_Smooth(handles, mode);
        handles.Step2PlotWaterSmooth=PWave_SMOOTH;
        handles.Step2PlotWaterBMOSmooth=PBMO_SMOOTH;
else
    set(handles.CB_WAVE_SMOOTH,'value',0);
end
set(handles.SL_WAVE_SMOOTH,'value',handles.Smooth_Water_Intensity);
set(handles.EDT_WAVE_SMOOTH,'string',num2str(handles.Smooth_Water_Intensity));
%------------------------------------------------------------
%   set the sensitivity value
%   not used for plot but for ref position determination
%------------------------------------------------------------
set(handles.EDT_WAVE_SENSITIVITY,'string',num2str(handles.Sensitivity_Water));
set(handles.SL_WAVE_SENSITIVITY,'value',handles.Sensitivity_Water);

guidata(hObject, handles);


% --- Executes on button press in PB_BTC_WAVE_SETTINGS.
function PB_BTC_WAVE_SETTINGS_Callback(hObject, eventdata, handles)
% hObject    handle to PB_BTC_WAVE_SETTINGS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
mode=2;

handles.Setting_WaterBtc=mode;

Clean_Figures(handles);
handles.Step2PlotWater=0;
handles.Step2PlotBtc=0;
handles.Step2PlotWaterBMO=0;
handles.Step2PlotBtcBMO=0;
handles.Step2PlotWaterRef1=0;
handles.Step2PlotBtcRef1=0;
handles.Step2PlotWaterRef2=0;
handles.Step2PlotBtcRef2=0;
handles.Step2PlotWaterSmooth=0;
handles.Step2PlotBtcSmooth=0;
handles.Step2PlotWaterBMOSmooth=0;
handles.Step2PlotBtcBMOSmooth=0;

%-----------------------------------------------------------
%   plot the BMO for all BTC (with electrical conductivity measurements)
%   waveforms
%   mode=2
%-----------------------------------------------------------  
[BMO,PWave,PBMO]=PlotWaveFormBMO(handles,mode); 
    handles.WaveformBMO_Btc=BMO;
    handles.Step2PlotBtc=PWave;
    handles.Step2PlotBtcBMO=PBMO;  
%-----------------------------------------------------------
%   plot the first reflection position
%   the initial value for check is 0
%   i.e., for the first run check is 0
%-----------------------------------------------------------
if handles.Manual_Ref1_Btc_Check==1
    set(handles.CB_MANUAL_FIRSTREF,'value',1);
    PlotFirRef=PlotWaveFirstRef(handles,mode);
    handles.Step2PlotBtcRef1=PlotFirRef;
else
    set(handles.CB_MANUAL_FIRSTREF,'value',0);
end
set(handles.SL_MANUAL_FIRSTREF,'value',handles.Manual_Btc_Ref1);
set(handles.EDT_MANUAL_FIRSTREF,'string',num2str(handles.Manual_Btc_Ref1));
%------------------------------------------------------------
%   check for smooth method
%   the initial value for check is 0
%   i.e., for the first run check is 0
%------------------------------------------------------------
if handles.Waveform_Btc_Smooth_Check==1
    set(handles.CB_WAVE_SMOOTH,'value',1);
    [PWave_SMOOTH,PBMO_SMOOTH]=PlotWaveFormBMO_Smooth(handles, mode);
        handles.Step2PlotBtcSmooth=PWave_SMOOTH;
        handles.Step2PlotBtcBMOSmooth=PBMO_SMOOTH;
else
    set(handles.CB_WAVE_SMOOTH,'value',0);
end
set(handles.SL_WAVE_SMOOTH,'value',handles.Smooth_Btc_Intensity);
set(handles.EDT_WAVE_SMOOTH,'string',num2str(handles.Smooth_Btc_Intensity));
%------------------------------------------------------------
%   set the sensitivity value
%   not used for plot but for ref position determination
%------------------------------------------------------------
set(handles.EDT_WAVE_SENSITIVITY,'string',num2str(handles.Sensitivity_Btc));
set(handles.SL_WAVE_SENSITIVITY,'value',handles.Sensitivity_Btc);

guidata(hObject, handles);

% --- Executes on slider movement.
function SL_MANUAL_FIRSTREF_Callback(hObject, eventdata, handles)
% hObject    handle to SL_MANUAL_FIRSTREF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

mode=handles.Setting_WaterBtc;
if mode==1
    FirstRef=get(hObject,'Value');
    handles.Manual_Water_Ref1=FirstRef;
    guidata(hObject, handles);
    if handles.Manual_Ref1_Water_Check==1
        if(handles.Step2PlotWaterRef1~=0)
            delete(handles.Step2PlotWaterRef1);
            handles.Step2PlotWaterRef1=0;
        end
        PlotFirRef=PlotWaveFirstRef(handles,mode);
        handles.Step2PlotWaterRef1=PlotFirRef;
    end
    set(handles.EDT_MANUAL_FIRSTREF,'string',num2str(FirstRef));
    guidata(hObject, handles);
elseif mode==2
    FirstRef=get(hObject,'Value');
    handles.Manual_Btc_Ref1=FirstRef;
    guidata(hObject, handles);
    if handles.Manual_Ref1_Btc_Check==1
        if(handles.Step2PlotBtcRef1~=0)
            delete(handles.Step2PlotBtcRef1);
            handles.Step2PlotBtcRef1=0;
        end
        PlotFirRef=PlotWaveFirstRef(handles,mode);
        handles.Step2PlotBtcRef1=PlotFirRef;
    end
    set(handles.EDT_MANUAL_FIRSTREF,'string',num2str(FirstRef));
    guidata(hObject, handles);
else
end


% --- Executes during object creation, after setting all properties.
function SL_MANUAL_FIRSTREF_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SL_MANUAL_FIRSTREF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function SL_WAVE_SMOOTH_Callback(hObject, eventdata, handles)
% hObject    handle to SL_WAVE_SMOOTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


mode=handles.Setting_WaterBtc;

if mode==1
    k=get(hObject,'Value');
    handles.Smooth_Water_Intensity=k;
    guidata(hObject, handles);
    if handles.Waveform_Water_Smooth_Check==1
        if(handles.Step2PlotWaterSmooth~=0)
            delete(handles.Step2PlotWaterSmooth);
            handles.Step2PlotWaterSmooth=0;
        end
        if(handles.Step2PlotWaterBMOSmooth~=0)
            delete(handles.Step2PlotWaterBMOSmooth);
            handles.Step2PlotWaterBMOSmooth=0;
        end
        [WAVE_SMOOTH,BMO_SMOOTH]=Waveform_Smoothing(handles, mode);
        handles.Waveform_Water_Smooth=WAVE_SMOOTH;
        handles.WaveformBMO_Water_Smooth=BMO_SMOOTH;
        guidata(hObject, handles);
        
        [PWave_SMOOTH,PBMO_SMOOTH]=PlotWaveFormBMO_Smooth(handles, mode);
        handles.Step2PlotWaterSmooth=PWave_SMOOTH;
        handles.Step2PlotWaterBMOSmooth=PBMO_SMOOTH;
    end
    
    guidata(hObject, handles);
    set(handles.EDT_WAVE_SMOOTH,'string',num2str(handles.Smooth_Water_Intensity));
    
elseif mode==2
    
    k=get(hObject,'Value');
    handles.Smooth_Btc_Intensity=k;
    
    if handles.Waveform_Btc_Smooth_Check==1
        if(handles.Step2PlotBtcSmooth~=0)
            delete(handles.Step2PlotBtcSmooth);
            handles.Step2PlotBtcSmooth=0;
        end
        if(handles.Step2PlotBtcBMOSmooth~=0)
            delete(handles.Step2PlotBtcBMOSmooth);
            handles.Step2PlotBtcBMOSmooth=0;
        end
        [WAVE_SMOOTH,BMO_SMOOTH]=Waveform_Smoothing(handles, mode);
        handles.Waveform_Btc_Smooth=WAVE_SMOOTH;
        handles.WaveformBMO_Btc_Smooth=BMO_SMOOTH;
        guidata(hObject, handles);
        
        [PWave_SMOOTH,PBMO_SMOOTH]=PlotWaveFormBMO_Smooth(handles, mode);
        handles.Step2PlotBtcSmooth=PWave_SMOOTH;
        handles.Step2PlotBtcBMOSmooth=PBMO_SMOOTH;
    end
    
    guidata(hObject, handles);
    set(handles.EDT_WAVE_SMOOTH,'string',num2str(handles.Smooth_Water_Intensity));
    
else
end



% --- Executes during object creation, after setting all properties.
function SL_WAVE_SMOOTH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SL_WAVE_SMOOTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function SL_WAVE_SENSITIVITY_Callback(hObject, eventdata, handles)
% hObject    handle to SL_WAVE_SENSITIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


mode=handles.Setting_WaterBtc;

if mode==1
    k=get(hObject,'Value');
    handles.Sensitivity_Water=k;
    guidata(hObject, handles);
    set(handles.EDT_WAVE_SENSITIVITY,'string',num2str(handles.Sensitivity_Water));
    
elseif mode==2
    
    k=get(hObject,'Value');
    handles.Sensitivity_Btc=k;
    guidata(hObject, handles);
    set(handles.EDT_WAVE_SENSITIVITY,'string',num2str(handles.Sensitivity_Btc));
    
else
end


% --- Executes during object creation, after setting all properties.
function SL_WAVE_SENSITIVITY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SL_WAVE_SENSITIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function EDT_WAVE_SMOOTH_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_WAVE_SMOOTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_WAVE_SMOOTH as text
%        str2double(get(hObject,'String')) returns contents of EDT_WAVE_SMOOTH as a double


mode=handles.Setting_WaterBtc;

if mode==1
    k=max(min(str2double(get(hObject,'String')),0),1);
    handles.Smooth_Water_Intensity=k;
    
    if handles.Waveform_Water_Smooth_Check==1
        if(handles.Step2PlotWaterSmooth~=0)
            delete(handles.Step2PlotWaterSmooth);
            handles.Step2PlotWaterSmooth=0;
        end
        if(handles.Step2PlotWaterBMOSmooth~=0)
            delete(handles.Step2PlotWaterBMOSmooth);
            handles.Step2PlotWaterBMOSmooth=0;
        end
        [WAVE_SMOOTH,BMO_SMOOTH]=Waveform_Smoothing(handles, mode);
        handles.Waveform_Water_Smooth=WAVE_SMOOTH;
        handles.WaveformBMO_Water_Smooth=BMO_SMOOTH;
        guidata(hObject, handles);
        
        [PWave_SMOOTH,PBMO_SMOOTH]=PlotWaveFormBMO_Smooth(handles, mode);
        handles.Step2PlotWaterSmooth=PWave_SMOOTH;
        handles.Step2PlotWaterBMOSmooth=PBMO_SMOOTH;
    end
    
    guidata(hObject, handles);
    set(handles.EDT_WAVE_SMOOTH,'string',num2str(handles.Smooth_Water_Intensity));
    set(handles.SL_WAVE_SMOOTH,'value',handles.Smooth_Water_Intensity);
    
elseif mode==2
    
    k=max(min(str2double(get(hObject,'String')),0),1);
    handles.Smooth_Btc_Intensity=k;
    
    if handles.Waveform_Btc_Smooth_Check==1
        if(handles.Step2PlotBtcSmooth~=0)
            delete(handles.Step2PlotBtcSmooth);
            handles.Step2PlotBtcSmooth=0;
        end
        if(handles.Step2PlotBtcBMOSmooth~=0)
            delete(handles.Step2PlotBtcBMOSmooth);
            handles.Step2PlotBtcBMOSmooth=0;
        end
        [WAVE_SMOOTH,BMO_SMOOTH]=Waveform_Smoothing(handles, mode);
        handles.Waveform_Btc_Smooth=WAVE_SMOOTH;
        handles.WaveformBMO_Btc_Smooth=BMO_SMOOTH;
        guidata(hObject, handles);
        
        [PWave_SMOOTH,PBMO_SMOOTH]=PlotWaveFormBMO_Smooth(handles, mode);
        handles.Step2PlotBtcSmooth=PWave_SMOOTH;
        handles.Step2PlotBtcBMOSmooth=PBMO_SMOOTH;
    end
    
    guidata(hObject, handles);
    set(handles.EDT_WAVE_SMOOTH,'string',num2str(handles.Smooth_Btc_Intensity));
    set(handles.SL_WAVE_SMOOTH,'value',handles.Smooth_Btc_Intensity);
    
else
end


% --- Executes during object creation, after setting all properties.
function EDT_WAVE_SMOOTH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_WAVE_SMOOTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_WAVE_SENSITIVITY_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_WAVE_SENSITIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_WAVE_SENSITIVITY as text
%        str2double(get(hObject,'String')) returns contents of EDT_WAVE_SENSITIVITY as a double

mode=handles.Setting_WaterBtc;

if mode==1
    k=max(min(str2double(get(hObject,'String')),0),1);
    handles.Sensitivity_Water=k;
    guidata(hObject, handles);
    set(handles.EDT_WAVE_SENSITIVITY,'string',num2str(handles.Sensitivity_Water));
    set(handles.SL_WAVE_SENSITIVITY,'value',handles.Sensitivity_Water);
elseif mode==2
    k=max(min(str2double(get(hObject,'String')),0),1);
    handles.Sensitivity_Btc=k;
    guidata(hObject, handles);
    set(handles.EDT_WAVE_SENSITIVITY,'string',num2str(handles.Sensitivity_Btc));
    set(handles.SL_WAVE_SENSITIVITY,'value',handles.Sensitivity_Btc);
else
end


% --- Executes during object creation, after setting all properties.
function EDT_WAVE_SENSITIVITY_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_WAVE_SENSITIVITY (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in CB_MANUAL_FIRSTREF.
function CB_MANUAL_FIRSTREF_Callback(hObject, eventdata, handles)
% hObject    handle to CB_MANUAL_FIRSTREF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of CB_MANUAL_FIRSTREF

% 1 for yes and 0 for no
check=get(hObject,'Value');
% 1 for water and 2 for btc
mode=handles.Setting_WaterBtc;

if mode==1
    if check==1
        handles.Manual_Ref1_Water_Check=1; 
        if(handles.Step2PlotWaterRef1~=0)
            delete(handles.Step2PlotWaterRef1);
            handles.Step2PlotWaterRef1=0;
        end
        guidata(hObject, handles);
        PlotFirRef=PlotWaveFirstRef(handles,mode);
        handles.Step2PlotWaterRef1=PlotFirRef;
        guidata(hObject, handles);
    else
        handles.Manual_Ref1_Water_Check=0;
        if(handles.Step2PlotWaterRef1~=0)
            delete(handles.Step2PlotWaterRef1);
            handles.Step2PlotWaterRef1=0;
        end
        guidata(hObject, handles);
    end 
    
elseif mode==2
    if check==1
        handles.Manual_Ref1_Btc_Check=1;
        if(handles.Step2PlotBtcRef1~=0)
            delete(handles.Step2PlotBtcRef1);
            handles.Step2PlotBtcRef1=0;
        end
        guidata(hObject, handles);
        PlotFirRef=PlotWaveFirstRef(handles,mode);
        handles.Step2PlotBtcRef1=PlotFirRef;
        guidata(hObject, handles);
    else
        handles.Manual_Ref1_Btc_Check=0;
        if(handles.Step2PlotBtcRef1~=0)
            delete(handles.Step2PlotBtcRef1);
            handles.Step2PlotBtcRef1=0;
        end
        guidata(hObject, handles);
    end     
else
end



% --- Executes on button press in CB_WAVE_SMOOTH.
function CB_WAVE_SMOOTH_Callback(hObject, eventdata, handles)
% hObject    handle to CB_WAVE_SMOOTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of CB_WAVE_SMOOTH

% 1 for yes and 0 for no
check=get(hObject,'Value');
% 1 for water and 2 for btc
mode=handles.Setting_WaterBtc;

%----------------------------------------------------------------
%   for water
%   otained smoothed waveform and plot
%----------------------------------------------------------------
if mode==1
    if check==1
        handles.Waveform_Water_Smooth_Check=1; 
        if(handles.Step2PlotWaterSmooth~=0)
            delete(handles.Step2PlotWaterSmooth);
            handles.Step2PlotWaterSmooth=0;
        end
        if(handles.Step2PlotWaterBMOSmooth~=0)
            delete(handles.Step2PlotWaterBMOSmooth);
            handles.Step2PlotWaterBMOSmooth=0;
        end
        [WAVE_SMOOTH,BMO_SMOOTH]=Waveform_Smoothing(handles, mode);
        handles.Waveform_Water_Smooth=WAVE_SMOOTH;
        handles.WaveformBMO_Water_Smooth=BMO_SMOOTH;
        guidata(hObject, handles);
        
        [PWave_SMOOTH,PBMO_SMOOTH]=PlotWaveFormBMO_Smooth(handles, mode);
        handles.Step2PlotWaterSmooth=PWave_SMOOTH;
        handles.Step2PlotWaterBMOSmooth=PBMO_SMOOTH;
        guidata(hObject, handles);
    else
        handles.Waveform_Water_Smooth_Check=0;
        if(handles.Step2PlotWaterSmooth~=0)
            delete(handles.Step2PlotWaterSmooth);
            handles.Step2PlotWaterSmooth=0;
        end
        if(handles.Step2PlotWaterBMOSmooth~=0)
            delete(handles.Step2PlotWaterBMOSmooth);
            handles.Step2PlotWaterBMOSmooth=0;
        end
        guidata(hObject, handles);
    end  
%----------------------------------------------------------------
%   for btc
%   otained smoothed waveform and plot
%----------------------------------------------------------------
elseif mode==2
    if check==1
        handles.Waveform_Btc_Smooth_Check=1;
        if(handles.Step2PlotBtcSmooth~=0)
            delete(handles.Step2PlotBtcSmooth);
            handles.Step2PlotBtcSmooth=0;
        end
        if(handles.Step2PlotBtcBMOSmooth~=0)
            delete(handles.Step2PlotBtcBMOSmooth);
            handles.Step2PlotBtcBMOSmooth=0;
        end
        
        [WAVE_SMOOTH,BMO_SMOOTH]=Waveform_Smoothing(handles, mode);
        handles.Waveform_Btc_Smooth=WAVE_SMOOTH; 
        handles.WaveformBMO_Btc_Smooth=BMO_SMOOTH;
        guidata(hObject, handles);
        
        [PWave_SMOOTH,PBMO_SMOOTH]=PlotWaveFormBMO_Smooth(handles, mode);
        handles.Step2PlotBtcSmooth=PWave_SMOOTH;
        handles.Step2PlotBtcBMOSmooth=PBMO_SMOOTH;
        guidata(hObject, handles);
    else
        handles.Waveform_Btc_Smooth_Check=0;
        if(handles.Step2PlotBtcSmooth~=0)
            delete(handles.Step2PlotBtcSmooth);
            handles.Step2PlotBtcSmooth=0;
        end
        if(handles.Step2PlotBtcBMOSmooth~=0)
            delete(handles.Step2PlotBtcBMOSmooth);
            handles.Step2PlotBtcBMOSmooth=0;
        end
        guidata(hObject, handles);
    end     
else
end


% --------------------------------------------------------------------
function MENU_CALIBRATION_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_CALIBRATION (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function MENU_CALI_WATER_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_CALI_WATER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function MENU_CALI_INPUT_Callback(hObject, eventdata, handles)
% hObject    handle to MENU_CALI_INPUT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function EDT_WAVEFORM_WATER_RES_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEFORM_WATER_RES (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_WAVEFORM_WATER_RES as text
%        str2double(get(hObject,'String')) returns contents of EDT_WAVEFORM_WATER_RES as a double


% --- Executes during object creation, after setting all properties.
function EDT_WAVEFORM_WATER_RES_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEFORM_WATER_RES (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PB_WAVEFORM_ANALYSIS.
function PB_WAVEFORM_ANALYSIS_Callback(hObject, eventdata, handles)
% hObject    handle to PB_WAVEFORM_ANALYSIS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% first write down the window length data and probe length data

%    vp=handles.VeloProp;
%    vc=handles.LightSpeed;

    WindLength=handles.WindLength;
    if handles.PropLength_Cali_Check==0
        ProbLength=handles.ProbeLength;
    else
        ProbLength=handles.PropLength_Cali;
    end
    WaveForm=handles.WaveformData;
    mode=handles.Setting_WaterBtc;
    DataLength=handles.DataLength;
    DataWidth=handles.DataWidth;
    
    set(handles.EDT_WAVEFORM_WINDOWLENGTH,'string',num2str(WindLength));
    set(handles.EDT_WAVEFORM_PROBELENGTH,'string',num2str(ProbLength));
%------------------------------------------------------------------------------
% water waveform analysis
%------------------------------------------------------------------------------  

% start parallel
    AnyPar=gcp('nocreate');
    if(isempty(AnyPar))
        ParFit=parpool('local');
        handles.ParFit=ParFit;
        guidata(hObject, handles);  
    end
% start the pool

    if mode==1
        WaterNum=handles.WaterWaveNum;
        FirRef=Auto_First_Ref_Position(handles,mode);
        SecRef=Auto_Second_Ref_Position(handles,mode);
%        Permitt=zeros(WaterNum,1);
%        Theta=zeros(WaterNum,1);
        EC=zeros(WaterNum,1);
        
        Permitt=(WindLength.*(SecRef-FirRef)./(DataWidth-1)./ProbLength).^2;
        Theta=ToppEq(Permitt);
        
        for k=1:WaterNum
            
%           Permitt(k,1)=(windowL*(SecRef(k,1)-FirRef(k,1))/(handles.DataWidth-1)/probeL).^2;
%           Theta(k,1)=ToppEq(Permitt(k,1));
% EC 
            V0=mean(WaveForm(k,1:floor(FirRef(k,1)/2)))+1;
            V1=mean(WaveForm(k,floor(SecRef(k,1)):ceil(SecRef(k,1))))+1;
            V2=mean(WaveForm(k,DataWidth-5:DataWidth))+1;
            V0=V0-(V0-1);
            V1=V1-(V0-1);
            V2=V2-(V0-1);
% use topp equation to give a pre-calculation in step 2            
            EC(k,1)=(sqrt(Permitt(k,1))/120/pi/(ProbLength/1000))...
                *log(V1*(2*V0-V1)/V0/(V2-V1))*10;   % determine the value as mS dm^-1 or 0.1 dS m^-1
        end
        
% the topp equation usually has an constant off-set
        minEC=min(EC);
        
        handles.WaveformData_Ref1(1:WaterNum,1)=FirRef;
        handles.WaveformData_Ref2(1:WaterNum,1)=SecRef;
        handles.WaveformData_Prem(1:WaterNum,1)=Permitt;
% the topp equation usually has an constant off-set
        handles.WaveformData_EC_Correction=minEC;
        handles.WaveformData_EC(1:WaterNum,1)=EC-minEC;
        handles.WaveformData_Theta(1:WaterNum,1)=Theta;
        
% start the plot of ref 1 and ref 2
        FirRef_Mean=mean(FirRef);
        SecRef_Mean=mean(SecRef);
        Permitt_Mean=mean(Permitt);
        Theta_Mean=mean(Theta);
        EC_Mean=mean(EC)-minEC;
        
        if(handles.Step2PlotWaterRef1~=0)
            delete(handles.Step2PlotWaterRef1);
            handles.Step2PlotWaterRef1=0;
        end
        if(handles.Step2PlotWaterRef2~=0)
            delete(handles.Step2PlotWaterRef2);
            handles.Step2PlotWaterRef2=0;
        end
        
        axes(handles.PIC_TDR_WAVE1)
        PlotFirRef_Wave1=plot([FirRef_Mean,FirRef_Mean],[-1,1],'r');
        PlotSecRef_Wave1=plot([SecRef_Mean,SecRef_Mean],[-1,1],'r');
        axes(handles.PIC_TDR_WAVE2)
        PlotFirRef_Wave2=plot([FirRef_Mean,FirRef_Mean],[-1,1],'r');
        PlotSecRef_Wave2=plot([SecRef_Mean,SecRef_Mean],[-1,1],'r');
        
        
        handles.Step2PlotWaterRef1=[PlotFirRef_Wave1,PlotFirRef_Wave2];
        handles.Step2PlotWaterRef2=[PlotSecRef_Wave1,PlotSecRef_Wave2];
        
        s1=sprintf('Ka=%f, VWC=%f',Permitt_Mean,Theta_Mean);
        set(handles.EDT_WAVEFORM_WATER_RES,'string',s1);
        s2=sprintf('EC=%f',EC_Mean);
        set(handles.EDT_WAVEFORM_EC_RES,'string',s2);
        
        guidata(hObject, handles);

%------------------------------------------------------------------------------
% btc waveform analysis
%------------------------------------------------------------------------------ 
    elseif mode==2
        
        BTCNum=handles.BtcWaveNum;
        WaterNum=handles.WaterWaveNum;
        EC_Correct=handles.WaveformData_EC_Correction;
        FirRef=Auto_First_Ref_Position(handles,mode);
        SecRef=Auto_Second_Ref_Position(handles,mode);
%        Permitt=zeros(BTCNum,1);
%        Theta=zeros(BTCNum,1);
        EC=zeros(BTCNum,1);
        
        Permitt=(WindLength.*(SecRef-FirRef)./(DataWidth-1)./ProbLength).^2;
        Theta=ToppEq(Permitt);
        
        for k=1:BTCNum
            
%           Permitt(k,1)=(windowL*(SecRef(k,1)-FirRef(k,1))/(handles.DataWidth-1)/probeL).^2;
%           Theta(k,1)=ToppEq(Permitt(k,1));
% EC 
            kk=k+WaterNum;
            V0=mean(WaveForm(kk,1:floor(FirRef(k,1)/2)))+1;
            V1=mean(WaveForm(kk,floor(SecRef(k,1)):ceil(SecRef(k,1))))+1;
            V2=mean(WaveForm(kk,DataWidth-5:DataWidth))+1;
            V0=V0-(V0-1);
            V1=V1-(V0-1);
            V2=V2-(V0-1);
            
%            EC(k,1)=handles.RELATIVEPERMITTIVITY_0*handles.LightSpeed...
%               /(probeL/1000)*sqrt(Permitt(k,1))*(V1/(2*V0-V1))*(2*V0/Vf-1);
            EC(k,1)=(sqrt(Permitt(k,1))/120/pi/(ProbLength/1000))...
                *log(V1*(2*V0-V1)/V0/(V2-V1))*10;   % determine the value as mS dm^-1 or 0.1 dS m^-1;
        end
        
        handles.WaveformData_Ref1(WaterNum+1:DataLength,1)=FirRef;
        handles.WaveformData_Ref2(WaterNum+1:DataLength,1)=SecRef;
        handles.WaveformData_Prem(WaterNum+1:DataLength,1)=Permitt;
        handles.WaveformData_EC(WaterNum+1:DataLength,1)=EC-EC_Correct;
        handles.WaveformData_Theta(WaterNum+1:DataLength,1)=Theta;
        
% start the plot of ref 1 and ref 2
        FirRef_Mean=mean(FirRef);
        SecRef_Mean=mean(SecRef);
        Permitt_Mean=mean(Permitt);
        Theta_Mean=mean(Theta);
        EC_Mean=mean(EC)-EC_Correct;
        
        if(handles.Step2PlotBtcRef1~=0)
            delete(handles.Step2PlotBtcRef1);
            handles.Step2PlotBtcRef1=0;
        end
        if(handles.Step2PlotBtcRef2~=0)
            delete(handles.Step2PlotBtcRef2);
            handles.Step2PlotBtcRef2=0;
        end
        
        axes(handles.PIC_TDR_WAVE1)
        PlotFirRef_Wave1=plot([FirRef_Mean,FirRef_Mean],[-1,1],'r');
        PlotSecRef_Wave1=plot([SecRef_Mean,SecRef_Mean],[-1,1],'r');
        axes(handles.PIC_TDR_WAVE2)
        PlotFirRef_Wave2=plot([FirRef_Mean,FirRef_Mean],[-1,1],'r');
        PlotSecRef_Wave2=plot([SecRef_Mean,SecRef_Mean],[-1,1],'r');
        
        handles.Step2PlotBtcRef1=[PlotFirRef_Wave1,PlotFirRef_Wave2];
        handles.Step2PlotBtcRef2=[PlotSecRef_Wave1,PlotSecRef_Wave2];
        
        s1=sprintf('Ka=%f, VWC=%f',Permitt_Mean,Theta_Mean);
        set(handles.EDT_WAVEFORM_WATER_RES,'string',s1);
        s2=sprintf('EC=%f',EC_Mean);
        set(handles.EDT_WAVEFORM_EC_RES,'string',s2);
        
        guidata(hObject, handles);

    else
        
    end
    



function EDT_WAVEFORM_EC_RES_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEFORM_EC_RES (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_WAVEFORM_EC_RES as text
%        str2double(get(hObject,'String')) returns contents of EDT_WAVEFORM_EC_RES as a double


% --- Executes during object creation, after setting all properties.
function EDT_WAVEFORM_EC_RES_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEFORM_EC_RES (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_WAVEFORM_WINDOWLENGTH_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEFORM_WINDOWLENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_WAVEFORM_WINDOWLENGTH as text
%        str2double(get(hObject,'String')) returns contents of EDT_WAVEFORM_WINDOWLENGTH as a double


% --- Executes during object creation, after setting all properties.
function EDT_WAVEFORM_WINDOWLENGTH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEFORM_WINDOWLENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_WAVEFORM_PROBELENGTH_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEFORM_PROBELENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_WAVEFORM_PROBELENGTH as text
%        str2double(get(hObject,'String')) returns contents of EDT_WAVEFORM_PROBELENGTH as a double


% --- Executes during object creation, after setting all properties.
function EDT_WAVEFORM_PROBELENGTH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_WAVEFORM_PROBELENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in PB_FITTING_BTC_WAVE.
function PB_FITTING_BTC_WAVE_Callback(hObject, eventdata, handles)
% hObject    handle to PB_FITTING_BTC_WAVE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% %%%%%%%%%%%%%%%%%%%%%%
%  handles.WaveformData_Ref1=[16.56.*ones(121,1);16.23.*ones(121,1);16.68.*ones(121,1)];
%  handles.WaveformData_Ref2=[151.9.*ones(121,1);152.91.*ones(121,1);151.43.*ones(121,1)];
%  handles.WaveformData_Prem=[81.4085.*ones(121,1);83.0285.*ones(121,1);80.7003.*ones(121,1)];
%  handles.WaveformData_Theta=[0.9990.*ones(121,1);1.0411.*ones(121,1);0.9815.*ones(121,1)];
%  handles.WaveformData_EC=[0.001.*ones(121,1);1.07.*ones(121,1);3.18.*ones(121,1)];
%  guidata(hObject, handles)
% %%%%%%%%%%%%%%%%%%%%%%

tic
Index=str2double(get(handles.EDT_FITTING_BTC_INDEX,'string'));   
WaveNum=handles.WaterWaveNum+Index;
WaveForm=handles.WaveformData(WaveNum,:);
if(handles.STEP3PLOTWATERWAVE~=0)
    delete(handles.STEP3PLOTWATERWAVE);
    handles.STEP3PLOTWATERWAVE=0;
end
if(handles.STEP3PLOTWATERWAVEFIT~=0)
    delete(handles.STEP3PLOTWATERWAVEFIT);
    handles.STEP3PLOTWATERWAVEFIT=0;
end
if(handles.STEP3PLOTBTCWAVE~=0)
    delete(handles.STEP3PLOTBTCWAVE);
    handles.STEP3PLOTBTCWAVE=0;
end
if(handles.STEP3PLOTBTCWAVEFIT~=0)
    delete(handles.STEP3PLOTBTCWAVEFIT);
    handles.STEP3PLOTBTCWAVEFIT=0;
end
guidata(hObject, handles)

axes(handles.PIC_TDR_INV)
hold on
DataWidth=handles.DataWidth;
X=0:DataWidth-1;
handles.STEP3PLOTBTCWAVE=plot(X,WaveForm,'b','linewidth',1); 
set(handles.PIC_TDR_INV,'xTick',[]);
set(handles.PIC_TDR_INV,'yTick',[]);
box on
drawnow;
guidata(hObject, handles)
NoDevision=str2double(get(handles.EDT_FITTING_NO_DEVISION,'string'));
        
% need to convert all the unit into SI unit
FirstRef=handles.WaveformData_Ref1(WaveNum,:);
% SecondRef=handles.WaveformData_Ref2(WaveNum,:);
EC=handles.WaveformData_EC(WaveNum,1);                         % unit in mS dm^-1
TimeInterval=handles.TimeInterval;
    
RCoef0=median(WaveForm(1:ceil(FirstRef)));
WaveForm=WaveForm-RCoef0;
    
AddL=handles.AdditionalLength;
AddT=handles.AdditionalTime;
CableL=handles.CableLength;
SolderL=handles.SolderLength;
ProbeL=handles.ProbeLength/1000;

L_Cable=handles.CableParL;
C_Cable=handles.CableParC;
R_Cable=handles.CableParR;
G_Cable=handles.CableParG;
L_Node=handles.NodeParL;
C_Node=handles.NodeParC;
R_Node=handles.NodeParR;
G_Node=handles.NodeParG;   
R_ProbeOrg=handles.ProbeParR;
L_ProbeOrg=handles.ProbeParL;
C_ProbeOrg=handles.ProbeParC;
    
PropDist=handles.PropDist;
PropDiam=handles.PropDiam;
LightSpeed=handles.LightSpeed;
       
Rs=handles.ResisSourceAdjusted;
Impendence=sqrt(L_ProbeOrg/C_ProbeOrg);
Rl=Impendence*40.0;
Vs=handles.InputVoltageFunc;
dVsdt=handles.InputVoltageFuncDiff;
AdjustFactor=handles.AdjustFactor;
G_ProbeOrg=pi*EC/acosh(PropDist/PropDiam).*AdjustFactor./10;
    
L_Probe=L_ProbeOrg*AdjustFactor;
C_Probe=C_ProbeOrg*AdjustFactor;
ProbeL=ProbeL/AdjustFactor;

Xdomain=AddL+CableL+SolderL+ProbeL;
dx=0.005;
NX=ceil(Xdomain/dx);
dx=Xdomain/NX;
dt=0.05*dx/LightSpeed;
TotalTimeStep=2*AddT+2*ceil(TimeInterval*(DataWidth-1)/dt);
DevisionArray=[floor((AddL+CableL+SolderL)/dx)+2:floor(ProbeL/dx/NoDevision):NX+1];
if(length(DevisionArray)<NoDevision+1)
    DevisionArray=[DevisionArray,NX+1];
else
    DevisionArray(NoDevision+1)=NX+1;
end
DevisionTimeArraySimu=zeros(NoDevision+1,1);

% the coefficient matrix
CableNo=floor((AddL+CableL)/dx)+1;
SolderNo=floor((AddL+CableL+SolderL)/dx)+1-CableNo;

R=[R_Cable.*ones(CableNo,1);R_Node.*ones(SolderNo,1);R_ProbeOrg*ones(NX+1-SolderNo-CableNo,1)];
L=[L_Cable.*ones(CableNo,1);L_Node.*ones(SolderNo,1);L_Probe*ones(NX+1-SolderNo-CableNo,1)];
G=[G_Cable.*ones(CableNo,1);G_Node.*ones(SolderNo,1);G_ProbeOrg*ones(NX+1-SolderNo-CableNo,1)];
C=[C_Cable.*ones(CableNo,1);C_Node.*ones(SolderNo,1);C_Probe*ones(NX+1-SolderNo-CableNo,1)];
G_ArrayOrg=G;

% %%%%%%%%%%%%%%%%%%%%%%%%
% NumNode=min(NX+1,ceil(0*ceil(NX+1-SolderNo-CableNo)+SolderNo+CableNo));
% for n=SolderNo+CableNo+1:NumNode
%     G(n,1)=pi*3.0/acosh(PropDist/PropDiam).*AdjustFactor./10;
% end
% for n=NumNode+1:NX+1
%     G(n,1)=pi*1.0/acosh(PropDist/PropDiam).*AdjustFactor./10;
% end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%


DevisionTimeArraySimu(1)=2*AddT+2*ceil(CableL*sqrt(L_Cable*C_Cable)/dt)+2*ceil(SolderL*sqrt(L_Node*C_Node)/dt);
for k=2:NoDevision+1
    DevisionTimeArraySimu(k)=DevisionTimeArraySimu(k-1)+2*ceil(ProbeL*sqrt(L_Probe*C_Probe)/dt/NoDevision);
end
DevisionTimeArrayMeas=ceil((DevisionTimeArraySimu-2*AddT).*dt./TimeInterval./2);

%CostFunVar=ones(2,1);
GRes=ones(NoDevision,1);
CheckSection=1;
InitialIterStep=1;
BigOrSmallSign=[0,0];
RefineCheck=0;
G=G_ArrayOrg;

SolderReach=0;
TimeSolderReach=0;

IterMaxCount=0;

while(1)
        
    if(InitialIterStep==1)
        GTemp=G_ProbeOrg;
        GTemp3=G_ProbeOrg;
        IterMaxCount=0;
    end
    
    IterMaxCount=IterMaxCount+1;
    
    Matrix_1=zeros(NX+1,3);
    Matrix_2=zeros(NX+1,1);
    
    % Assemble the matrix
    % x=0 source load
    Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
    Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
    % intermediate point
    a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
    b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
    d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
    Matrix_1(2:NX,1)=1./dx./dx./a;
    Matrix_1(2:NX,2)=b./a;
    Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
    Matrix_2(2:NX,1)=d./a;
    % x=NX+1 loading load
    Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
    Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);
    
    V=zeros(NX+1,3);
    WaveFormSimu=zeros(TotalTimeStep+1,1);
    
    k=CheckSection;
    if(k<NoDevision)
        TotalTimeStepThis=DevisionTimeArraySimu(k+2);
    else
        TotalTimeStepThis=ceil(0.5*DevisionTimeArraySimu(k+1)+0.5*TotalTimeStep);
    end
    
% %%%%%%%%%%%%%%%%%%%%
% TotalTimeStepThis=TotalTimeStep;
% %%%%%%%%%%%%%%%%%%%%%%
           
    if(SolderReach==0)
        for T=1:TotalTimeStepThis+1
            Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
            V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
            for n=2:NX
                V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
            end
            V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
            V(:,3)=V(:,2);
            V(:,2)=V(:,1);
            WaveFormSimu(T,1)=V(1,1);
            if(V(CableNo+SolderNo,1)>0&&SolderReach==0)
                TimeSolderReach=T;
                VSolderReach=V;
                SolderReach=1;
                WaveFormSimuSolderReach=WaveFormSimu(1:T,1);
            end
        end
    else
        NXSolderReach=size(VSolderReach,1);
        if(NXSolderReach==NX+1)
            V=VSolderReach;
        elseif(NXSolderReach>NX+1)
            V=VSolderReach(1:NX+1,:);
        else
            V(1:NXSolderReach,:)=VSolderReach;
        end
        WaveFormSimu(1:TimeSolderReach,1)=WaveFormSimuSolderReach;
        % start the time iteration
        for T=TimeSolderReach+1:TotalTimeStepThis+1
            Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
            V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
            for n=2:NX
                V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
            end
            V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
            V(:,3)=V(:,2);
            V(:,2)=V(:,1);
            WaveFormSimu(T,1)=V(1,1);
        end
    end
    
    
    FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
    BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
    WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
    TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
    WaveFormSimuInterpolate=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:DataWidth-1]');
   
    if(k==1&&NoDevision>1)
        CompareLeft=floor(DevisionTimeArrayMeas(k)+0.4*(DevisionTimeArrayMeas(k+1)-DevisionTimeArrayMeas(k)));
        CompareRight=DevisionTimeArrayMeas(k+1);
        CompareFrac1=0.0;
        CompareFrac2=0.75;
    elseif(k==NoDevision)
        CompareLeft=DevisionTimeArrayMeas(k);
        CompareRight=ceil(DevisionTimeArrayMeas(k)+0.90*(DevisionTimeArrayMeas(k+1)-DevisionTimeArrayMeas(k)));
        CompareFrac1=0.5;
        CompareFrac2=0.90;
    else
        CompareLeft=DevisionTimeArrayMeas(k);
        CompareRight=DevisionTimeArrayMeas(k+1);
        CompareFrac1=0.4;
        CompareFrac2=0.85;
    end
    
    DataMasure=WaveForm(CompareLeft:CompareRight);
    DataSimu=WaveFormSimuInterpolate(CompareLeft:CompareRight);
    lengthSample=length(DataMasure);
    diffData=zeros(lengthSample,1);
    diffDataLater=zeros(lengthSample,1);
    diffDeriLater=zeros(lengthSample,1);
    range=floor(lengthSample*CompareFrac1);
    rangeLater=floor(lengthSample*CompareFrac2);
    DataMasureDiff=diff(DataMasure);
    DataSimuDiff=diff(DataSimu);
    % we use arctan as the kernel, maybe changed to other kernel (sigmond)
    for i=range+1:lengthSample
        diffData(i)=atan(2.5*(i-range)/lengthSample)*(DataSimu(i)-DataMasure(i));
    end
    for i=rangeLater+1:lengthSample
        diffDataLater(i)=DataSimu(i)-DataMasure(i);
    end
    for i=rangeLater+1:lengthSample-1
        diffDeriLater(i)=atan(1.1.*(i-range)/lengthSample)*(DataSimuDiff(i)-DataMasureDiff(i));
    end
    majorDiff=sum(diffData);
    laterDeri=sum(diffDeriLater)/(lengthSample-1-rangeLater);
    laterDiffSlopeInter=polyfit(rangeLater+1:lengthSample,diffDataLater(rangeLater+1:lengthSample),1);
    laterDiff=abs(laterDiffSlopeInter(2)/laterDiffSlopeInter(1))-lengthSample;
%    laterDiff=sum(sign(diffDataLater));
    DiffBeforeFitting=sum(abs(diffDataLater));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %           figure(1)
    %           hold on
    %           plot([0:lengthSample-1],DataSimu,'r')
    %           plot([0:lengthSample-1],DataMasure,'b')
    %           hold off
    
    if(IterMaxCount>=200)
        RefineCheck=1;
        InitialIterStep=-2;
    end
    
    if(InitialIterStep==1)
        if(majorDiff>0)
            BigOrSmallSign(1)=1;
        elseif(majorDiff<0)
            BigOrSmallSign(1)=-1;
        else
            BigOrSmallSign(1)=0;
        end
        InitialIterStep=2;
    end
    if(InitialIterStep==2)
        if(BigOrSmallSign(1)==1)
            if(majorDiff>=0)
                %%%%%%%%%%%%%%%%%%
                minG=min(G(DevisionArray(k):DevisionArray(k+1)));
                if(minG<1e-4)
                    G(DevisionArray(k):DevisionArray(k+1))=2.*G(DevisionArray(k):DevisionArray(k+1))+0.0001;
                else
                    G(DevisionArray(k):DevisionArray(k+1))=2.*G(DevisionArray(k):DevisionArray(k+1));
                end
                %%%%%%%%                    G(DevisionArray(k):DevisionArray(k+1))=2.*G(DevisionArray(k):DevisionArray(k+1))+0.1;
            else
                GTemp2=median(G(DevisionArray(k):DevisionArray(k+1)));
                InitialIterStep=0;
                BigOrSmallSign(2)=-1;
            end
        elseif(BigOrSmallSign(1)==-1)
            if(majorDiff<=0)
                if(median(G(DevisionArray(k):DevisionArray(k+1)))<1e-4)
                    if(k>1)
                        G(DevisionArray(k):DevisionArray(k+1))=G_ProbeOrg;
                        G(DevisionArray(k-1):DevisionArray(k))=0.99.*G(DevisionArray(k-1):DevisionArray(k));
                    else
                        G(DevisionArray(k):DevisionArray(k+1))=1e-4;
                        %%%%%%                           RefineCheck=1;
                        %%%%%%                           InitialIterStep=1;
                        InitialIterStep=3;
                    end
                else
                    G(DevisionArray(k):DevisionArray(k+1))=0.5.*G(DevisionArray(k):DevisionArray(k+1));
                end
            else
                GTemp2=median(G(DevisionArray(k):DevisionArray(k+1)));
                InitialIterStep=0;
                BigOrSmallSign(2)=1;
            end
        else
            GTemp2=GTemp;
            InitialIterStep=0;
            BigOrSmallSign(2)=0;
        end
    end
    if(InitialIterStep==0)
        InitialIterStep=-1;
        if(abs(GTemp2-GTemp)/abs(GTemp2+GTemp)>0.00001)
            GTemp3=(GTemp+GTemp2)./2;
            G(DevisionArray(k):DevisionArray(k+1))=GTemp3.*ones(size(G(DevisionArray(k):DevisionArray(k+1))));
            continue
        else
            GTemp3=(GTemp+GTemp2)./2;
            G(DevisionArray(k):DevisionArray(k+1))=GTemp3.*ones(size(G(DevisionArray(k):DevisionArray(k+1))));
            if(CheckSection==NoDevision)
                %%%%%%                           RefineCheck=1;
                %%%%%%                           InitialIterStep=1;
                InitialIterStep=3;
            else
                %%%%%%                           RefineCheck=1;
                %%%%%%                           InitialIterStep=1;
                InitialIterStep=3;
            end
        end
    end
    if(InitialIterStep==-1)
        if(majorDiff>0)
            if(sum(BigOrSmallSign==[1,-1])==2)
                GTemp=GTemp3;
            elseif(sum(BigOrSmallSign==[-1,1])==2)
                GTemp2=GTemp3;
            end
        elseif(majorDiff<0)
            if(sum(BigOrSmallSign==[1,-1])==2)
                GTemp2=GTemp3;
            elseif(sum(BigOrSmallSign==[-1,1])==2)
                GTemp=GTemp3;
            end
        else
            GTemp=GTemp3;
            GTemp2=GTemp3;
        end
        if(abs(GTemp2-GTemp)/abs(GTemp2+GTemp)>0.00001)
            GTemp3=(GTemp+GTemp2)./2;
            G(DevisionArray(k):DevisionArray(k+1))=GTemp3.*ones(size(G(DevisionArray(k):DevisionArray(k+1))));
            continue
        else
            GTemp3=(GTemp+GTemp2)./2;
            G(DevisionArray(k):DevisionArray(k+1))=GTemp3.*ones(size(G(DevisionArray(k):DevisionArray(k+1))));
            if(CheckSection==NoDevision)
                %%%%%%                           RefineCheck=1;
                InitialIterStep=3;
            else
                %%%%%%                           RefineCheck=1;
                InitialIterStep=3;
            end
        end
    end
    
    
    %%%%%%%%%%%%%%%%%%%
    % Here we see the derivative
    if(InitialIterStep==3)
        if(abs(laterDeri)<1e-6)
        else
            if(laterDeri<0)
                if(laterDiff<=0)
                    if(GTemp3<1e-4)
                        RefineCheck=1;
                    else
                        %%%%%%%%%%%%%%%
                        GTemp3=0.95*GTemp3;
                        
%%%%%%%%%%%%%%%%
%                        GTemp3=0.0678
                        G(DevisionArray(k):DevisionArray(k+1))=GTemp3.*ones(size(G(DevisionArray(k):DevisionArray(k+1))));
                        continue
                    end
                end
            end
            if(laterDeri>0)
                if(laterDiff<=0)
                    if(GTemp3<1e-4)
                        GTemp3=GTemp3+1e-4;
                    else
                        %%%%%%%%%%%%%%%
                        GTemp3=1.04*GTemp3;
                        G(DevisionArray(k):DevisionArray(k+1))=GTemp3.*ones(size(G(DevisionArray(k):DevisionArray(k+1))));
                        continue
                    end
                end
            end
        end
        RefineCheck=1;
        GRes(k,1)=GTemp3;
    end
    
    if(RefineCheck==1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           figure(1)
%           plot([0:lengthSample-1],DataSimu,'r')
%           hold on
%           plot([0:lengthSample-1],DataMasure,'b')
        
        NoRefine=100;
        IntervalRefine=(GTemp3*0.8)/NoRefine;
        GTempArray=GTemp3*0.6:IntervalRefine:GTemp3*1.4;
        NoRefine=length(GTempArray);
        CorrCoefArray=ones(NoRefine,1);
        CorrCoefArrayDiff=ones(NoRefine,1);
        DiffCoefArray=ones(NoRefine,1);
        
        laterDiffArray=ones(NoRefine,1);
        
% start parallel
    AnyPar=gcp('nocreate');
    if(isempty(AnyPar))
        ParFit=parpool('local');
        handles.ParFit=ParFit;
        guidata(hObject, handles);  
    end
% start the pool
            
    parfor rek=1:NoRefine
        Gtest=G;
        Gtest(DevisionArray(k):DevisionArray(k+1))=GTempArray(rek).*ones(size(G(DevisionArray(k):DevisionArray(k+1))));
        Matrix_1=zeros(NX+1,3);
        Matrix_2=zeros(NX+1,1);
        
        % Assemble the matrix
        % x=0 source load
        Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
        Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
        % intermediate point
        a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*Gtest(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
        b=-2./dx./dx-R(2:NX,1).*Gtest(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*Gtest(2:NX,1))./dt;
        d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
        Matrix_1(2:NX,1)=1./dx./dx./a;
        Matrix_1(2:NX,2)=b./a;
        Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
        Matrix_2(2:NX,1)=d./a;
        % x=NX+1 loading load
        Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
        Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);
        
        V=zeros(NX+1,3);
        WaveFormSimu=zeros(TotalTimeStep+1,1);
        
        NXSolderReach=size(VSolderReach,1);
        if(NXSolderReach==NX+1)
            V=VSolderReach;
        elseif(NXSolderReach>NX+1)
            V=VSolderReach(1:NX+1,:);
        else
            V(1:NXSolderReach,:)=VSolderReach;
        end
        WaveFormSimu(1:TimeSolderReach,1)=WaveFormSimuSolderReach;
        % start the time iteration
        for T=TimeSolderReach+1:TotalTimeStepThis+1
            Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
            V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
            for n=2:NX
                V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
            end
            V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
            V(:,3)=V(:,2);
            V(:,2)=V(:,1);
            WaveFormSimu(T,1)=V(1,1);
        end
        
        FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
        BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
        WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
        TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
        TimeframeInterpolate=[0:250]';
        WaveFormSimuInterpolate=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),TimeframeInterpolate);
        
        
        %%%%%%%%%%%%%%%%%%%%%
        
        DataMasure=WaveForm(CompareLeft:CompareRight);
        DataSimu=WaveFormSimuInterpolate(CompareLeft:CompareRight);
        lengthSample=length(DataMasure);
        diffDataLater=zeros(lengthSample,1);
        diffDeriLater=zeros(lengthSample,1);
        DataMasureDiff=diff(DataMasure);
        DataSimuDiff=diff(DataSimu);
        % we use arctan as the kernel, maybe changed to other kernel (sigmond)
%        overDiffMed=median(DataSimu-DataMasure');
        for i=rangeLater+1:lengthSample
            diffDataLater(i)=DataSimu(i)-DataMasure(i);
        end
        for i=rangeLater+1:lengthSample-1
            diffDeriLater(i)=atan(1.1.*(i-range)/lengthSample)*(DataSimuDiff(i)-DataMasureDiff(i));
        end
        laterDeri=sum(diffDeriLater)/(lengthSample-1-rangeLater);
        laterDiffSlopeInter=polyfit(rangeLater+1:lengthSample,diffDataLater(rangeLater+1:lengthSample),1);
        laterDiff=abs(laterDiffSlopeInter(2)/laterDiffSlopeInter(1))-lengthSample;
%       laterDiff=sum(sign(diffDataLater));
        DiffBeforeRefine=sum(abs(diffDataLater));
        %%%%%%%%%%%%%%%%%%%%%
        laterDiffArray(rek)=laterDiff;
        
        covMatrix=corrcoef(WaveFormSimuInterpolate(DevisionTimeArrayMeas(k):DevisionTimeArrayMeas(k+1))',...
            WaveForm(DevisionTimeArrayMeas(k):DevisionTimeArrayMeas(k+1)));
        CorrCoefArray(rek)=covMatrix(2);
        
        if(k==NoDevision&&NoDevision>1)
            covMatrix=corrcoef(WaveFormSimuInterpolate(CompareLeft:DevisionTimeArrayMeas(k+1))',...
                WaveForm(CompareLeft:DevisionTimeArrayMeas(k+1)));
            CorrCoefArrayDiff(rek)=covMatrix(2);
            
            diffMatrix=sum(abs(WaveFormSimuInterpolate(CompareLeft:DevisionTimeArrayMeas(k+1))'-...
                WaveForm(CompareLeft:DevisionTimeArrayMeas(k+1))));
            DiffCoefArray(rek)=diffMatrix;
        else
            diffMatrix=sum(abs(WaveFormSimuInterpolate(CompareLeft:CompareRight)'-...
                WaveForm(CompareLeft:CompareRight)));
            DiffCoefArray(rek)=diffMatrix;
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%
        if(DiffBeforeRefine>=10*DiffBeforeFitting)
            CorrCoefArray(rek)=-100;
            if(k==NoDevision&&NoDevision>1)
                CorrCoefArrayDiff(rek)=-100;
            end
        end
        
%         if(rek==51)
%             aaa=1;
%         end
      
        if(abs(laterDeri)<1e-6)
        else
            if(laterDeri<0&&laterDiff<=0)
                CorrCoefArray(rek)=-100;
                if(k==NoDevision&&NoDevision>1)
                    CorrCoefArrayDiff(rek)=-100;
                else
                    DiffCoefArray(rek)=5000;
                end
            elseif(laterDeri>0&&laterDiff<=0)
                CorrCoefArray(rek)=-100;
                if(k==NoDevision&&NoDevision>1)
                    CorrCoefArrayDiff(rek)=-100;
                else
                    DiffCoefArray(rek)=5000;
                end
%             elseif(laterDeri>0&&overDiffMed>0)
%                 CorrCoefArray(rek)=-100;
%                 if(k==NoDevision&&NoDevision>1)
%                     CorrCoefArrayDiff(rek)=-100;
%                 else
%                     DiffCoefArray(rek)=5000;
%                 end
%             elseif(laterDeri<0&&overDiffMed<0)
%                 CorrCoefArray(rek)=-100;
%                 if(k==NoDevision&&NoDevision>1)
%                     CorrCoefArrayDiff(rek)=-100;
%                 else
%                     DiffCoefArray(rek)=5000;
%                 end
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%
        
    end
    
    CorrCoefArrayMax=find(CorrCoefArray>=max(CorrCoefArray));CorrCoefArrayMax=CorrCoefArrayMax(1);
    GResCorr=GTempArray(CorrCoefArrayMax);
    if(k==NoDevision&&NoDevision>1)
      CorrCoefArrayMax=find(CorrCoefArrayDiff>=max(CorrCoefArrayDiff));CorrCoefArrayMax=CorrCoefArrayMax(1);
      GResDiff1=GTempArray(CorrCoefArrayMax);
      
      DiffCoefArrayMax=find(DiffCoefArray<=min(DiffCoefArray));DiffCoefArrayMax=DiffCoefArrayMax(1);
      GResDiff2=GTempArray(DiffCoefArrayMax);
      
      GResDiff=GResDiff2;
    else
      DiffCoefArrayMax=find(DiffCoefArray<=min(DiffCoefArray));DiffCoefArrayMax=DiffCoefArrayMax(1);
      GResDiff=GTempArray(DiffCoefArrayMax);
    end
%    laterDiffArray;
    meanGRefine=0.5*(GResCorr+GResDiff);
    stdGRefine=abs(GResCorr-GResDiff);
    varGRefine=stdGRefine/meanGRefine;
    varGRefine2=stdGRefine/GResDiff;
    GRes(k,1)=median([GResCorr,GResDiff,GTemp3]);
    
    if(NoDevision==1)
        GRes(k,1)=GResDiff;
    else
        if(varGRefine<0.01)
            GRes(k,1)=meanGRefine;
        elseif(k==1&&NoDevision>1)
            GRes(k,1)=0.9*min(GResCorr,GResDiff)+0.1*max(GResCorr,GResDiff);
        elseif(k==NoDevision)
            if(GRes(k-1,1)>=GResDiff)
                GRes(k,1)=0.8*max(GResCorr,GResDiff)+0.2*min(GResCorr,GResDiff);
            else
%                GRes(k,1)=0.8*max(GResCorr,GResDiff)+0.2*min(GResCorr,GResDiff);
                GRes(k,1)=0.65*min(GResCorr,GResDiff)+0.35*max(GResCorr,GResDiff);
            end
        else
            if(GRes(k-1,1)>=GResDiff)
                GRes(k,1)=0.7*max(GResCorr,GResDiff)+0.3*min(GResCorr,GResDiff);
            else
%                GRes(k,1)=0.8*max(GResCorr,GResDiff)+0.2*min(GResCorr,GResDiff);
                GRes(k,1)=0.7*min(GResCorr,GResDiff)+0.3*max(GResCorr,GResDiff);
            end
        end
    end
    G(DevisionArray(k):DevisionArray(k+1))=GRes(k,1).*ones(size(G(DevisionArray(k):DevisionArray(k+1))));
    
            
    RefineCheck=0;
    if(CheckSection==NoDevision)
        break;
    else
        CheckSection=CheckSection+1;
        InitialIterStep=1;
    end
    end
end
    
%     if(NoDevision>1)
%         CostFunVar(costk)=sum(abs(diff(GRes(costk,:))));
%     end
% %%%%%%%%%%%%%%%%%%%%%%%%%%
% %   CostFunVar(2)=50000;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%
% end

% if(NoDevision>1)
%     RefVar=abs(diff(CostFunVar)/min(CostFunVar));
%     if(RefVar<0.2)
%         GTarget=mean(GRes,1);
%     else
%         VarMin=find(CostFunVar<=min(CostFunVar));
%         VarMin=floor(mean(VarMin));
%         GTarget=mean(GRes(VarMin,:),1);
%     end
% else
% %    GTarget=mean(GRes(1,:),1);
%     GTarget=mean(GRes);
% end
GTarget=GRes;
ECFit=zeros(1,50);
for k=1:NoDevision
    ECFit(1,k)=GTarget(k).*acosh(handles.PropDist/handles.PropDiam)./AdjustFactor.*10./pi;
    G(DevisionArray(k):DevisionArray(k+1))=GTarget(k);
end

handles.WaveformData_EC_Fitted(WaveNum,:)=ECFit;

% finally fit the waveform for shown
Matrix_1=zeros(NX+1,3);
Matrix_2=zeros(NX+1,1);

% Assemble the matrix
% x=0 source load
Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
% intermediate point
a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
Matrix_1(2:NX,1)=1./dx./dx./a;
Matrix_1(2:NX,2)=b./a;
Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
Matrix_2(2:NX,1)=d./a;
% x=NX+1 loading load
Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

V=zeros(NX+1,3);
WaveFormSimu=zeros(TotalTimeStep+1,1);

% start the time iteration
for T=1:TotalTimeStep+1
    Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
    V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
    for n=2:NX
        V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
    end
    V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
    V(:,3)=V(:,2);
    V(:,2)=V(:,1);
    WaveFormSimu(T,1)=V(1,1);
end

FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;

X=0:DataWidth-1;
WaveFormSimuFinal=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),X)+RCoef0;
handles.Waveform_Fitted(WaveNum,:)=WaveFormSimuFinal;

axes(handles.PIC_TDR_INV)
hold on

handles.STEP3PLOTBTCWAVEFIT=plot(X,WaveFormSimuFinal,'r--','linewidth',1);
set(handles.PIC_TDR_INV,'xTick',[]);
set(handles.PIC_TDR_INV,'yTick',[]);
box on

guidata(hObject, handles)
toc

ECFit(1:4)



function EDT_FITTING_BTC_INDEX_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_BTC_INDEX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_FITTING_BTC_INDEX as text
%        str2double(get(hObject,'String')) returns contents of EDT_FITTING_BTC_INDEX as a double


% --- Executes during object creation, after setting all properties.
function EDT_FITTING_BTC_INDEX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_BTC_INDEX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_FITTING_BTC_MAXITER_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_BTC_MAXITER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_FITTING_BTC_MAXITER as text
%        str2double(get(hObject,'String')) returns contents of EDT_FITTING_BTC_MAXITER as a double


% --- Executes during object creation, after setting all properties.
function EDT_FITTING_BTC_MAXITER_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_BTC_MAXITER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_FITTING_NO_DEVISION_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_NO_DEVISION (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_FITTING_NO_DEVISION as text
%        str2double(get(hObject,'String')) returns contents of EDT_FITTING_NO_DEVISION as a double


% --- Executes during object creation, after setting all properties.
function EDT_FITTING_NO_DEVISION_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_NO_DEVISION (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PB_BTC_FITTING_NEXT.
function PB_BTC_FITTING_NEXT_Callback(hObject, eventdata, handles)
% hObject    handle to PB_BTC_FITTING_NEXT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    Index=str2double(get(handles.EDT_FITTING_BTC_INDEX,'string'));
    if(Index>=handles.BtcWaveNum)
        Index=handles.BtcWaveNum;
        set(handles.EDT_FITTING_BTC_INDEX,'string',num2str(Index));
        BtcWaveNum=handles.DataLength;
        Waveform=handles.WaveformData(BtcWaveNum,:);
        if(handles.STEP3PLOTWATERWAVE~=0)
            delete(handles.STEP3PLOTWATERWAVE);
 %           for n=1:handles.WaterWaveNum
 %               delete(handles.STEP3PLOTWATERWAVE(n));
 %           end
            handles.STEP3PLOTWATERWAVE=0;
        end
        if(handles.STEP3PLOTWATERWAVEFIT~=0)
            delete(handles.STEP3PLOTWATERWAVEFIT);
            handles.STEP3PLOTWATERWAVEFIT=0;
        end
        if(handles.STEP3PLOTBTCWAVE~=0)
            delete(handles.STEP3PLOTBTCWAVE);
            handles.STEP3PLOTBTCWAVE=0;
        end
        if(handles.STEP3PLOTBTCWAVEFIT~=0)
            delete(handles.STEP3PLOTBTCWAVEFIT);
            handles.STEP3PLOTBTCWAVEFIT=0;
        end
        guidata(hObject, handles)
        
        axes(handles.PIC_TDR_INV)
        hold on
        
        X=0:handles.DataWidth-1;
        handles.STEP3PLOTBTCWAVE=plot(X,Waveform,'b','linewidth',1);
        set(handles.PIC_TDR_INV,'xTick',[]);
        set(handles.PIC_TDR_INV,'yTick',[]);
        box on
        guidata(hObject, handles)
    else
        Index=Index+1;
        set(handles.EDT_FITTING_BTC_INDEX,'string',num2str(Index));
        BtcWaveNum=handles.WaterWaveNum+Index;
        Waveform=handles.WaveformData(BtcWaveNum,:);
        if(handles.STEP3PLOTWATERWAVE~=0)
            delete(handles.STEP3PLOTWATERWAVE);
%             for n=1:handles.WaterWaveNum
%                 delete(handles.STEP3PLOTWATERWAVE(n));
%             end
            handles.STEP3PLOTWATERWAVE=0;
        end
        if(handles.STEP3PLOTWATERWAVEFIT~=0)
            delete(handles.STEP3PLOTWATERWAVEFIT);
            handles.STEP3PLOTWATERWAVEFIT=0;
        end
        if(handles.STEP3PLOTBTCWAVE~=0)
            delete(handles.STEP3PLOTBTCWAVE);
            handles.STEP3PLOTBTCWAVE=0;
        end
        if(handles.STEP3PLOTBTCWAVEFIT~=0)
            delete(handles.STEP3PLOTBTCWAVEFIT);
            handles.STEP3PLOTBTCWAVEFIT=0;
        end
        guidata(hObject, handles)
        
        axes(handles.PIC_TDR_INV)
        hold on
        
        X=0:handles.DataWidth-1;
        handles.STEP3PLOTBTCWAVE=plot(X,Waveform,'b','linewidth',1);  
        set(handles.PIC_TDR_INV,'xTick',[]);
        set(handles.PIC_TDR_INV,'yTick',[]);
        box on
        guidata(hObject, handles)
    end    

% --- Executes on button press in PB_BTC_FITTING_PREVIOUS.
function PB_BTC_FITTING_PREVIOUS_Callback(hObject, eventdata, handles)
% hObject    handle to PB_BTC_FITTING_PREVIOUS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    Index=str2double(get(handles.EDT_FITTING_BTC_INDEX,'string'));
    if(Index<=1)
        Index=1;
        set(handles.EDT_FITTING_BTC_INDEX,'string',num2str(Index));
        BTCWaveNum=handles.WaterWaveNum+Index;
        Waveform=handles.WaveformData(BTCWaveNum,:);
        if(handles.STEP3PLOTWATERWAVE~=0)
            delete(handles.STEP3PLOTWATERWAVE);
 %           for n=1:handles.WaterWaveNum
 %               delete(handles.STEP3PLOTWATERWAVE(n));
 %           end
            handles.STEP3PLOTWATERWAVE=0;
        end
        if(handles.STEP3PLOTWATERWAVEFIT~=0)
            delete(handles.STEP3PLOTWATERWAVEFIT);
            handles.STEP3PLOTWATERWAVEFIT=0;
        end
        if(handles.STEP3PLOTBTCWAVE~=0)
            delete(handles.STEP3PLOTBTCWAVE);
            handles.STEP3PLOTBTCWAVE=0;
        end
        if(handles.STEP3PLOTBTCWAVEFIT~=0)
            delete(handles.STEP3PLOTBTCWAVEFIT);
            handles.STEP3PLOTBTCWAVEFIT=0;
        end
        guidata(hObject, handles)
        
        axes(handles.PIC_TDR_INV)
        hold on
        
        X=0:handles.DataWidth-1;
        handles.STEP3PLOTBTCWAVE=plot(X,Waveform,'b','linewidth',1); 
        
        set(handles.PIC_TDR_INV,'xTick',[]);
        set(handles.PIC_TDR_INV,'yTick',[]);
        box on
        guidata(hObject, handles)
    else
        Index=Index-1;
        set(handles.EDT_FITTING_BTC_INDEX,'string',num2str(Index));
        BTCWaveNum=handles.WaterWaveNum+Index;
        Waveform=handles.WaveformData(BTCWaveNum,:);
        if(handles.STEP3PLOTWATERWAVE~=0)
            delete(handles.STEP3PLOTWATERWAVE);
 %           for n=1:handles.WaterWaveNum
 %               delete(handles.STEP3PLOTWATERWAVE(n));
 %           end
            handles.STEP3PLOTWATERWAVE=0;
        end
        if(handles.STEP3PLOTWATERWAVEFIT~=0)
            delete(handles.STEP3PLOTWATERWAVEFIT);
            handles.STEP3PLOTWATERWAVEFIT=0;
        end
        if(handles.STEP3PLOTBTCWAVE~=0)
            delete(handles.STEP3PLOTBTCWAVE);
            handles.STEP3PLOTBTCWAVE=0;
        end
        if(handles.STEP3PLOTBTCWAVEFIT~=0)
            delete(handles.STEP3PLOTBTCWAVEFIT);
            handles.STEP3PLOTBTCWAVEFIT=0;
        end
        guidata(hObject, handles)
        
        axes(handles.PIC_TDR_INV)
        hold on
        
        X=0:handles.DataWidth-1;
        handles.STEP3PLOTBTCWAVE=plot(X,Waveform,'b','linewidth',1);    
        
        set(handles.PIC_TDR_INV,'xTick',[]);
        set(handles.PIC_TDR_INV,'yTick',[]);
        box on
        guidata(hObject, handles)
    end


% --- Executes on button press in PB_SHOW_WATER_WAVE.
function PB_SHOW_WATER_WAVE_Callback(hObject, eventdata, handles)
% hObject    handle to PB_SHOW_WATER_WAVE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    set(handles.EDT_FITTING_WATER_R_SOURCE,'string',num2str(handles.ResisSource));
    set(handles.EDT_FITTING_WATER_R_LOAD,'string',num2str(handles.ResisLoad));
    set(handles.EDT_FITTING_WATER_RELAPERM,'string',...
        num2str(mean(handles.WaveformData_Prem(1:handles.WaterWaveNum,1))));
    set(handles.EDT_FITTING_WATER_EC,'string',...
        num2str(mean(handles.WaveformData_EC(1:handles.WaterWaveNum,1))));

% need to clean previous plot if possible

    Waveform=handles.WaveformData(1:handles.WaterWaveNum,:);
    if(handles.STEP3PLOTWATERWAVE~=0)
        delete(handles.STEP3PLOTWATERWAVE)
        handles.STEP3PLOTWATERWAVE=0;
    end
    if(handles.STEP3PLOTWATERWAVEFIT~=0)
        delete(handles.STEP3PLOTWATERWAVEFIT);
        handles.STEP3PLOTWATERWAVEFIT=0;
    end
    if(handles.STEP3PLOTBTCWAVE~=0)
        delete(handles.STEP3PLOTBTCWAVE);
        handles.STEP3PLOTBTCWAVE=0;
    end
    if(handles.STEP3PLOTBTCWAVEFIT~=0)
        delete(handles.STEP3PLOTBTCWAVEFIT);
        handles.STEP3PLOTBTCWAVEFIT=0;
    end
    guidata(hObject, handles)
    
    axes(handles.PIC_TDR_INV)
    hold on
        
    X=0:handles.DataWidth-1;
    handles.STEP3PLOTWATERWAVE=plot(X,Waveform,'b','linewidth',1); 
    set(handles.PIC_TDR_INV,'xTick',[]);
    set(handles.PIC_TDR_INV,'yTick',[]);
    box on
    guidata(hObject, handles);


% --- Executes on button press in PB_FITTING_WATER_WAVE.
function PB_FITTING_WATER_WAVE_Callback(hObject, eventdata, handles)
tic
% hObject    handle to PB_FITTING_WATER_WAVE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% need to convert all the unit into SI unit

WaterNum=handles.WaterWaveNum;
if(WaterNum==1)
    WaveForm=handles.WaveformData(1,:);
    MinLoc=find(WaveForm<=min(WaveForm)); MinLoc=MinLoc(1);
    FirstRef=handles.WaveformData_Ref1(1,:);
    SecondRef=handles.WaveformData_Ref2(1,:);
    RelaPermit=handles.WaveformData_Prem(1,1);
    EC=handles.WaveformData_EC(1,1); 
else
    WaveForm=mean(handles.WaveformData(1:WaterNum,:));
    MinLoc=find(WaveForm<=min(WaveForm)); MinLoc=MinLoc(1);
    FirstRef=mean(handles.WaveformData_Ref1(1:WaterNum,:));
    SecondRef=mean(handles.WaveformData_Ref2(1:WaterNum,:));
    RelaPermit=mean(handles.WaveformData_Prem(1:WaterNum,1));
    EC=mean(handles.WaveformData_EC(1:WaterNum,1));                       % unit in mS dm^-1
end
Permit=RelaPermit*handles.RELATIVEPERMITTIVITY_0;
DataWidth=handles.DataWidth;

ProbeL=handles.ProbeLength/1000;
TimeInterval=handles.TimeInterval;

RCoef0=median(WaveForm(1:ceil(FirstRef)));
WaveForm=WaveForm-RCoef0;
RCoefN=max(WaveForm(floor(FirstRef):ceil(SecondRef)));
MaxLoc=find(WaveForm>=RCoefN); MaxLoc=MaxLoc(1);

VeloProbe=ProbeL/((SecondRef-FirstRef)*TimeInterval);

%**********************************************************************
% STEP ONE
% Let the signal raise correctly.
% this step is to compromise the arbitraty wire length.
%**********************************************************************

CableImped=handles.CableImped;
LightSpeed=handles.LightSpeed;
CablePropVelo=handles.CablePropVelo;
ResisSource=handles.ResisSource;
InputVoltage=handles.InputVoltage;
InputRiseTime=handles.InputRiseTime;

% the cable LC
relative_v=0.01*LightSpeed*CablePropVelo;
L_Cable=CableImped/relative_v;
C_Cable=1/(CableImped*relative_v);

% cast voltage unit from mV to V
Vin=2*CableImped/(ResisSource+CableImped)*InputVoltage/1000;
Rs=CableImped;
beta=1/(InputRiseTime*3);
Vs=@(t) Vin*(1-exp(-beta*t));
dVsdt=@(t) Vin*beta*exp(-beta*t);

% determine an appropriate rising period, this will be added to the left
% side of the cable part
Xdomain=1;             % make it long enough for the first step
dx=0.005;
NX=ceil(Xdomain/dx);
dx=Xdomain/NX;
dt=0.05*dx/LightSpeed;   % this /20=*0.05 is just for numerical stability
TotalTimeStep=ceil(Xdomain/relative_v/dt);

V=zeros(NX+1,3);
Matrix_1=zeros(NX+1,3);
Matrix_2=zeros(NX+1,1);

WaveFormSimu=zeros(TotalTimeStep+1,1);
% use 10% window to make further validation
Window=floor(TotalTimeStep*0.10);

R=zeros(NX+1,1);
L=L_Cable*ones(NX+1,1);
G=zeros(NX+1,1);
C=C_Cable*ones(NX+1,1);
Rl=sqrt(L_Cable/C_Cable)*10.0;

% Assemble the matrix
% x=0 source load
Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
% intermediate point
a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
Matrix_1(2:NX,1)=1./dx./dx./a;
Matrix_1(2:NX,2)=b./a;
Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
Matrix_2(2:NX,1)=d./a;
Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

for T=1:TotalTimeStep+1
    Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
    V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
    for n=2:NX
        V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
    end
    V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
    V(:,3)=V(:,2);
    V(:,2)=V(:,1);
    WaveFormSimu(T,1)=V(1,1);
    if(T>=Window+1)
        if(abs(median(WaveFormSimu(T-Window:T,1))-WaveFormSimu(T,1))<=0.0005)
            break
        end
    end
end

AddL=T*dt*relative_v;
AddT=T;

% store the parameter to the handles.
handles.AdditionalLength=AddL;
handles.AdditionalTime=AddT;
handles.CableParL=L_Cable;
handles.CableParC=C_Cable;
handles.CableParR=0;
handles.CableParG=0;
handles.ResisSourceAdjusted=handles.CableImped;
handles.InputVoltageFunc=Vs;
handles.InputVoltageFuncDiff=dVsdt;
guidata(hObject, handles);

%**********************************************************************
% STEP TWO
% Adjust the cable length.
%**********************************************************************

% determine spatial domain characteristics
CableL=FirstRef*TimeInterval*relative_v;
% made the correct domain length
Xdomain=AddL+CableL+ProbeL;
dx=0.005;
NX=ceil(Xdomain/dx);
dx=Xdomain/NX;
dt=0.05*dx/LightSpeed;   % this /20=*0.05 is just for numerical stability
TotalTimeStep=2*AddT+2*ceil(TimeInterval*(DataWidth-1)/dt);
% the votage matrix (t+1,t,t-1)
V=zeros(NX+1,3);
% the three coefficient matrix
Matrix_1=zeros(NX+1,3);
Matrix_2=zeros(NX+1,1);
WaveFormSimu=zeros(TotalTimeStep+1,1);
% the first jump (determine the cable length)
ImpedenceRatio=(1-RCoefN)/(1+RCoefN);
% the speed ratio
L_Node=L_Cable;
C_Node=C_Cable*ImpedenceRatio*ImpedenceRatio;

% the coefficient matrix
R=zeros(NX+1,1);
L=[L_Cable*ones(floor((AddL+CableL)/dx)+1,1);L_Node*ones(NX+1-(floor((AddL+CableL)/dx)+1),1)];
G=zeros(NX+1,1);
C=[C_Cable*ones(floor((AddL+CableL)/dx)+1,1);C_Node*ones(NX+1-(floor((AddL+CableL)/dx)+1),1)];
Rl=sqrt(L_Node/C_Node)*10.0;

% Assemble the matrix
% x=0 source load
Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
% intermediate point
a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
Matrix_1(2:NX,1)=1./dx./dx./a;
Matrix_1(2:NX,2)=b./a;
Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
Matrix_2(2:NX,1)=d./a;
% x=NX+1 loading load
Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

% start the time iteration
for T=1:TotalTimeStep+1
    Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
    V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
    for n=2:NX
        V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
    end
    V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
    V(:,3)=V(:,2);
    V(:,2)=V(:,1);
    WaveFormSimu(T,1)=V(1,1);
end

time_scale=dt/TimeInterval/2;
FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*time_scale;
TimeframeInterpolate=[0:50:TotalTimeStep-2*AddT]'.*time_scale;
WaveFormSimuInterpolate=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),TimeframeInterpolate);

WaveFormSimuBMO=OneDimensionBMO(OneDimensionBMO(WaveFormSimuInterpolate));
WaveFormSimuBMO=WaveFormSimuBMO'.*(WaveFormSimuInterpolate>=0);
WaveFormSimuBMO=WaveFormSimuBMO.*(WaveFormSimuInterpolate<=1.1*RCoefN);
DiffWaveFormSimu=[0;diff(diff(WaveFormSimuInterpolate));0];
DiffWaveFormSimu=DiffWaveFormSimu.*(WaveFormSimuInterpolate>=0);
DiffWaveFormSimu=DiffWaveFormSimu.*(WaveFormSimuInterpolate<=1.1*RCoefN);

DiffWaveFormSimu=WaveFormSimuBMO.*sign(DiffWaveFormSimu);

MinDiff=find(DiffWaveFormSimu==min(DiffWaveFormSimu)); MinDiff=MinDiff(1);
MaxDiff=find(DiffWaveFormSimu==max(DiffWaveFormSimu(1:MinDiff))); MaxDiff=MaxDiff(1);
FirstRefSimu=TimeframeInterpolate(MaxDiff);
CableL=CableL/FirstRefSimu*FirstRef;

% finish the cable length adjustment
% store the step 2 data to the handles,

handles.NodeParL=L_Node;
handles.NodeParC=C_Node;
handles.NodeParR=0;
handles.NodeParG=0;
handles.CableLength=CableL;
guidata(hObject, handles);

% start to fit the major depression
% amplitude
%    [L_Node,C_Node,Offset,SolderL,Amplifier]=WaterWaveFit1(handles);
% old function waterwavefit2
% simplified and merge the process to the main fitting code
% seek for speed improve
% ---------------------------------------------------------------------

Xdomain=AddL+CableL+ProbeL;
dx=0.005;
NX=ceil(Xdomain/dx);
dx=Xdomain/NX;
dt=0.05*dx/LightSpeed;
TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(DataWidth-1)/dt);

PropDist=handles.PropDist;
PropDiam=handles.PropDiam;

C_Probe=pi*Permit/acosh(PropDist/PropDiam);
L_Probe=1/(VeloProbe^2)/C_Probe;
R_Probe=0;
G_Probe=pi*EC/acosh(PropDist/PropDiam);
Impendence=sqrt(L_Probe/C_Probe);
Rl=Impendence*40.0;

CableNo=floor((AddL+CableL)/dx)+1;

R=R_Probe.*ones(NX+1,1);
L=[L_Cable.*ones(CableNo,1);L_Probe.*ones(NX+1-CableNo,1)];
G=[zeros(CableNo,1);G_Probe.*ones(NX+1-CableNo,1)];
C=[C_Cable.*ones(CableNo,1);C_Probe.*ones(NX+1-CableNo,1)];

V=zeros(NX+1,3);
Matrix_1=zeros(NX+1,3);
Matrix_2=zeros(NX+1,1);
WaveFormSimu=zeros(TotalTimeStep+1,1);

% Assemble the matrix
% x=0 source load
Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
% intermediate point
a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
Matrix_1(2:NX,1)=1./dx./dx./a;
Matrix_1(2:NX,2)=b./a;
Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
Matrix_2(2:NX,1)=d./a;
% x=NX+1 loading load
Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

% start the time iteration
for T=1:TotalTimeStep+1
    Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
    V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
    for n=2:NX
        V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
    end
    V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
    V(:,3)=V(:,2);
    V(:,2)=V(:,1);
    WaveFormSimu(T,1)=V(1,1);
end

FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
TimeFrameSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
WaveFormSimuInterpolate2=interp1(TimeFrameSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:DataWidth-1]);

AmplifierArray=zeros(ceil(SecondRef)-MaxLoc,1);
m=0;
for n=MaxLoc:ceil(SecondRef)
    if(WaveFormSimuInterpolate2(n)~=0)
        m=m+1;
        AmplifierArray(m)=WaveForm(n)/WaveFormSimuInterpolate2(n);
    end
end
Amplifier=median(AmplifierArray(1:m,1));

% add the first jump to the curve
ImpedenceRatio=(1-RCoefN/Amplifier)/(1+RCoefN/Amplifier);
L_Node=L_Cable;
C_Node=C_Cable*ImpedenceRatio*ImpedenceRatio;
MaxIter=101;
CorrCoefArray=zeros(MaxIter,1);

% start the maxiter iteration
CableReach=0;
TimeCableReach=0;

% do the first step separatly such that we can parallel
iter=1;
Offset=2*(iter-1)*(MaxLoc-FirstRef)/(MaxIter-1);
% the speed ratio

SolderL=Offset*TimeInterval/sqrt(L_Node*C_Node);
Xdomain=AddL+CableL+SolderL+ProbeL;
dx=0.005;
NX=ceil(Xdomain/dx);
dx=Xdomain/NX;
dt=0.05*dx/LightSpeed;

% this is only for the water waveforms, may not applied for waveforms in air
CorRight=ceil(0.4*MinLoc+0.6*FirstRef);
TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(CorRight+1)/dt);

% the coefficient matrix
CableNo=floor((AddL+CableL)/dx)+1;
SolderNo=floor((AddL+CableL+SolderL)/dx)+1-CableNo;
R=R_Probe*ones(NX+1,1);
L=[L_Cable.*ones(CableNo,1);L_Node.*ones(SolderNo,1);L_Probe*ones(NX+1-CableNo-SolderNo,1)];
G=[zeros(CableNo+SolderNo,1);G_Probe*ones(NX+1-CableNo-SolderNo,1)];
C=[C_Cable.*ones(CableNo,1);C_Node.*ones(SolderNo,1);C_Probe*ones(NX+1-CableNo-SolderNo,1)];

Matrix_1=zeros(NX+1,3);
Matrix_2=zeros(NX+1,1);

% Assemble the matrix
% x=0 source load
Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
% intermediate point
a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
Matrix_1(2:NX,1)=1./dx./dx./a;
Matrix_1(2:NX,2)=b./a;
Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
Matrix_2(2:NX,1)=d./a;
% x=NX+1 loading load
Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

V=zeros(NX+1,3);
WaveFormSimu=zeros(TotalTimeStep+1,1);

for T=1:TotalTimeStep+1
    Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
    V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
    for n=2:NX
        V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
    end
    V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
    V(:,3)=V(:,2);
    V(:,2)=V(:,1);
    WaveFormSimu(T,1)=V(1,1);
    if(V(CableNo,1)>0&&CableReach==0)
        TimeCableReach=T;
        VCableReach=V;
        CableReach=1;
        WaveFormSimuCableReach=WaveFormSimu(1:T,1);
    end
end

FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
WaveFormSimuInterpolate2=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:CorRight-1]);
CorrCoefMatrix=corrcoef(WaveFormSimuInterpolate2(ceil(FirstRef):CorRight),WaveForm(ceil(FirstRef):CorRight));
CorrCoefArray(iter,1)=CorrCoefMatrix(2);

% start parallel
    AnyPar=gcp('nocreate');
    if(isempty(AnyPar))
        ParFit=parpool('local');
        handles.ParFit=ParFit;
        guidata(hObject, handles);  
    end
% start the pool

parfor iter=1:MaxIter    
    Offset=2*(iter-1)*(MaxLoc-FirstRef)/(MaxIter-1);
    % the speed ratio
    
    SolderL=Offset*TimeInterval/sqrt(L_Node*C_Node);
    Xdomain=AddL+CableL+SolderL+ProbeL;
    dx=0.005;
    NX=ceil(Xdomain/dx);
    dx=Xdomain/NX;
    dt=0.05*dx/LightSpeed;
    
    % this is only for the water waveforms, may not applied for waveforms in air
    CorRight=ceil(0.4*MinLoc+0.6*FirstRef);
    TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(CorRight+1)/dt);
    
    % the coefficient matrix
    CableNo=floor((AddL+CableL)/dx)+1;
    SolderNo=floor((AddL+CableL+SolderL)/dx)+1-CableNo;
    R=R_Probe*ones(NX+1,1);
    L=[L_Cable.*ones(CableNo,1);L_Node.*ones(SolderNo,1);L_Probe*ones(NX+1-CableNo-SolderNo,1)];
    G=[zeros(CableNo+SolderNo,1);G_Probe*ones(NX+1-CableNo-SolderNo,1)];
    C=[C_Cable.*ones(CableNo,1);C_Node.*ones(SolderNo,1);C_Probe*ones(NX+1-CableNo-SolderNo,1)];
    
    Matrix_1=zeros(NX+1,3);
    Matrix_2=zeros(NX+1,1);    
    
    % Assemble the matrix
    % x=0 source load
    Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
    Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
    % intermediate point
    a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
    b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
    d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
    Matrix_1(2:NX,1)=1./dx./dx./a;
    Matrix_1(2:NX,2)=b./a;
    Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
    Matrix_2(2:NX,1)=d./a;
    % x=NX+1 loading load
    Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
    Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);
        
    V=zeros(NX+1,3);
    WaveFormSimu=zeros(TotalTimeStep+1,1);
    

    NXCableReach=size(VCableReach,1);
    if(NXCableReach==NX+1)
        V=VCableReach;
    elseif(NXCableReach>NX+1)
        V=VCableReach(1:NX+1,:);
    else
        V(1:NXCableReach,:)=VCableReach;
    end
    WaveFormSimu(1:TimeCableReach,1)=WaveFormSimuCableReach;
    % start the time iteration
    for T=TimeCableReach+1:TotalTimeStep+1
        Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
        V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
        for n=2:NX
            V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
        end
        V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
        V(:,3)=V(:,2);
        V(:,2)=V(:,1);
        WaveFormSimu(T,1)=V(1,1);
    end

    FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
    BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
    WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
    TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
    WaveFormSimuInterpolate2=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:CorRight-1]);
    CorrCoefMatrix=corrcoef(WaveFormSimuInterpolate2(ceil(FirstRef):CorRight),WaveForm(ceil(FirstRef):CorRight));
    CorrCoefArray(iter,1)=CorrCoefMatrix(2);
    
end

CorrCoefArrayMax=find(CorrCoefArray>=max(CorrCoefArray));CorrCoefArrayMax=CorrCoefArrayMax(1);


% output node L C Offset SolderL Amplifer
Offset=2*(CorrCoefArrayMax-1)*(MaxLoc-FirstRef)/(MaxIter-1);
IterationMax=1;

CableReach=0;
TimeCableReach=0;
while(IterationMax<=20)
    IterationMax=IterationMax+1;
    SolderL=Offset*TimeInterval/sqrt(L_Node*C_Node);
    
    Xdomain=AddL+CableL+SolderL+ProbeL;
    dx=0.005;
    NX=ceil(Xdomain/dx);
    dx=Xdomain/NX;
    dt=0.05.*dx/LightSpeed;
    %       TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(DataWidth-1)/dt);
    %       TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(MinLoc+1)/dt);
    CorRight=ceil(0.4*MinLoc+0.6*FirstRef);
    TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(CorRight+1)/dt);
    
    % the coefficient matrix
    CableNo=floor((AddL+CableL)/dx)+1;
    SolderNo=floor((AddL+CableL+SolderL)/dx)+1-CableNo;
    R=R_Probe*ones(NX+1,1);
    L=[L_Cable.*ones(CableNo,1);L_Node.*ones(SolderNo,1);L_Probe*ones(NX+1-CableNo-SolderNo,1)];
    G=[zeros(CableNo+SolderNo,1);G_Probe*ones(NX+1-CableNo-SolderNo,1)];
    C=[C_Cable.*ones(CableNo,1);C_Node.*ones(SolderNo,1);C_Probe*ones(NX+1-CableNo-SolderNo,1)];
    
    Matrix_1=zeros(NX+1,3);
    Matrix_2=zeros(NX+1,1);
    
    % Assemble the matrix
    % x=0 source load
    Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
    Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
    % intermediate point
    a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
    b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
    d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
    Matrix_1(2:NX,1)=1./dx./dx./a;
    Matrix_1(2:NX,2)=b./a;
    Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
    Matrix_2(2:NX,1)=d./a;
    % x=NX+1 loading load
    Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
    Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);
    
    V=zeros(NX+1,3);
    WaveFormSimu=zeros(TotalTimeStep+1,1);
    
    if(CableReach==0)
        for T=1:TotalTimeStep+1
            Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
            V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
            
            for n=2:NX
                V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
            end
            V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
            V(:,3)=V(:,2);
            V(:,2)=V(:,1);
            WaveFormSimu(T,1)=V(1,1);
            if(V(CableNo,1)>0&&CableReach==0)
                TimeCableReach=T;
                VCableReach=V;
                CableReach=1;
                WaveFormSimuCableReach=WaveFormSimu(1:T,1);
            end
        end
    else
        NXCableReach=size(VCableReach,1);
        if(NXCableReach==NX+1)
            V=VCableReach;
        elseif(NXCableReach>NX+1)
            V=VCableReach(1:NX+1,:);
        else
            V(1:NXCableReach,:)=VCableReach;
        end
        WaveFormSimu(1:TimeCableReach,1)=WaveFormSimuCableReach;
        % start the time iteration
        for T=TimeCableReach+1:TotalTimeStep+1
            % source input at each time step
            Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
            V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
            
            for n=2:NX
                V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
            end
            V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
            V(:,3)=V(:,2);
            V(:,2)=V(:,1);
            WaveFormSimu(T,1)=V(1,1);
        end
    end
    
    FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
    BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
    WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
    TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
    WaveFormSimuInterpolate2=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:CorRight-1]);
    
    error=(max(WaveFormSimuInterpolate2(floor(FirstRef):CorRight))-RCoefN)/abs(RCoefN);
    error1=abs(error);
    if(error1>0.01)
        errorsign=sign(error);
        C_Node=C_Node*(1+errorsign*error1)*(1+errorsign*error1);
    else

        break
    end
end
SolderL=Offset*TimeInterval/sqrt(L_Node*C_Node);
% ---------------------------------------------------------------------------

handles.NodeParL=L_Node;
handles.NodeParC=C_Node;
handles.OffSet=Offset;
handles.SolderLength=SolderL;
handles.Amplifier=Amplifier;
guidata(hObject, handles);

%   [VeloProbe,ProbeLAdjust]=WaterWaveFit2(handles);
% old function waterwavefit2
% simplified and merge the process to the main fitting code
% seek for speed improve
% -----------------------------------------------------------------

Rs=handles.ResisSourceAdjusted;

VeloProbe=ProbeL/((SecondRef-FirstRef-Offset)*TimeInterval);
Xdomain=AddL+CableL+SolderL+ProbeL;
dx=0.005;
NX=ceil(Xdomain/dx);
dx=Xdomain/NX;
dt=0.05*dx/LightSpeed;
TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(DataWidth-1)/dt);

CableNo=floor((AddL+CableL)/dx)+1;
SolderNo=floor((AddL+CableL+SolderL)/dx)+1-CableNo;
R=R_Probe*ones(NX+1,1);
L=[L_Cable.*ones(CableNo,1);L_Node.*ones(SolderNo,1);L_Probe*ones(NX+1-CableNo-SolderNo,1)];
G=[zeros(CableNo+SolderNo,1);G_Probe*ones(NX+1-CableNo-SolderNo,1)];
C=[C_Cable.*ones(CableNo,1);C_Node.*ones(SolderNo,1);C_Probe*ones(NX+1-CableNo-SolderNo,1)];


Matrix_1=zeros(NX+1,3);
Matrix_2=zeros(NX+1,1);

% Assemble the matrix
% x=0 source load
Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
% intermediate point
a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
Matrix_1(2:NX,1)=1./dx./dx./a;
Matrix_1(2:NX,2)=b./a;
Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
Matrix_2(2:NX,1)=d./a;
% x=NX+1 loading load
Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

V=zeros(NX+1,3);
WaveFormSimu=zeros(TotalTimeStep+1,1);

SolderReach=0;
TimeSolderReach=0;
if(SolderReach==0)
    for T=1:TotalTimeStep+1
        Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
        V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
        
        for n=2:NX
            V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
        end
        V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
        V(:,3)=V(:,2);
        V(:,2)=V(:,1);
        WaveFormSimu(T,1)=V(1,1);
        if(V(CableNo+SolderNo,1)>0&&SolderReach==0)
            TimeSolderReach=T;
            VSolderReach=V;
            SolderReach=1;
            WaveFormSimuSolderReach=WaveFormSimu(1:T,1);
        end
    end
else
    NXSolderReach=size(VSolderReach,1);
    if(NXSolderReach==NX+1)
        V=VSolderReach;
    elseif(NXSolderReach>NX+1)
        V=VSolderReach(1:NX+1,:);
    else
        V(1:NXSolderReach,:)=VSolderReach;
    end
    WaveFormSimu(1:TimeSolderReach,1)=WaveFormSimuSolderReach;
    % start the time iteration
    for T=TimeSolderReach+1:TotalTimeStep+1
        Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
        V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
        
        for n=2:NX
            V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
        end
        V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
        V(:,3)=V(:,2);
        V(:,2)=V(:,1);
        WaveFormSimu(T,1)=V(1,1);
    end
end

FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
TimeframeInterpolate=[0:50:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
WaveFormSimuInterpolate=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),TimeframeInterpolate);
WaveFormSimuInterpolate=WaveFormSimuInterpolate*Amplifier;

WaveFormSimuBMO=OneDimensionBMO(OneDimensionBMO(WaveFormSimuInterpolate));
LocalMin=find(WaveFormSimuInterpolate<=min(WaveFormSimuInterpolate));LocalMin=floor(LocalMin(1)-0.001*(TotalTimeStep-2*AddT));
WaveFormSimuBMO(1:LocalMin)=0;
WaveFormSimuBMO=WaveFormSimuBMO.*(WaveFormSimuBMO>=0.8*max(WaveFormSimuBMO));
for n=LocalMin-1:length(WaveFormSimuInterpolate)-1
    if WaveFormSimuBMO(n)>WaveFormSimuBMO(n-1) && WaveFormSimuBMO(n)>WaveFormSimuBMO(n+1)
        break
    end
end
WaveSimuLocalInterpolate=spline(0:4,[WaveFormSimuBMO(n-2),WaveFormSimuBMO(n-1),WaveFormSimuBMO(n),WaveFormSimuBMO(n+1),WaveFormSimuBMO(n+2)],0:0.01:4);
WaveSimuLocalInterpolateMax=find(WaveSimuLocalInterpolate>=max(WaveSimuLocalInterpolate));WaveSimuLocalInterpolateMax=WaveSimuLocalInterpolateMax(1);
SecondRefSimu=(WaveSimuLocalInterpolateMax-1)*0.01+n-2;
SecondRefSimu=SecondRefSimu/(length(WaveFormSimuInterpolate)-1)*(DataWidth-1);

MaxIter=51;
if(SecondRefSimu>=SecondRef)
    % speed is too small
    AccellRattio=(SecondRefSimu-FirstRef-Offset)/(SecondRef-FirstRef-Offset);
    VeloProbeArray=[1:2*(AccellRattio-1)/(MaxIter-1):(1+2*(AccellRattio-1))].*VeloProbe;
    CorrCoefArray=zeros(MaxIter,1);
else
    % speed is too large
    AccellRattio=(SecondRefSimu-FirstRef-Offset)/(SecondRef-FirstRef-Offset);
    VeloProbeArray=[(1-2*(1-AccellRattio)):2*(1-AccellRattio)/(MaxIter-1):1].*VeloProbe;
    CorrCoefArray=zeros(MaxIter,1);
end

parfor iter=1:MaxIter
    % the speed ratio is already done
    
    C_Probe=pi*Permit/acosh(PropDist/PropDiam);
    L_Probe=1/(VeloProbeArray(iter)^2)/C_Probe;
    R_Probe=0;
    G_Probe=pi*EC/acosh(PropDist/PropDiam);
    Impendence=sqrt(L_Probe/C_Probe);
    Rl=Impendence*40.0;
    
    % the coefficient matrix
    R=R_Probe*ones(NX+1,1);
    L=[L_Cable.*ones(CableNo,1);L_Node.*ones(SolderNo,1);L_Probe*ones(NX+1-CableNo-SolderNo,1)];
    G=[zeros(CableNo+SolderNo,1);G_Probe*ones(NX+1-CableNo-SolderNo,1)];
    C=[C_Cable.*ones(CableNo,1);C_Node.*ones(SolderNo,1);C_Probe*ones(NX+1-CableNo-SolderNo,1)];
    
    % no change for the x domain and time/spatial steps
    % assume the previous SolderReach is still working.
    
    Matrix_1=zeros(NX+1,3);
    Matrix_2=zeros(NX+1,1);
    
    % Assemble the matrix
    % x=0 source load
    Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
    Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
    % intermediate point
    a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
    b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
    d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
    Matrix_1(2:NX,1)=1./dx./dx./a;
    Matrix_1(2:NX,2)=b./a;
    Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
    Matrix_2(2:NX,1)=d./a;
    % x=NX+1 loading load
    Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
    Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);
    
    V=zeros(NX+1,3);
    WaveFormSimu=zeros(TotalTimeStep+1,1);
    NXSolderReach=size(VSolderReach,1);
    if(NXSolderReach==NX+1)
        V=VSolderReach;
    elseif(NXSolderReach>NX+1)
        V=VSolderReach(1:NX+1,:);
    else
        V(1:NXSolderReach,:)=VSolderReach;
    end
    WaveFormSimu(1:TimeSolderReach,1)=WaveFormSimuSolderReach;
    
    TotalTimeStepThis=2*AddT+2.*ceil(TimeInterval*min(ceil(SecondRef+5),DataWidth-1)/dt);
    
    % start the time iteration
    for T=TimeSolderReach+1:TotalTimeStepThis+1
        Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
        V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
        
        for n=2:NX
            V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
        end
        V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
        V(:,3)=V(:,2);
        V(:,2)=V(:,1);
        WaveFormSimu(T,1)=V(1,1);
    end
    
    FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
    BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
    WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
    TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
    WaveFormSimuInterpolate2=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:DataWidth-1]);
    
    CorrCoefMatrix=corrcoef(WaveFormSimuInterpolate2(MinLoc:min(ceil(SecondRef+5),DataWidth-1)),...
        WaveForm(MinLoc:min(ceil(SecondRef+5),DataWidth-1)));
    CorrCoefArray(iter,1)=CorrCoefMatrix(2);
    
end

CorrCoefArrayMax=find(CorrCoefArray>=max(CorrCoefArray));CorrCoefArrayMax=CorrCoefArrayMax(1);
VeloProbe=VeloProbeArray(CorrCoefArrayMax);
ProbeLAdjust=(LightSpeed/VeloProbe)/sqrt(80.5)*ProbeL;

% -----------------------------------------------------------------


% make judgement on the probe length
% ccccccccccccccc
    if(abs(ProbeL-ProbeLAdjust)/ProbeL>0.01)
        ProbeLAdjustCheck=questdlg('The probe length needs further adjustment;\n choosing Yes is recommended for measurements in pure water');
    else
        ProbeLAdjustCheck='N';
    end
% cccccccccccccccccccccccccc
% ProbeLAdjustCheck='Y';
if(ProbeLAdjustCheck(1)=='Y')
    IterAdjust=20;
    ProbeTestArray=zeros(IterAdjust,1);
    %        handles.ProbeLength=ProbeLAdjust*1000;
    %        guidata(hObject, handles);
    ProbeL=ProbeLAdjust;
    
    % ------------------------------------------------------------
    % just keep old working code here.
    %        for k=1:IterAdjust
    %            [VeloProbe,ProbeLAdjust]=WaterWaveFit2(handles);
    %            handles.ProbeLength=ProbeLAdjust*1000;
    %            ProbeTestArray(k,1)=ProbeLAdjust*1000;
    %            guidata(hObject, handles);
    %        end
    % -------------------------------------------------------
    % substitute the WaterWaveFit2 for acceleration
    % --------------------------------------------------------
    for k=1:IterAdjust
        VeloProbe=ProbeL/((SecondRef-FirstRef-Offset)*TimeInterval);
        Xdomain=AddL+CableL+SolderL+ProbeL;
        dx=0.005;
        NX=ceil(Xdomain/dx);
        dx=Xdomain/NX;
        dt=0.05*dx/LightSpeed;
        TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(DataWidth-1)/dt);
        
        % because the probe length changed, all the paramerter should
        % be changed too.
        C_Probe=pi*Permit/acosh(PropDist/PropDiam);
        L_Probe=1/(VeloProbe^2)/C_Probe;
        R_Probe=0;
        G_Probe=pi*EC/acosh(PropDist/PropDiam);
        Impendence=sqrt(L_Probe/C_Probe);
        Rl=Impendence*40.0;
        
        CableNo=floor((AddL+CableL)/dx)+1;
        SolderNo=floor((AddL+CableL+SolderL)/dx)+1-CableNo;
        R=R_Probe*ones(NX+1,1);
        L=[L_Cable.*ones(CableNo,1);L_Node.*ones(SolderNo,1);L_Probe*ones(NX+1-CableNo-SolderNo,1)];
        G=[zeros(CableNo+SolderNo,1);G_Probe*ones(NX+1-CableNo-SolderNo,1)];
        C=[C_Cable.*ones(CableNo,1);C_Node.*ones(SolderNo,1);C_Probe*ones(NX+1-CableNo-SolderNo,1)];
        
        Matrix_1=zeros(NX+1,3);
        Matrix_2=zeros(NX+1,1);
        
        % Assemble the matrix
        % x=0 source load
        Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
        Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
        % intermediate point
        a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
        b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
        d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
        Matrix_1(2:NX,1)=1./dx./dx./a;
        Matrix_1(2:NX,2)=b./a;
        Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
        Matrix_2(2:NX,1)=d./a;
        % x=NX+1 loading load
        Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
        Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);
        
        V=zeros(NX+1,3);
        WaveFormSimu=zeros(TotalTimeStep+1,1);
        
        SolderReach=0;
        TimeSolderReach=0;
        if(SolderReach==0)
            for T=1:TotalTimeStep+1
                Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
                V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
                
                for n=2:NX
                    V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
                end
                V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
                V(:,3)=V(:,2);
                V(:,2)=V(:,1);
                WaveFormSimu(T,1)=V(1,1);
                if(V(CableNo+SolderNo,1)>0&&SolderReach==0)
                    TimeSolderReach=T;
                    VSolderReach=V;
                    SolderReach=1;
                    WaveFormSimuSolderReach=WaveFormSimu(1:T,1);
                end
            end
        else
            NXSolderReach=size(VSolderReach,1);
            if(NXSolderReach==NX+1)
                V=VSolderReach;
            elseif(NXSolderReach>NX+1)
                V=VSolderReach(1:NX+1,:);
            else
                V(1:NXSolderReach,:)=VSolderReach;
            end
            WaveFormSimu(1:TimeSolderReach,1)=WaveFormSimuSolderReach;
            % start the time iteration
            for T=TimeSolderReach+1:TotalTimeStep+1
                Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
                V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
                      
                for n=2:NX
                    V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
                end
                V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
                V(:,3)=V(:,2);
                V(:,2)=V(:,1);
                WaveFormSimu(T,1)=V(1,1);
            end
        end
        
        FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
        BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
        WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
        TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
        TimeframeInterpolate=[0:50:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
        WaveFormSimuInterpolate=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),TimeframeInterpolate);
        WaveFormSimuInterpolate=WaveFormSimuInterpolate*Amplifier;
        
        WaveFormSimuBMO=OneDimensionBMO(OneDimensionBMO(WaveFormSimuInterpolate));
        LocalMin=find(WaveFormSimuInterpolate<=min(WaveFormSimuInterpolate));LocalMin=floor(LocalMin(1)-0.001*(TotalTimeStep-2*AddT));
        WaveFormSimuBMO(1:LocalMin)=0;
        WaveFormSimuBMO=WaveFormSimuBMO.*(WaveFormSimuBMO>=0.8*max(WaveFormSimuBMO));
        for n=LocalMin-1:length(WaveFormSimuInterpolate)-1
            if WaveFormSimuBMO(n)>WaveFormSimuBMO(n-1) && WaveFormSimuBMO(n)>WaveFormSimuBMO(n+1)
                break
            end
        end
        WaveSimuLocalInterpolate=spline(0:4,[WaveFormSimuBMO(n-2),WaveFormSimuBMO(n-1),WaveFormSimuBMO(n),WaveFormSimuBMO(n+1),WaveFormSimuBMO(n+2)],0:0.01:4);
        WaveSimuLocalInterpolateMax=find(WaveSimuLocalInterpolate>=max(WaveSimuLocalInterpolate));WaveSimuLocalInterpolateMax=WaveSimuLocalInterpolateMax(1);
        SecondRefSimu=(WaveSimuLocalInterpolateMax-1)*0.01+n-2;
        SecondRefSimu=SecondRefSimu/(length(WaveFormSimuInterpolate)-1)*(DataWidth-1);
        
        MaxIter=51;
        if(SecondRefSimu>=SecondRef)
            % speed is too small
            AccellRattio=(SecondRefSimu-FirstRef-Offset)/(SecondRef-FirstRef-Offset);
            VeloProbeArray=[1:2*(AccellRattio-1)/(MaxIter-1):(1+2*(AccellRattio-1))].*VeloProbe;
            CorrCoefArray=zeros(MaxIter,1);
        else
            % speed is too large
            AccellRattio=(SecondRefSimu-FirstRef-Offset)/(SecondRef-FirstRef-Offset);
            VeloProbeArray=[(1-2*(1-AccellRattio)):2*(1-AccellRattio)/(MaxIter-1):1].*VeloProbe;
            CorrCoefArray=zeros(MaxIter,1);
        end
        
        parfor iter=1:MaxIter
            % the speed ratio is already done
            
            C_Probe=pi*Permit/acosh(PropDist/PropDiam);
            L_Probe=1/(VeloProbeArray(iter)^2)/C_Probe;
            R_Probe=0;
            G_Probe=pi*EC/acosh(PropDist/PropDiam);
            Impendence=sqrt(L_Probe/C_Probe);
            Rl=Impendence*40.0;
            
            % the coefficient matrix
            R=R_Probe.*ones(NX+1,1);
            L=[L_Cable.*ones(CableNo,1);L_Node.*ones(SolderNo,1);L_Probe*ones(NX+1-CableNo-SolderNo,1)];
            G=[zeros(CableNo+SolderNo,1);G_Probe*ones(NX+1-CableNo-SolderNo,1)];
            C=[C_Cable.*ones(CableNo,1);C_Node.*ones(SolderNo,1);C_Probe*ones(NX+1-CableNo-SolderNo,1)];
            
            % no change for the x domain and time/spatial steps
            % assume the previous SolderReach is still working.
            
            Matrix_1=zeros(NX+1,3);
            Matrix_2=zeros(NX+1,1);
            
            % Assemble the matrix
            % x=0 source load
            Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
            Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
            % intermediate point
            a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
            b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
            d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
            Matrix_1(2:NX,1)=1./dx./dx./a;
            Matrix_1(2:NX,2)=b./a;
            Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
            Matrix_2(2:NX,1)=d./a;
            % x=NX+1 loading load
            Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
            Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);
            
            V=zeros(NX+1,3);
            WaveFormSimu=zeros(TotalTimeStep+1,1);
            NXSolderReach=size(VSolderReach,1);
            if(NXSolderReach==NX+1)
                V=VSolderReach;
            elseif(NXSolderReach>NX+1)
                V=VSolderReach(1:NX+1,:);
            else
                V(1:NXSolderReach,:)=VSolderReach;
            end
            WaveFormSimu(1:TimeSolderReach,1)=WaveFormSimuSolderReach;
            
            TotalTimeStepThis=2*AddT+2.*ceil(TimeInterval*min(ceil(SecondRef+5),DataWidth-1)/dt);
            
            % start the time iteration
            for T=TimeSolderReach+1:TotalTimeStepThis+1
                Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
                V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
                      
                for n=2:NX
                    V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
                end
                V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
                V(:,3)=V(:,2);
                V(:,2)=V(:,1);
                WaveFormSimu(T,1)=V(1,1);
            end
            
            FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
            BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
            WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
            TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
            WaveFormSimuInterpolate2=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:DataWidth-1]);
            
            CorrCoefMatrix=corrcoef(WaveFormSimuInterpolate2(MinLoc:min(ceil(SecondRef+5),DataWidth-1)),...
                WaveForm(MinLoc:min(ceil(SecondRef+5),DataWidth-1)));
            CorrCoefArray(iter,1)=CorrCoefMatrix(2);
        end
        
        CorrCoefArrayMax=find(CorrCoefArray>=max(CorrCoefArray));CorrCoefArrayMax=CorrCoefArrayMax(1);
        VeloProbe=VeloProbeArray(CorrCoefArrayMax);
        ProbeLAdjust=(LightSpeed/VeloProbe)/sqrt(80.5)*ProbeL;
        % --------------------------------------------------------
        ProbeL=ProbeLAdjust;
        ProbeTestArray(k,1)=ProbeLAdjust;
        
    end
    
    ProbeL=median(ProbeTestArray(IterAdjust-15:IterAdjust));
    handles.ProbeLength=ProbeL*1000;
    guidata(hObject, handles);
    VeloProbe=ProbeL/((SecondRef-FirstRef-Offset)*TimeInterval);
    
end

C_Probe=pi*Permit/acosh(PropDist/PropDiam);
L_Probe=1/VeloProbe/VeloProbe/C_Probe;
R_Probe=0;
G_Probe=pi*EC/acosh(PropDist/PropDiam);
Impendence=sqrt(L_Probe/C_Probe);
Rl=Impendence*40.0;

% record the waveform
handles.WaveformData_Prem_FIT=(LightSpeed/VeloProbe)^2;
handles.ProbeParR=R_Probe;
handles.ProbeParL=L_Probe;
handles.ProbeParC=C_Probe;
handles.ProbeParG=G_Probe;
guidata(hObject, handles);

%    [WaveFormSimuInterpolate,AdjustFactor]=WaterWaveFit3(handles);
% ----------------------------------------------------------------------
% release the function WaterWaveFit3(handles) to seek for acceration
% ----------------------------------------------------------------------

% because we need to iteration, first save the original data
ProbeLOrg=ProbeL;
R_ProbeOrg=R_Probe;
L_ProbeOrg=L_Probe;
C_ProbeOrg=C_Probe;
G_ProbeOrg=G_Probe;
Impendence=sqrt(L_ProbeOrg/C_ProbeOrg);
Rl=Impendence*40.0;

% adjust the amplifier for correct plot

AdjustFactor=Amplifier;
AdjustFactorOld=AdjustFactor;
ErrorAdjust=1000;
iterAdjust=0;

MaxIterFit=20;
SolderReach=0;
TimeSolderReach=0;
while(iterAdjust<=MaxIterFit)
    iterAdjust=iterAdjust+1;
    ProbeL=ProbeLOrg/AdjustFactor;
    Xdomain=AddL+CableL+SolderL+ProbeL;
    dx=0.005;
    NX=ceil(Xdomain/dx);
    dx=Xdomain/NX;
    dt=0.05*dx/LightSpeed;
    TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(DataWidth-1)/dt);
    TotalTimeStepThis=2*AddT+2.*ceil(TimeInterval*min(ceil(SecondRef)+1,(DataWidth-1))/dt);
    L_Probe=L_ProbeOrg*AdjustFactor;
    C_Probe=C_ProbeOrg*AdjustFactor;
    G_Probe=G_ProbeOrg;
    
    CableNo=floor((AddL+CableL)/dx)+1;
    SolderNo=floor((AddL+CableL+SolderL)/dx)+1-CableNo;
    R=R_ProbeOrg.*ones(NX+1,1);
    L=[L_Cable.*ones(CableNo,1);L_Node.*ones(SolderNo,1);L_Probe*ones(NX+1-CableNo-SolderNo,1)];
    G=[zeros(CableNo+SolderNo,1);G_Probe*ones(NX+1-CableNo-SolderNo,1)];
    C=[C_Cable.*ones(CableNo,1);C_Node.*ones(SolderNo,1);C_Probe*ones(NX+1-CableNo-SolderNo,1)];
    
    Matrix_1=zeros(NX+1,3);
    Matrix_2=zeros(NX+1,1);

    % Assemble the matrix
    % x=0 source load
    Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
    Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
    % intermediate point
    a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
    b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
    d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
    Matrix_1(2:NX,1)=1./dx./dx./a;
    Matrix_1(2:NX,2)=b./a;
    Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
    Matrix_2(2:NX,1)=d./a;
    % x=NX+1 loading load
    Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
    Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);
    
    V=zeros(NX+1,3);
    WaveFormSimu=zeros(TotalTimeStep+1,1);
    
    if(SolderReach==0)
        for T=1:TotalTimeStepThis+1
            Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
            V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
                  
                for n=2:NX
                    V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
                end
            V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
            V(:,3)=V(:,2);
            V(:,2)=V(:,1);
            WaveFormSimu(T,1)=V(1,1);
            if(V(CableNo+SolderNo,1)>0&&SolderReach==0)
                TimeSolderReach=T;
                VSolderReach=V;
                SolderReach=1;
                WaveFormSimuSolderReach=WaveFormSimu(1:T,1);
            end
        end
    else
        NXSolderReach=size(VSolderReach,1);
        if(NXSolderReach==NX+1)
            V=VSolderReach;
        elseif(NXSolderReach>NX+1)
            V=VSolderReach(1:NX+1,:);
        else
            V(1:NXSolderReach,:)=VSolderReach;
        end
        WaveFormSimu(1:TimeSolderReach,1)=WaveFormSimuSolderReach;
        if(iterAdjust==MaxIterFit+1)
            TotalTimeStepThis=TotalTimeStep;
        end
        for T=TimeSolderReach+1:TotalTimeStepThis+1
            Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
            V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
                  
                for n=2:NX
                    V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
                end
            V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
            V(:,3)=V(:,2);
            V(:,2)=V(:,1);
            WaveFormSimu(T,1)=V(1,1);
        end
    end
    
    FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
    BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
    WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
    TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
    WaveFormSimuInterpolate=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:DataWidth-1]);
    AdjustFactorOld=AdjustFactor;
    AdjustFactor=AdjustFactor*median(WaveForm(ceil(FirstRef):floor(SecondRef))./WaveFormSimuInterpolate(ceil(FirstRef):floor(SecondRef)));
    ErrorAdjust=abs(AdjustFactor-AdjustFactorOld)/abs(AdjustFactor);
    
    if(ErrorAdjust<=0.01)
        if(iterAdjust<MaxIterFit+1)
            for T=TotalTimeStepThis+2:TotalTimeStep+1
                Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)*2+dVsdt(T*dt-dt)*dt*2;
                V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
                for n=2:NX
                    V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
                end
                V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
                V(:,3)=V(:,2);
                V(:,2)=V(:,1);
                WaveFormSimu(T,1)=(V(1,1)-BasedValue)/BasedValue;
            end
            WaveFormSimuInterpolate=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:DataWidth-1]);
        end
        break
    end
end
% ----------------------------------------------------------------------

WaveFormSimuInterpolate=WaveFormSimuInterpolate+RCoef0;
handles.AdjustFactor=AdjustFactor;
guidata(hObject, handles);

set(handles.EDT_FITTING_WATER_RELAPERM,'string',num2str(handles.WaveformData_Prem_FIT));
set(handles.EDT_FITTING_WATER_PROBELENGTH,'string',num2str(handles.ProbeLength));

% start to plot
% need to clean previous plot if possible
X=0:DataWidth-1;
if(handles.STEP3PLOTWATERWAVE~=0)
else
    axes(handles.PIC_TDR_INV)
    handles.STEP3PLOTWATERWAVE=plot(X,WaveForm,'b','linewidth',1);
end
if(handles.STEP3PLOTWATERWAVEFIT~=0)
    delete(handles.STEP3PLOTWATERWAVEFIT);
    handles.STEP3PLOTWATERWAVEFIT=0;
end
guidata(hObject, handles);

axes(handles.PIC_TDR_INV)
hold on

handles.STEP3PLOTWATERWAVEFIT=plot(X,WaveFormSimuInterpolate,'r--','linewidth',2);
set(handles.PIC_TDR_INV,'xTick',[]);
set(handles.PIC_TDR_INV,'yTick',[]);
box on
handles.Waveform_Water_Fitted=WaveFormSimuInterpolate;
guidata(hObject, handles)
toc



function EDT_FITTING_WATER_R_SOURCE_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_WATER_R_SOURCE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_FITTING_WATER_R_SOURCE as text
%        str2double(get(hObject,'String')) returns contents of EDT_FITTING_WATER_R_SOURCE as a double
set(handles.EDT_FITTING_WATER_R_SOURCE,'string',num2str(handles.ResisSource));



% --- Executes during object creation, after setting all properties.
function EDT_FITTING_WATER_R_SOURCE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_WATER_R_SOURCE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_FITTING_WATER_R_LOAD_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_WATER_R_LOAD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_FITTING_WATER_R_LOAD as text
%        str2double(get(hObject,'String')) returns contents of EDT_FITTING_WATER_R_LOAD as a double

    set(handles.EDT_FITTING_WATER_R_LOAD,'string',num2str(handles.ResisLoad));


% --- Executes during object creation, after setting all properties.
function EDT_FITTING_WATER_R_LOAD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_WATER_R_LOAD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_FITTING_WATER_RELAPERM_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_WATER_RELAPERM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_FITTING_WATER_RELAPERM as text
%        str2double(get(hObject,'String')) returns contents of EDT_FITTING_WATER_RELAPERM as a double

    set(handles.EDT_FITTING_WATER_RELAPERM,'string',...
        num2str(mean(handles.WaveformData_Prem(1:handles.WaterWaveNum,1))));


% --- Executes during object creation, after setting all properties.
function EDT_FITTING_WATER_RELAPERM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_WATER_RELAPERM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function EDT_FITTING_WATER_EC_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_WATER_EC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_FITTING_WATER_EC as text
%        str2double(get(hObject,'String')) returns contents of EDT_FITTING_WATER_EC as a double

    set(handles.EDT_FITTING_WATER_EC,'string',...
        num2str(mean(handles.WaveformData_EC(1:handles.WaterWaveNum,1))));


% --- Executes during object creation, after setting all properties.
function EDT_FITTING_WATER_EC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_WATER_EC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EDT_MEASURE_INPUT_TIMERESO_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_INPUT_TIMERESO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_MEASURE_INPUT_TIMERESO as text
%        str2double(get(hObject,'String')) returns contents of EDT_MEASURE_INPUT_TIMERESO as a double
TimeReso=str2double(get(hObject,'String'))*1.0e-12;
if handles.SelfSystem==1
    if TimeReso>0
        handles.InputTimeReso=TimeReso;
        guidata(hObject, handles);
    else
        set(hObject,'String',num2str(handles.InputTimeReso*1.0e+12));
    end
else
    set(hObject,'String',num2str(handles.InputTimeReso*1.0e+12));
end


% --- Executes during object creation, after setting all properties.
function EDT_MEASURE_INPUT_TIMERESO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_MEASURE_INPUT_TIMERESO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object deletion, before destroying properties.
function PAN_WAVE_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to PAN_WAVE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

function EDT_FITTING_WATER_PROBELENGTH_Callback(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_WATER_PROBELENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EDT_FITTING_WATER_PROBELENGTH as text
%        str2double(get(hObject,'String')) returns contents of EDT_FITTING_WATER_PROBELENGTH as a double


% --- Executes during object creation, after setting all properties.
function EDT_FITTING_WATER_PROBELENGTH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EDT_FITTING_WATER_PROBELENGTH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% *********************************************************************
% *********************************************************************
% *********************************************************************
% From here not GUI

%---------------------------------------
% Clean_Figures
% Use to clean the figures in open callback function.
%                             Bisection_Fitting_OpeningFcn function.
% Need //
%---------------------------------------
function Clean_Figures(handles)
    if(handles.Step2PlotWater~=0)
        delete(handles.Step2PlotWater);
    end
    if(handles.Step2PlotBtc~=0)
        delete(handles.Step2PlotBtc);
    end
    if(handles.Step2PlotWaterBMO~=0)
        delete(handles.Step2PlotWaterBMO);
    end
    if(handles.Step2PlotBtcBMO~=0)
        delete(handles.Step2PlotBtcBMO);
    end
    if(handles.Step2PlotWaterRef1~=0)
        delete(handles.Step2PlotWaterRef1);
    end
    if(handles.Step2PlotBtcRef1~=0)
        delete(handles.Step2PlotBtcRef1);
    end
    if(handles.Step2PlotWaterRef2~=0)
        delete(handles.Step2PlotWaterRef2);
    end
    if(handles.Step2PlotBtcRef2~=0)
        delete(handles.Step2PlotBtcRef2);
    end
    if(handles.Step2PlotWaterSmooth~=0)
        delete(handles.Step2PlotWaterSmooth);
    end
    if(handles.Step2PlotBtcSmooth~=0)
        delete(handles.Step2PlotBtcSmooth);
    end
    if(handles.Step2PlotWaterBMOSmooth~=0)
        delete(handles.Step2PlotWaterBMOSmooth);
    end
    if(handles.Step2PlotBtcBMOSmooth~=0)
        delete(handles.Step2PlotBtcBMOSmooth)
    end

    

%---------------------------------------
% PlotWaveForms for view
% Use to plot the waveforms in Step2 (Water/BTC)
% in both axes handles
% 
% Use in PB_NEXT and PT_PREV callback function.
% Need //
%---------------------------------------
function [Plot_Water_Wave,Plot_Btc_Wave]=PlotWaveForms(handles)

% Begin the plot new waveform set
    
    Waveform=handles.WaveformData;
    NumWater=handles.WaterWaveNum;
    NumTotal=handles.DataLength;
    DataWidth=handles.DataWidth;
    X=0:(DataWidth-1);
    
    WaveformsWater=Waveform(1:NumWater,:);
    WaveformsBTC=Waveform(NumWater+1:NumTotal,:);

    axes(handles.PIC_TDR_WAVE1)
    hold on
    Plot_Water_Wave=plot(X,WaveformsWater,'b');
    set(handles.PIC_TDR_WAVE1,'xTick',[]);
    set(handles.PIC_TDR_WAVE1,'yTick',[]);
    axis([0,DataWidth-1,min(min(WaveformsWater))-0.1,max(max(WaveformsWater))+0.1]);
    box on

    axes(handles.PIC_TDR_WAVE2)
    hold on
    Plot_Btc_Wave=plot(X,WaveformsBTC,'b');
    set(handles.PIC_TDR_WAVE2,'xTick',[]);
    set(handles.PIC_TDR_WAVE2,'yTick',[]);
    axis([0,DataWidth-1,min(min(WaveformsBTC))-0.1,max(max(WaveformsBTC))+0.1]);
    box on
    

%---------------------------------------
% PlotWaveForms and BMO for view
% Calculated the non-smoothed BMOs for waveforms and report them
% 
% Need OneDimensionBMO(INPUT)
%---------------------------------------
function [BMO,PWave,PBMO]=PlotWaveFormBMO(handles, mode)

DataWidth=handles.DataWidth;
X=0:(DataWidth-1);
Waveform=handles.WaveformData;
NumTotal=handles.DataLength;

if mode==1
% do the following process for water part

% Begin the calculation of the TDR waveform BMO
    
    NumWater=handles.WaterWaveNum;
    Waveform=Waveform(1:NumWater,:);
    BMO=Waveform;
    for i=1:NumWater
        BMO(i,:)=OneDimensionBMO(OneDimensionBMO(Waveform(i,:)));
    end

        
    axes(handles.PIC_TDR_WAVE1)
    hold on
    PWave=plot(X,Waveform,'b');
    set(handles.PIC_TDR_WAVE1,'xTick',[]);
    set(handles.PIC_TDR_WAVE1,'yTick',[]);
    axis([0,DataWidth-1,min(min(Waveform))-0.1,max(max(Waveform))+0.1]);
    box on
        
    axes(handles.PIC_TDR_WAVE2)
    hold on
    PBMO=plot(X,BMO,'b');
    set(handles.PIC_TDR_WAVE2,'xTick',[]);
    set(handles.PIC_TDR_WAVE2,'yTick',[]);
    axis([0,DataWidth-1,0,max(max(BMO))*1.1]);
    box on
    
elseif mode==2
    
    NumBTC=handles.BtcWaveNum;
    NumWater=handles.WaterWaveNum;
    Waveform=Waveform(NumWater+1:NumTotal,:);
    BMO=Waveform;
    for i=1:NumBTC
        BMO(i,:)=OneDimensionBMO(OneDimensionBMO(Waveform(i,:)));
    end
        
    axes(handles.PIC_TDR_WAVE1)
    hold on
    PWave=plot(X,Waveform,'b');
    set(handles.PIC_TDR_WAVE1,'xTick',[]);
    set(handles.PIC_TDR_WAVE1,'yTick',[]);
    axis([0,DataWidth-1,min(min(Waveform))-0.1,max(max(Waveform))+0.1]);
    box on
        
    axes(handles.PIC_TDR_WAVE2)
    hold on
    PBMO=plot(X,BMO,'b');
    set(handles.PIC_TDR_WAVE2,'xTick',[]);
    set(handles.PIC_TDR_WAVE2,'yTick',[]);
    axis([0,DataWidth-1,0,max(max(BMO))*1.1]);
    box on
     
end

%---------------------------------------
% Plot Smoothed WaveForms and Smoothed BMO for view
% Calculated the smoothed BMOs for waveforms and report them
% 
% Need OneDimensionBMO(INPUT)
%---------------------------------------
function [PWave_SMOOTH,PBMO_SMOOTH]=PlotWaveFormBMO_Smooth(handles, mode)

DataWidth=handles.DataWidth;
X=0:(DataWidth-1);

if mode==1
% do the following process for water part
    Waveform=handles.Waveform_Water_Smooth;
    WaveformBMO=handles.WaveformBMO_Water_Smooth;
 
    axes(handles.PIC_TDR_WAVE1)
    hold on
    PWave_SMOOTH=plot(X,Waveform,'g');
    set(handles.PIC_TDR_WAVE1,'xTick',[]);
    set(handles.PIC_TDR_WAVE1,'yTick',[]);
    %axis([0,handles.DataWidth-1,min(min(Waveform))-0.1,max(max(Waveform))+0.1]);
    box on
        
    axes(handles.PIC_TDR_WAVE2)
    hold on
    PBMO_SMOOTH=plot(X,WaveformBMO,'g');
    set(handles.PIC_TDR_WAVE2,'xTick',[]);
    set(handles.PIC_TDR_WAVE2,'yTick',[]);
    %axis([0,handles.DataWidth-1,0,max(max(BMO))*1.1]);
    box on
    
elseif mode==2
    
    Waveform=handles.Waveform_Btc_Smooth;
    WaveformBMO=handles.WaveformBMO_Btc_Smooth;
    
    axes(handles.PIC_TDR_WAVE1)
    hold on
    PWave_SMOOTH=plot(X,Waveform,'g');
    set(handles.PIC_TDR_WAVE1,'xTick',[]);
    set(handles.PIC_TDR_WAVE1,'yTick',[]);
    %axis([0,handles.DataWidth-1,min(min(Waveform))-0.1,max(max(Waveform))+0.1]);
    box on
        
    axes(handles.PIC_TDR_WAVE2)
    hold on
    PBMO_SMOOTH=plot(X,WaveformBMO,'g');
    set(handles.PIC_TDR_WAVE2,'xTick',[]);
    set(handles.PIC_TDR_WAVE2,'yTick',[]);
    %axis([0,handles.DataWidth-1,0,max(max(BMO))*1.1]);
    box on
     
end


%---------------------------------------
% Plot first reflection position with manual method
%---------------------------------------

function PlotFirRef=PlotWaveFirstRef(handles,mode)

if mode==1
    FirstRef=handles.Manual_Water_Ref1;
    axes(handles.PIC_TDR_WAVE1)
    PlotFirRef_Wave1=plot([FirstRef,FirstRef],[-1,1],'r');
    axes(handles.PIC_TDR_WAVE2)
    PlotFirRef_Wave2=plot([FirstRef,FirstRef],[-1,1],'r');
elseif mode==2
    FirstRef=handles.Manual_Btc_Ref1;
    axes(handles.PIC_TDR_WAVE1)
    PlotFirRef_Wave1=plot([FirstRef,FirstRef],[-1,1],'r');
    axes(handles.PIC_TDR_WAVE2)
    PlotFirRef_Wave2=plot([FirstRef,FirstRef],[-1,1],'r');
else
end
PlotFirRef=[PlotFirRef_Wave1;PlotFirRef_Wave2];


%---------------------------------------
% 1-D BMO function (7 points averaged)
% Need //
%---------------------------------------
function ANS=OneDimensionBMO(INPUT)
    h=1;
    m=max(size(INPUT));
    ANS=zeros(1,m);
    for i=4:m-3	
        p=((INPUT(i)+INPUT(i-1)+INPUT(i+1)+INPUT(i-2)+INPUT(i+2))+0.5*INPUT(i-3)+0.5*INPUT(i+3))/6;
        q=(((INPUT(i)-p)^2+(INPUT(i+1)-p)^2+(INPUT(i-1)-p)^2+(INPUT(i+2)-p)^2+(INPUT(i+2)-p)^2)+0.5*((INPUT(i+3)-p)^2)+0.5*((INPUT(i-3)-p)^2))/6;
        ANS(i)=sqrt(q)/h;
    end
    ANS(1)=ANS(4);
    ANS(2)=ANS(4);
    ANS(3)=ANS(4);
    ANS(m)=ANS(m-3);
    ANS(m-1)=ANS(m-3);
    ANS(m-2)=ANS(m-3);
   
% -------------------------------------------------------------------------------
% Func_Waveform_Processing Function
% Do the waveform calculation, return waveform, smoothed waveform and
% corresponding second order BMO.
% Need second order BMO (or first order BMO) function and Smoothed function.
% Thus,
% OneDimensionBMO(INPUT,h)
% KernelFunc(BmoDATA1,thre);
% --------------------------------------------------------------------------------

function [Waveform,WaveformBMO]=Waveform_Smoothing(handles, mode)

NumTotal=handles.DataLength;

MaxIter=100;
%-----------------------------------------------------------------------
%   for water waveform processing
%   obtained smoothed waveform and smoothed BMO
%-----------------------------------------------------------------------
if mode==1    
    NumWater=handles.WaterWaveNum;
    k=handles.Smooth_Water_Intensity; 
    Waveform=handles.WaveformData(1:NumWater,:);
    DataWidth=handles.DataWidth;
    
    Dt=0.001;
    h=1;
    sqrt_h_reci=1/(h^2);
    c=@(t) 1/(1+(t/k)^2);
    Lf=zeros(NumWater,DataWidth);
    g=zeros(NumWater,DataWidth);
    Lg=zeros(NumWater,DataWidth);
    
    for m=1:MaxIter
        for i=1:NumWater
            for j=2:DataWidth-1
                Lf(i,j)=sqrt_h_reci*(Waveform(i,j+1)+Waveform(i,j-1)-2*Waveform(i,j));
                g(i,j)=c(Lf(i,j))*Lf(i,j);
            end
            Lf(i,1)=sqrt_h_reci*(Waveform(i,2)-Waveform(i,1)); 
            Lf(i,DataWidth)=sqrt_h_reci*(Waveform(i,DataWidth)-Waveform(i,DataWidth-1));
            g(i,1)=c(Lf(i,1))*Lf(i,1);
            g(i,DataWidth)=c(Lf(i,DataWidth))*Lf(i,DataWidth);
        end
        for i=1:NumWater
            for j=2:DataWidth-1
                Lg(i,j)=sqrt_h_reci*(g(i,j+1)+g(i,j-1)-2*g(i,j));
            end
            Lg(i,1)=sqrt_h_reci*(g(i,2)-g(i,1)); 
            Lg(i,DataWidth)=sqrt_h_reci*(g(i,DataWidth)-g(i,DataWidth-1));
        end
        Waveform=Waveform-Dt*Lg;
    end
    WaveformBMO=zeros(NumWater,DataWidth);
    for i=1:NumWater
        WaveformBMO(i,:)=OneDimensionBMO(OneDimensionBMO(Waveform(i,:)));
    end

%-----------------------------------------------------------------------
%   for btc waveform processing
%   obtained smoothed waveform and smoothed BMO
%-----------------------------------------------------------------------
elseif mode==2
    NumWater=handles.WaterWaveNum;
    NumBTC=handles.BtcWaveNum;
    k=handles.Smooth_Btc_Intensity; 
    Waveform=handles.WaveformData(NumWater+1:NumTotal,:);
    DataWidth=handles.DataWidth;
    
    Dt=0.001;
    h=1;
    sqrt_h_reci=1/(h^2);
    c=@(t) 1/(1+(t/k)^2);
    Lf=zeros(NumBTC,DataWidth);
    g=zeros(NumBTC,DataWidth);
    Lg=zeros(NumBTC,DataWidth);
    
    for m=1:MaxIter
        for i=1:NumBTC
            for j=2:DataWidth-1
                Lf(i,j)=sqrt_h_reci*(Waveform(i,j+1)+Waveform(i,j-1)-2*Waveform(i,j));
                g(i,j)=c(Lf(i,j))*Lf(i,j);
            end
            Lf(i,1)=sqrt_h_reci*(Waveform(i,2)-Waveform(i,1)); 
            Lf(i,DataWidth)=sqrt_h_reci*(Waveform(i,DataWidth)-Waveform(i,DataWidth-1));
            g(i,1)=c(Lf(i,1))*Lf(i,1);
            g(i,DataWidth)=c(Lf(i,DataWidth))*Lf(i,DataWidth);
        end
        for i=1:NumBTC
            for j=2:DataWidth-1
                Lg(i,j)=sqrt_h_reci*(g(i,j+1)+g(i,j-1)-2*g(i,j));
            end
            Lg(i,1)=sqrt_h_reci*(g(i,2)-g(i,1)); 
            Lg(i,DataWidth)=sqrt_h_reci*(g(i,DataWidth)-g(i,DataWidth-1));
        end
        Waveform=Waveform-Dt*Lg;
    end
    WaveformBMO=zeros(NumBTC,DataWidth);
    for i=1:NumBTC
        WaveformBMO(i,:)=OneDimensionBMO(OneDimensionBMO(Waveform(i,:)));
    end

else
end

%--------------------------------------
% Automatical First Ref Determination Function, need all the handles.
% Four method are metioned here, need calculations except for manual one
% Return the first reflection position as the POINT INDEX
% Return the first reflection position PLOT HANDLE
%--------------------------------------

function FIRSTREF=Auto_First_Ref_Position(handles,mode)

% process for the water data
if mode==1
    L=handles.DataWidth;
    WaterWaveNum=handles.WaterWaveNum;
    Sensitivity_Water=handles.Sensitivity_Water;
    if handles.Waveform_Water_Smooth_Check==0
        WAVE=handles.WaveformData(1:WaterWaveNum,:);
        WAVEBMO=handles.WaveformBMO_Water;
    else
        WAVE=handles.Waveform_Water_Smooth;
        WAVEBMO=handles.WaveformBMO_Water_Smooth;
    end
    
    
%    YInterval1=zeros(5,1);
    FIRSTREF=zeros(WaterWaveNum,1);
    
    Manual_Ref1_Water_Check=handles.Manual_Ref1_Water_Check;
    Manual_Water_Ref1=handles.Manual_Water_Ref1;
    
    parfor k=1:WaterWaveNum
        TempPick2=zeros(L,1);
% consider if manual first ref is used
        if Manual_Ref1_Water_Check==1
            FIRSTREF(k,1)=Manual_Water_Ref1;        
        else
            min_WAVE=min(WAVE(k,:));
            LocalMin=find(WAVE(k,:)<=min_WAVE);
            LocalMin=LocalMin(1);
            M=max(WAVEBMO(k,1:LocalMin));
% need to use the automatic determination of the first ref
            EpsFirst=0.01;

            for i=4:LocalMin
                if(WAVEBMO(k,i)>=WAVEBMO(k,i+1)...
                        &&WAVEBMO(k,i)>=WAVEBMO(k,i-1)...
                        &&WAVEBMO(k,i)>=WAVEBMO(k,i-2)...
                        &&WAVEBMO(k,i)>=WAVEBMO(k,i+2)...
                        &&WAVEBMO(k,i)>=WAVEBMO(k,i-3)...
                        &&WAVEBMO(k,i)>=WAVEBMO(k,i+3))
                    if (WAVEBMO(k,i)>=(1-Sensitivity_Water)*M)
                        TempPick2(i,1)=1;
                    end
                end
            end

            % find the first reflection position
            % find slope 
            Indices=find(TempPick2(1:LocalMin,1)==1);
            LIndices=length(Indices);
%             WaveIndices=zeros(LIndices+2,1);
%             WaveIndices(1)=WAVE(k,1);
%             WaveIndices(LIndices+2)=WAVE(k,LocalMin);
%             for i=1:LIndices
%                 WaveIndices(i+1)=WAVE(k,Indices(i));
%             end
            WaveIndices=[WAVE(k,1);WAVE(k,Indices)';WAVE(k,LocalMin)];
            kmid=1;

            XaxisMax=0;

            for i=2:LIndices+1
                if((WaveIndices(i+1)-WaveIndices(i))<(WaveIndices(i)-WaveIndices(i-1)))
%                if((WaveIndices(i+1)-WaveIndices(i))>=0&&(WaveIndices(i)-WaveIndices(i-1))<=0)
                else
                    if(kmid==1)
                        XaxisMax=Indices(i-1);
                        kmid=0;
                    end
                end
            end

            if XaxisMax==0
                LL=find(TempPick2==1);
                XaxisMax=max(2,LL(1));
            end

            % spline interpolation
            Interval1=(XaxisMax-2):(XaxisMax+2);
%            for i=1:5
%                YInterval1(i)=WAVEBMO(k,XaxisMax-3+i);
%            end
            YInterval1=WAVEBMO(k,Interval1);
            PInterval1=(XaxisMax-2):EpsFirst:(XaxisMax+2);
            SplInterval1=spline(Interval1,YInterval1,PInterval1);
            max_SplInterval1=max(SplInterval1);
            LocX1=find(SplInterval1>=max_SplInterval1);
            XaxisMax=XaxisMax-2+(LocX1-1)*EpsFirst;

% give the first reflection position: -1 because we set first pt as 0
            FIRSTREF(k,1)=XaxisMax-1;
        end
    end
    
elseif mode==2
    
    L=handles.DataWidth;
    WaterWaveNum=handles.WaterWaveNum;
    DataLength=handles.DataLength;
    BtcWaveNum=handles.BtcWaveNum;
    Sensitivity_Btc=handles.Sensitivity_Btc;
    
    if handles.Waveform_Btc_Smooth_Check==0
        WAVE=handles.WaveformData(WaterWaveNum+1:DataLength,:);
        WAVEBMO=handles.WaveformBMO_Btc;
    else
        WAVE=handles.Waveform_Btc_Smooth;
        WAVEBMO=handles.WaveformBMO_Btc_Smooth;
    end
    
    
    YInterval1=zeros(5,1);
    FIRSTREF=zeros(BtcWaveNum,1);
    
    Manual_Ref1_Btc_Check=handles.Manual_Ref1_Btc_Check;
    Manual_Btc_Ref1=handles.Manual_Btc_Ref1;
    
    parfor k=1:BtcWaveNum
        TempPick2=zeros(L,1);
% consider if manual first ref is used
        if Manual_Ref1_Btc_Check==1
            FIRSTREF(k,1)=Manual_Btc_Ref1;        
        else
            min_WAVE=min(WAVE(k,:));
            LocalMin=find(WAVE(k,:)<=min_WAVE);
            LocalMin=LocalMin(1);
            M=max(WAVEBMO(k,1:LocalMin));
% need to use the automatic determination of the first ref
            EpsFirst=0.01;

            for i=4:LocalMin
                if(WAVEBMO(k,i)>=WAVEBMO(k,i+1)...
                        &&WAVEBMO(k,i)>=WAVEBMO(k,i-1)...
                        &&WAVEBMO(k,i)>=WAVEBMO(k,i-2)...
                        &&WAVEBMO(k,i)>=WAVEBMO(k,i+2)...
                        &&WAVEBMO(k,i)>=WAVEBMO(k,i-3)...
                        &&WAVEBMO(k,i)>=WAVEBMO(k,i+3))
                    if (WAVEBMO(k,i)>=(1-Sensitivity_Btc)*M)
                        TempPick2(i)=1;
                    end
                end
            end

            % find the first reflection position
            % find slope 
            Indices=find(TempPick2(1:LocalMin)==1);
            LIndices=length(Indices);
%             WaveIndices=zeros(LIndices+2,1);
%             WaveIndices(1)=WAVE(k,1);
%             WaveIndices(LIndices+2)=WAVE(k,LocalMin);
%             for i=1:LIndices
%                 WaveIndices(i+1)=WAVE(k,Indices(i));
%             end
            WaveIndices=[WAVE(k,1);WAVE(k,Indices)';WAVE(k,LocalMin)];
            kmid=1;

            XaxisMax=0;

            for i=2:LIndices+1
                if((WaveIndices(i+1)-WaveIndices(i))<(WaveIndices(i)-WaveIndices(i-1)))
                else
                    if(kmid==1)
                        XaxisMax=Indices(i-1);
                        kmid=0;
                    end
                end
            end

            if XaxisMax==0
                LL=find(TempPick2==1);
                XaxisMax=max(2,LL(1));
            end

            % spline interpolation
            Interval1=(XaxisMax-2):(XaxisMax+2);
%            for i=1:5
%                YInterval1(i)=WAVEBMO(k,XaxisMax-3+i);
%            end
            YInterval1=WAVEBMO(k,Interval1);
            PInterval1=(XaxisMax-2):EpsFirst:(XaxisMax+2);
            SplInterval1=spline(Interval1,YInterval1,PInterval1);
            max_SplInterval1=max(SplInterval1);
            LocX1=find(SplInterval1>=max_SplInterval1);
            XaxisMax=XaxisMax-2+(LocX1-1)*EpsFirst;

            % give the first reflection position: -1 because we set first pt as 0
            FIRSTREF(k,1)=XaxisMax-1;
        end
    end
    
else
end


%--------------------------------------
% Automatical Second Ref Determination Function, need all the handles.
% Second order BMO metioned here
% Return the second reflection position as the POINT INDEX
% Return the second reflection position PLOT HANDLE
%--------------------------------------
function SECONDREF=Auto_Second_Ref_Position(handles,mode)

EpsSecond=0.01;
L=handles.DataWidth;

if mode==1
% process for the water data

    WaterWaveNum=handles.WaterWaveNum;
    Sensitivity_Water=handles.Sensitivity_Water;
    if handles.Waveform_Water_Smooth_Check==0
        WAVE=handles.WaveformData(1:WaterWaveNum,:);
        WAVEAXU=handles.WaveformData(1:WaterWaveNum,:);
        WAVEBMO=handles.WaveformBMO_Water;
    else
        WAVE=handles.Waveform_Water_Smooth;
        WAVEAXU=handles.WaveformData(1:WaterWaveNum,:);
        WAVEBMO=handles.WaveformBMO_Water_Smooth;
    end
    
    SECONDREF=zeros(WaterWaveNum,1);
    
    parfor k=1:WaterWaveNum
        
        min_WAVEAXU=min(WAVEAXU(k,:));
        LocalMin=find(WAVEAXU(k,:)<=min_WAVEAXU);
        LocalMin=LocalMin(1);
        LeftEnd=LocalMin;
        
% begin tangent line pretreatment

        SMOOTHWAVE=WAVEAXU(k,:);
        DIFFWAVE=zeros(1,L);
        SMOOTHWAVE(2:L-1)=(SMOOTHWAVE(1:L-2)+SMOOTHWAVE(2:L-1)+SMOOTHWAVE(3:L))./3;
        DIFFWAVE(2:L)=SMOOTHWAVE(2:L)-SMOOTHWAVE(1:L-1);
        DIFFWAVE(1)=DIFFWAVE(2);
        max_DIFFWAVE=max(DIFFWAVE(LeftEnd:L));
        SecondInflation=find(DIFFWAVE(LeftEnd:L)>=max_DIFFWAVE,1,'first')+(LeftEnd-1);
        SecFlat=SecondInflation+(WAVEAXU(k,LeftEnd)-WAVEAXU(k,SecondInflation))/DIFFWAVE(SecondInflation);
        SecFlat=round(SecFlat);
        Y=WAVEAXU(k,LeftEnd:SecFlat);
        X=LeftEnd:SecFlat;
        Cov=cov(X,Y); MeaX=mean(X); MeaY=mean(Y); bR=Cov(1,2)/Cov(1,1); aR=MeaY-bR*MeaX;
        SecRegr=(aR-WAVEAXU(k,SecondInflation)+DIFFWAVE(SecondInflation)*SecondInflation)/(DIFFWAVE(SecondInflation)-bR);
        SecRegr=round(SecRegr);
        RightEnd=min([SecFlat+10,SecRegr+10,SecondInflation,L-3]);
        LeftEnd=max([LeftEnd,SecFlat-10,SecRegr-10]);  
        
% end tangent line pretreatment

% start the second order BMO

        M=max(WAVEBMO(LeftEnd:RightEnd));
        TempPick2=zeros(1,L);
        
        for i=LeftEnd:RightEnd
            if(WAVEBMO(k,i)>=WAVEBMO(k,i+1)...
                    &&WAVEBMO(k,i)>=WAVEBMO(k,i-1)...
                    &&WAVEBMO(k,i)>=WAVEBMO(k,i-2)...
                    &&WAVEBMO(k,i)>=WAVEBMO(k,i+2)...
                    &&WAVEBMO(k,i)>=WAVEBMO(k,i-3)...
                    &&WAVEBMO(k,i)>=WAVEBMO(k,i+3))
                if (WAVEBMO(k,i)>=(1-Sensitivity_Water)*M)
                    TempPick2(i)=1;
                end
            end
        end
        
        % determine the second reflection position
        Indices=find(TempPick2(LeftEnd:L)==1);

        Indices=Indices+(LeftEnd-1);
        LIndices=length(Indices);
        WaveValIndices=[WAVE(k,LeftEnd);WAVE(k,Indices)';WAVE(k,RightEnd)];
        kmid=1;

        XaxisMax=0;

        for i=2:LIndices+1
            if((WaveValIndices(i+1)-WaveValIndices(i))<(WaveValIndices(i)-WaveValIndices(i-1)))
            else
                if(kmid==1)
                    XaxisMax=Indices(i-1);
                    kmid=0;
                end
            end
        end

        if XaxisMax==0
            LL=find(TempPick2==1);
            XaxisMax=min(L-3,LL(1));
        end

        % spline interpolation
        Interval1=(XaxisMax-2):(XaxisMax+2);
        YInterval1=WAVEBMO(k,Interval1);
%        YInterval1=zeros(1,5);
%        for i=1:5
%            YInterval1(i)=WAVEBMO(k,XaxisMax-3+i);
%        end
        PInterval1=(XaxisMax-2):EpsSecond:(XaxisMax+2);
        SplInterval1=spline(Interval1,YInterval1,PInterval1);
        max_SplInterval1=max(SplInterval1);
        LocX1=find(SplInterval1>=max_SplInterval1);
        XaxisMax=XaxisMax-2+(LocX1-1)*EpsSecond;

        % give the first reflection position: -1 because we set first pt as 0
        SECONDREF(k,1)=XaxisMax-1;
        
% end the second order BMO
    end

elseif mode==2
% process for the BTC data

    WaterWaveNum=handles.WaterWaveNum;
    BtcWaveNum=handles.BtcWaveNum;
    DataLength=handles.DataLength;
    Sensitivity_Btc=handles.Sensitivity_Btc;

    if handles.Waveform_Btc_Smooth_Check==0
        WAVE=handles.WaveformData(WaterWaveNum+1:DataLength,:);
        WAVEAXU=handles.WaveformData(WaterWaveNum+1:DataLength,:);
        WAVEBMO=handles.WaveformBMO_Btc;
    else
        WAVE=handles.Waveform_Btc_Smooth;
        WAVEAXU=handles.WaveformData(WaterWaveNum+1:DataLength,:);
        WAVEBMO=handles.WaveformBMO_Btc_Smooth;
    end
    
    SECONDREF=zeros(BtcWaveNum,1);
    
    parfor k=1:BtcWaveNum
        
        min_WAVEAXU=min(WAVEAXU(k,:));
        LocalMin=find(WAVEAXU(k,:)<=min_WAVEAXU);
        LocalMin=LocalMin(1);
        LeftEnd=LocalMin;
        
% begin tangent line pretreatment

        SMOOTHWAVE=WAVEAXU(k,:);
        DIFFWAVE=zeros(1,L);
        SMOOTHWAVE(2:L-1)=(SMOOTHWAVE(1:L-2)+SMOOTHWAVE(2:L-1)+SMOOTHWAVE(3:L))./3;
        DIFFWAVE(2:L)=SMOOTHWAVE(2:L)-SMOOTHWAVE(1:L-1);
        DIFFWAVE(1)=DIFFWAVE(2);
%        for i=2:L-1
%            SMOOTHWAVE(i)=(SMOOTHWAVE(i-1)+SMOOTHWAVE(i)+SMOOTHWAVE(i+1))/3;
%        end
%        for i=2:L
%            DIFFWAVE(i)=SMOOTHWAVE(i)-SMOOTHWAVE(i-1);
%        end
%        DIFFWAVE(1)=DIFFWAVE(2);
        
        max_DIFFWAVE=max(DIFFWAVE(LeftEnd:L));
        SecondInflation=find(DIFFWAVE(LeftEnd:L)>=max_DIFFWAVE,1,'first')+(LeftEnd-1);
        SecFlat=SecondInflation+(WAVEAXU(k,LeftEnd)-WAVEAXU(k,SecondInflation))/DIFFWAVE(SecondInflation);
        SecFlat=round(SecFlat);
        Y=WAVEAXU(k,LeftEnd:SecFlat);
        X=LeftEnd:SecFlat;
        Cov=cov(X,Y); MeaX=mean(X); MeaY=mean(Y); bR=Cov(1,2)/Cov(1,1); aR=MeaY-bR*MeaX;
        SecRegr=(aR-WAVEAXU(k,SecondInflation)+DIFFWAVE(SecondInflation)*SecondInflation)/(DIFFWAVE(SecondInflation)-bR);
        SecRegr=round(SecRegr);
        RightEnd=min([SecFlat+10,SecRegr+10,SecondInflation,L-3]);
        LeftEnd=max([LeftEnd,SecFlat-10,SecRegr-10]);  
        
% end tangent line pretreatment

% start the second order BMO

        M=max(WAVEBMO(LeftEnd:RightEnd));
        TempPick2=zeros(1,L);
        
        for i=LeftEnd:RightEnd
            if(WAVEBMO(k,i)>=WAVEBMO(k,i+1)...
                    &&WAVEBMO(k,i)>=WAVEBMO(k,i-1)...
                    &&WAVEBMO(k,i)>=WAVEBMO(k,i-2)...
                    &&WAVEBMO(k,i)>=WAVEBMO(k,i+2)...
                    &&WAVEBMO(k,i)>=WAVEBMO(k,i-3)...
                    &&WAVEBMO(k,i)>=WAVEBMO(k,i+3))
                if (WAVEBMO(k,i)>=(1-Sensitivity_Btc)*M)
                    TempPick2(i)=1;
                end
            end
        end
        
        % determine the second reflection position
        Indices=find(TempPick2(LeftEnd:L)==1);

        Indices=Indices+(LeftEnd-1);
        LIndices=length(Indices);
        WaveValIndices=[WAVE(k,LeftEnd);WAVE(k,Indices)';WAVE(k,RightEnd)];
%        WaveValIndices=zeros(LIndices+2,1);
%        WaveValIndices(1)=WAVE(k,LeftEnd);
%        WaveValIndices(LIndices+2)=WAVE(k,RightEnd);
%        for i=1:LIndices
%            WaveValIndices(i+1)=WAVE(k,Indices(i));
%        end
        kmid=1;

        XaxisMax=0;

        for i=2:LIndices+1
            if((WaveValIndices(i+1)-WaveValIndices(i))<(WaveValIndices(i)-WaveValIndices(i-1)))
            else
                if(kmid==1)
                    XaxisMax=Indices(i-1);
                    kmid=0;
                end
            end
        end

        if XaxisMax==0
            LL=find(TempPick2==1);
            XaxisMax=min(L-3,LL(1));
        end

        % spline interpolation
        Interval1=(XaxisMax-2):(XaxisMax+2);
        YInterval1=WAVEBMO(k,Interval1);
%        YInterval1=zeros(1,5);
%        for i=1:5
%            YInterval1(i)=WAVEBMO(k,XaxisMax-3+i);
%        end
        PInterval1=(XaxisMax-2):EpsSecond:(XaxisMax+2);
        SplInterval1=spline(Interval1,YInterval1,PInterval1);
        max_SplInterval1=max(SplInterval1);
        LocX1=find(SplInterval1>=max_SplInterval1);
        XaxisMax=XaxisMax-2+(LocX1-1)*EpsSecond;

        % give the first reflection position: -1 because we set first pt as 0
        SECONDREF(k,1)=XaxisMax-1;
        
% end the second order BMO
    end

else   
end

%---------------------------------------
% ToppEq function
% Need //
%---------------------------------------
function y=ToppEq(x)
y=(-0.053)+(0.0292.*x)+(-0.00055.*x.*x)+(0.0000043.*x.*x.*x);


%-----------------------------------------
% fit water waveform near the first jump
%-----------------------------------------

function [L_Node,C_Node,Offset,SolderL,Amplifier]=WaterWaveFit1(handles)

    % need to convert all the unit into SI unit

    WaterNum=handles.WaterWaveNum;
    WaveForm=mean(handles.WaveformData(1:WaterNum,:));
    MinLoc=find(WaveForm<=min(WaveForm)); MinLoc=MinLoc(1);
    FirstRef=mean(handles.WaveformData_Ref1(1:WaterNum,:));
    SecondRef=mean(handles.WaveformData_Ref2(1:WaterNum,:));
    RelaPermit=mean(handles.WaveformData_Prem(1:WaterNum,1));
    EC=mean(handles.WaveformData_EC(1:WaterNum,1));                         % unit in mS dm^-1
    Permit=RelaPermit*handles.RELATIVEPERMITTIVITY_0;
    DataWidth=handles.DataWidth;
    ProbeL=handles.ProbeLength/1000;
    AddL=handles.AdditionalLength;
    AddT=handles.AdditionalTime;
    TimeInterval=handles.TimeInterval;
    CableL=handles.CableLength;
    
    
    L_Cable=handles.CableParL;
    C_Cable=handles.CableParC;
    R_Cable=handles.CableParR;
    G_Cable=handles.CableParG;   
    Rs=handles.ResisSourceAdjusted;
    Vs=handles.InputVoltageFunc;
    dVsdt=handles.InputVoltageFuncDiff;
    
    RCoef0=median(WaveForm(1:ceil(FirstRef)));
% RCoef0 stores the original offset at the y-axis
    WaveForm=WaveForm-RCoef0;
    RCoefN=max(WaveForm(floor(FirstRef):ceil(SecondRef)));
    MaxLoc=find(WaveForm>=RCoefN); MaxLoc=MaxLoc(1); 
% RCoef1=median(WaveForm(floor(FirstRef+5):ceil(SecondRef)));
% RCoef2=mean(WaveForm(min(floor(SecondRef+5),DataWidth-5):DataWidth));

    VeloProbe=ProbeL/((SecondRef-FirstRef)*TimeInterval);   
    Xdomain=AddL+CableL+ProbeL;
    dx=0.005;
    NX=ceil(Xdomain/dx);
    dx=Xdomain/NX;
    dt=dx/handles.LightSpeed/20;
    TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(DataWidth-1)/dt);

    C_Probe=pi*Permit/acosh(handles.PropDist/handles.PropDiam);
    L_Probe=1/VeloProbe/VeloProbe/C_Probe;
    R_Probe=0;
    G_Probe=pi*EC/acosh(handles.PropDist/handles.PropDiam);
    Impendence=sqrt(L_Probe/C_Probe);
    Rl=Impendence*40.0;

    R=R_Probe*ones(NX+1,1);
    L=L_Probe*ones(NX+1,1);
    G=G_Probe*ones(NX+1,1);
    C=C_Probe*ones(NX+1,1);

    for i=1:floor((AddL+CableL)/dx)+1
        R(i)=0;
        G(i)=0;
        L(i)=L_Cable;
        C(i)=C_Cable;
    end

    V=zeros(NX+1,3);

    Matrix_1=zeros(NX+1,3);
    Matrix_2=zeros(NX+1,1);

    WaveSimu=zeros(TotalTimeStep+1,1);

    % Assemble the matrix
       % x=0 source load
       Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
       Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
       % intermediate point
       a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
       b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
       d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
       Matrix_1(2:NX,1)=1./dx./dx./a;
       Matrix_1(2:NX,2)=b./a;
       Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
       Matrix_2(2:NX,1)=d./a;
       % x=NX+1 loading load 
       Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
       Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

    % start the time iteration
    for T=1:floor(TotalTimeStep+1)
        % source input at each time step
        Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)+dVsdt(T*dt-dt)*dt;
        V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
        for n=2:NX
            V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
        end
        V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
        V(:,3)=V(:,2);
        V(:,2)=V(:,1);
        WaveSimu(T,1)=V(1,1);
    end
    WaveFormSimu=WaveSimu;

    FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);    
    BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
    WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
    TimeFrameSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
    WaveFormSimuInterpolate2=interp1(TimeFrameSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:DataWidth-1]);
    
    AmplifierArray=zeros(ceil(SecondRef)-MaxLoc,1);
    for n=MaxLoc:ceil(SecondRef)
        if(WaveFormSimuInterpolate2(n)~=0)
            AmplifierArray(n-MaxLoc+1)=WaveForm(n)/WaveFormSimuInterpolate2(n);
        end
    end
    Amplifier=median(AmplifierArray);
    
    % add the first jump to the curve
    ImpedenceRatio=(1-RCoefN/Amplifier)/(1+RCoefN/Amplifier);
    L_Node=L_Cable;
    C_Node=C_Cable*ImpedenceRatio*ImpedenceRatio;
    MaxIter=101;
    CorrCoefArray=zeros(MaxIter,1);
    for iter=1:MaxIter
          
        Offset=2*(iter-1)*(MaxLoc-FirstRef)/(MaxIter-1);
        % the speed ratio
        
        SolderL=Offset*TimeInterval/sqrt(L_Node*C_Node);
        Xdomain=AddL+CableL+SolderL+ProbeL;
        dx=0.005;
        NX=ceil(Xdomain/dx);
        dx=Xdomain/NX;
        dt=dx/handles.LightSpeed/20;
        TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(handles.DataWidth-1)/dt);

        % the coefficient matrix
        R=R_Probe*ones(NX+1,1);
        L=L_Probe*ones(NX+1,1);
        G=G_Probe*ones(NX+1,1);
        C=C_Probe*ones(NX+1,1);

        for i=1:floor((AddL+CableL)/dx)+1
            R(i)=0;
            G(i)=0;
            L(i)=L_Cable;
            C(i)=C_Cable;
        end
        for i=floor((AddL+CableL)/dx)+2:floor((AddL+CableL+SolderL)/dx)+1
            R(i)=0;
            G(i)=0;
            L(i)=L_Node;
            C(i)=C_Node;
        end

        V=zeros(NX+1,3);
        Matrix_1=zeros(NX+1,3);
        Matrix_2=zeros(NX+1,1);
        
        WaveSimu=zeros(TotalTimeStep+1,1);

        % Assemble the matrix
           % x=0 source load
           Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
           Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
           % intermediate point
           a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
           b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
           d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
           Matrix_1(2:NX,1)=1./dx./dx./a;
           Matrix_1(2:NX,2)=b./a;
           Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
           Matrix_2(2:NX,1)=d./a;
           % x=NX+1 loading load 
           Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
           Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

        % start the time iteration
        for T=1:floor(TotalTimeStep+1)
            % source input at each time step
            Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)+dVsdt(T*dt-dt)*dt;
            V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
            for n=2:NX
                V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
            end
            V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
            V(:,3)=V(:,2);
            V(:,2)=V(:,1);
            WaveSimu(T,1)=V(1,1);
        end
        WaveFormSimu=WaveSimu;

        FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);    
        BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
        WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
        TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
        WaveFormSimuInterpolate2=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:DataWidth-1]);

        CorrCoefMatrix=corrcoef(WaveFormSimuInterpolate2(ceil(FirstRef):MinLoc),WaveForm(ceil(FirstRef):MinLoc));
        CorrCoefArray(iter,1)=CorrCoefMatrix(2);
    
    end
    
    CorrCoefArrayMax=find(CorrCoefArray>=max(CorrCoefArray));CorrCoefArrayMax=CorrCoefArrayMax(1);
    
    
    % output node L C Offset SolderL Amplifer
    Offset=2*(CorrCoefArrayMax-1)*(MaxLoc-FirstRef)/(MaxIter-1);
    IterationMax=1;
    while(IterationMax<=20)
        IterationMax=IterationMax+1;
        SolderL=Offset*TimeInterval/sqrt(L_Node*C_Node);

        Xdomain=AddL+CableL+SolderL+ProbeL;
        dx=0.005;
        NX=ceil(Xdomain/dx);
        dx=Xdomain/NX;
        dt=dx/handles.LightSpeed/20;
        TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(handles.DataWidth-1)/dt);

        % the coefficient matrix
        R=R_Probe*ones(NX+1,1);
        L=L_Probe*ones(NX+1,1);
        G=G_Probe*ones(NX+1,1);
        C=C_Probe*ones(NX+1,1);

        for i=1:floor((AddL+CableL)/dx)+1
            R(i)=0;
            G(i)=0;
            L(i)=L_Cable;
            C(i)=C_Cable;
        end
        for i=floor((AddL+CableL)/dx)+2:floor((AddL+CableL+SolderL)/dx)+1
            R(i)=0;
            G(i)=0;
            L(i)=L_Node;
            C(i)=C_Node;
        end

        V=zeros(NX+1,3);
        Matrix_1=zeros(NX+1,3);
        Matrix_2=zeros(NX+1,1); 
        WaveSimu=zeros(TotalTimeStep+1,1);

        % Assemble the matrix
          % x=0 source load
          Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
          Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
          % intermediate point
          a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
          b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
          d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
          Matrix_1(2:NX,1)=1./dx./dx./a;
          Matrix_1(2:NX,2)=b./a;
          Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
          Matrix_2(2:NX,1)=d./a;
          % x=NX+1 loading load 
          Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
          Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

        % start the time iteration
        for T=1:floor(TotalTimeStep+1)
            % source input at each time step
            Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)+dVsdt(T*dt-dt)*dt;
            V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
            for n=2:NX
                V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
            end
            V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
            V(:,3)=V(:,2);
            V(:,2)=V(:,1);
            WaveSimu(T,1)=V(1,1);
        end
        WaveFormSimu=WaveSimu;
        FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);
        BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
        WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
        TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
        WaveFormSimuInterpolate2=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:DataWidth-1]);


        error=abs(max(WaveFormSimuInterpolate2(floor(FirstRef):ceil(SecondRef)))-RCoefN)/abs(RCoefN);
        if(error>0.01)
            errorsign=sign(max(WaveFormSimuInterpolate2(floor(FirstRef):ceil(SecondRef)))-RCoefN);
            C_Node=C_Node*(1+errorsign*error)*(1+errorsign*error);
        else
            SolderL=Offset*TimeInterval/sqrt(L_Node*C_Node);
            break
        end
    end
    
    
    

%-----------------------------------------
% fit water waveform near the second jump,
% as well as fitting the probe length recursively.
%-----------------------------------------

function [VeloProbe,ProbeLAdjust]=WaterWaveFit2(handles)

    WaterNum=handles.WaterWaveNum;
    WaveForm=mean(handles.WaveformData(1:WaterNum,:));
    MinLoc=find(WaveForm<=min(WaveForm)); MinLoc=MinLoc(1);
    FirstRef=mean(handles.WaveformData_Ref1(1:WaterNum,:));
    SecondRef=mean(handles.WaveformData_Ref2(1:WaterNum,:));
    RelaPermit=mean(handles.WaveformData_Prem(1:WaterNum,1));
    EC=mean(handles.WaveformData_EC(1:WaterNum,1));                         % unit in mS dm^-1
    Permit=RelaPermit*handles.RELATIVEPERMITTIVITY_0;
    DataWidth=handles.DataWidth;
    ProbeL=handles.ProbeLength/1000;
    AddL=handles.AdditionalLength;
    AddT=handles.AdditionalTime;
    TimeInterval=handles.TimeInterval;
    CableL=handles.CableLength;
    
    L_Node=handles.NodeParL;
    C_Node=handles.NodeParC;
    Offset=handles.OffSet;
    SolderL=handles.SolderLength;
    Amplifier=handles.Amplifier;
       
    L_Cable=handles.CableParL;
    C_Cable=handles.CableParC;
    R_Cable=handles.CableParR;
    G_Cable=handles.CableParG;   
    Rs=handles.ResisSourceAdjusted;
    Vs=handles.InputVoltageFunc;
    dVsdt=handles.InputVoltageFuncDiff;
    
    RCoef0=median(WaveForm(1:ceil(FirstRef)));
% RCoef0 stores the original offset at the y-axis
    WaveForm=WaveForm-RCoef0;
    RCoefN=max(WaveForm(floor(FirstRef):ceil(SecondRef)));
    MaxLoc=find(WaveForm>=RCoefN); MaxLoc=MaxLoc(1); 

    VeloProbe=ProbeL/((SecondRef-FirstRef-Offset)*TimeInterval);   
    Xdomain=AddL+CableL+SolderL+ProbeL;
    dx=0.005;
    NX=ceil(Xdomain/dx);
    dx=Xdomain/NX;
    dt=dx/handles.LightSpeed/20;
    TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(DataWidth-1)/dt);
    
    C_Probe=pi*Permit/acosh(handles.PropDist/handles.PropDiam);
    L_Probe=1/VeloProbe/VeloProbe/C_Probe;
    R_Probe=0;
    G_Probe=pi*EC/acosh(handles.PropDist/handles.PropDiam);
    Impendence=sqrt(L_Probe/C_Probe);
    Rl=Impendence*40.0;
    
    % the coefficient matrix
    R=R_Probe*ones(NX+1,1);
    L=L_Probe*ones(NX+1,1);
    G=G_Probe*ones(NX+1,1);
    C=C_Probe*ones(NX+1,1);
    
    for i=1:floor((AddL+CableL)/dx)+1
        R(i)=0;
        G(i)=0;
        L(i)=L_Cable;
        C(i)=C_Cable;
    end
    for i=floor((AddL+CableL)/dx)+2:floor((AddL+CableL+SolderL)/dx)+1
        R(i)=0;
        G(i)=0;
        L(i)=L_Node;
        C(i)=C_Node;
    end

    V=zeros(NX+1,3);
    Matrix_1=zeros(NX+1,3);
    Matrix_2=zeros(NX+1,1);
    WaveSimu=zeros(TotalTimeStep+1,1);

    % Assemble the matrix
       % x=0 source load
       Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
       Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
       % intermediate point
       a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
       b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
       d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
       Matrix_1(2:NX,1)=1./dx./dx./a;
       Matrix_1(2:NX,2)=b./a;
       Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
       Matrix_2(2:NX,1)=d./a;
       % x=NX+1 loading load 
       Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
       Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

    % start the time iteration
    for T=1:floor(TotalTimeStep+1)
        % source input at each time step
        Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)+dVsdt(T*dt-dt)*dt;
        V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
        for n=2:NX
            V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
        end
        V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
        V(:,3)=V(:,2);
        V(:,2)=V(:,1);
        WaveSimu(T,1)=V(1,1);
    end
    WaveFormSimu=WaveSimu;

    FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);    
    BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
    WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
    TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
    TimeframeInterpolate=[0:50:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
    WaveFormSimuInterpolate=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),TimeframeInterpolate);
    WaveFormSimuInterpolate=WaveFormSimuInterpolate*Amplifier;
    
    WaveFormSimuBMO=OneDimensionBMO(OneDimensionBMO(WaveFormSimuInterpolate));
    LocalMin=find(WaveFormSimuInterpolate<=min(WaveFormSimuInterpolate));LocalMin=floor(LocalMin(1)-0.001*(TotalTimeStep-2*AddT));
    WaveFormSimuBMO(1:LocalMin)=0;
    WaveFormSimuBMO=WaveFormSimuBMO.*(WaveFormSimuBMO>=0.8*max(WaveFormSimuBMO));
    for n=LocalMin-1:length(WaveFormSimuInterpolate)-1
        if WaveFormSimuBMO(n)>WaveFormSimuBMO(n-1) && WaveFormSimuBMO(n)>WaveFormSimuBMO(n+1)
            break
        end
    end
    WaveSimuLocalInterpolate=spline(0:4,[WaveFormSimuBMO(n-2),WaveFormSimuBMO(n-1),WaveFormSimuBMO(n),WaveFormSimuBMO(n+1),WaveFormSimuBMO(n+2)],0:0.01:4);
    WaveSimuLocalInterpolateMax=find(WaveSimuLocalInterpolate>=max(WaveSimuLocalInterpolate));WaveSimuLocalInterpolateMax=WaveSimuLocalInterpolateMax(1);
    SecondRefSimu=(WaveSimuLocalInterpolateMax-1)*0.01+n-2;
    SecondRefSimu=SecondRefSimu/(length(WaveFormSimuInterpolate)-1)*(handles.DataWidth-1);
    
    MaxIter=11;
    if(SecondRefSimu>=SecondRef)
% speed is too small
       AccellRattio=(SecondRefSimu-FirstRef-Offset)/(SecondRef-FirstRef-Offset);   
       VeloProbeArray=[1:2*(AccellRattio-1)/(MaxIter-1):(1+2*(AccellRattio-1))].*VeloProbe;
       CorrCoefArray=zeros(MaxIter,1);
    else
% speed is too large
       AccellRattio=(SecondRefSimu-FirstRef-Offset)/(SecondRef-FirstRef-Offset);
       VeloProbeArray=[(1-2*(1-AccellRattio)):2*(1-AccellRattio)/(MaxIter-1):1].*VeloProbe;
       CorrCoefArray=zeros(MaxIter,1); 
    end
    
    for iter=1:MaxIter
         
    % the speed ratio is already done
        
        C_Probe=pi*Permit/acosh(handles.PropDist/handles.PropDiam);
        L_Probe=1/VeloProbeArray(iter)/VeloProbeArray(iter)/C_Probe;
        R_Probe=0;
        G_Probe=pi*EC/acosh(handles.PropDist/handles.PropDiam);
        Impendence=sqrt(L_Probe/C_Probe);
        Rl=Impendence*40.0;

        % the coefficient matrix
        R=R_Probe*ones(NX+1,1);
        L=L_Probe*ones(NX+1,1);
        G=G_Probe*ones(NX+1,1);
        C=C_Probe*ones(NX+1,1);

        for i=1:floor((AddL+CableL)/dx)+1
            R(i)=0;
            G(i)=0;
            L(i)=L_Cable;
            C(i)=C_Cable;
        end
        for i=floor((AddL+CableL)/dx)+2:floor((AddL+CableL+SolderL)/dx)+1
            R(i)=0;
            G(i)=0;
            L(i)=L_Node;
            C(i)=C_Node;
        end

        V=zeros(NX+1,3);
        Matrix_1=zeros(NX+1,3);
        Matrix_2=zeros(NX+1,1);
        
        WaveSimu=zeros(TotalTimeStep+1,1);

        % Assemble the matrix
           % x=0 source load
           Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
           Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
           % intermediate point
           a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
           b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
           d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
           Matrix_1(2:NX,1)=1./dx./dx./a;
           Matrix_1(2:NX,2)=b./a;
           Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
           Matrix_2(2:NX,1)=d./a;
           % x=NX+1 loading load 
           Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
           Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

        % start the time iteration
        for T=1:floor(TotalTimeStep+1)
            % source input at each time step
            Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)+dVsdt(T*dt-dt)*dt;
            V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
            for n=2:NX
                V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
            end
            V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
            V(:,3)=V(:,2);
            V(:,2)=V(:,1);
            WaveSimu(T,1)=V(1,1);
        end
        WaveFormSimu=WaveSimu;

        FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);    
        BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
        WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
        TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
        WaveFormSimuInterpolate2=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),[0:handles.DataWidth-1]);

        CorrCoefMatrix=corrcoef(WaveFormSimuInterpolate2(MinLoc:ceil(SecondRef+5)),WaveForm(MinLoc:ceil(SecondRef+5)));
        CorrCoefArray(iter,1)=CorrCoefMatrix(2);
    
    end
    
    CorrCoefArrayMax=find(CorrCoefArray>=max(CorrCoefArray));CorrCoefArrayMax=CorrCoefArrayMax(1);
    VeloProbe=VeloProbeArray(CorrCoefArrayMax);   
    ProbeLAdjust=(handles.LightSpeed/VeloProbe)/sqrt(80.5)*ProbeL;
    

%-----------------------------------------
% fit water waveform with correct reflection depth
%-----------------------------------------    
function [WaveFormSimuInterpolate,AdjustFactor]=WaterWaveFit3(handles)
        
    WaterNum=handles.WaterWaveNum;
    WaveForm=mean(handles.WaveformData(1:WaterNum,:));
    MinLoc=find(WaveForm<=min(WaveForm)); MinLoc=MinLoc(1);
    FirstRef=mean(handles.WaveformData_Ref1(1:WaterNum,:));
    SecondRef=mean(handles.WaveformData_Ref2(1:WaterNum,:));
    RelaPermit=mean(handles.WaveformData_Prem(1:WaterNum,1));
    DataWidth=handles.DataWidth;
    ProbeLOrg=handles.ProbeLength/1000;
    AddL=handles.AdditionalLength;
    AddT=handles.AdditionalTime;
    TimeInterval=handles.TimeInterval;
    CableL=handles.CableLength;
    
    L_Node=handles.NodeParL;
    C_Node=handles.NodeParC;
    SolderL=handles.SolderLength;
    Amplifier=handles.Amplifier;
       
    L_Cable=handles.CableParL;
    C_Cable=handles.CableParC;
    R_Cable=handles.CableParR;
    G_Cable=handles.CableParG;   
    Rs=handles.ResisSourceAdjusted;
    Vs=handles.InputVoltageFunc;
    dVsdt=handles.InputVoltageFuncDiff;
       
    R_ProbeOrg=handles.ProbeParR;
    L_ProbeOrg=handles.ProbeParL;
    C_ProbeOrg=handles.ProbeParC;
    G_ProbeOrg=handles.ProbeParG;
    Impendence=sqrt(L_ProbeOrg/C_ProbeOrg);
    Rl=Impendence*40.0;
    
    % adjust the amplifier for correct plot
    
    AdjustFactor=Amplifier;
    AdjustFactorOld=AdjustFactor;
    ErrorAdjust=1000;
    iterAdjust=0;
    
    while(iterAdjust<=20&&ErrorAdjust>0.01)
        iterAdjust=iterAdjust+1;
        ProbeL=ProbeLOrg/AdjustFactor;
        Xdomain=AddL+CableL+SolderL+ProbeL;
        dx=0.005;
        NX=ceil(Xdomain/dx);
        dx=Xdomain/NX;
        dt=dx/handles.LightSpeed/20;
        TotalTimeStep=2*AddT+2.*ceil(TimeInterval*(DataWidth-1)/dt);
        L_Probe=L_ProbeOrg*AdjustFactor;
        C_Probe=C_ProbeOrg*AdjustFactor;
        G_Probe=G_ProbeOrg;

        % the coefficient matrix
        R=R_ProbeOrg*ones(NX+1,1);
        L=L_Probe*ones(NX+1,1);
        G=G_Probe*ones(NX+1,1);
        C=C_Probe*ones(NX+1,1);

        for i=1:floor((AddL+CableL)/dx)+1
            R(i)=0;
            G(i)=0;
            L(i)=L_Cable;
            C(i)=C_Cable;
        end
        for i=floor((AddL+CableL)/dx)+2:floor((AddL+CableL+SolderL)/dx)+1
            R(i)=0;
            G(i)=0;
            L(i)=L_Node;
            C(i)=C_Node;
        end

        V=zeros(NX+1,3);
        Matrix_1=zeros(NX+1,3);
        Matrix_2=zeros(NX+1,1);

        WaveSimu=zeros(TotalTimeStep+1,1);

        % Assemble the matrix
        % x=0 source load
        Matrix_1(1,2)=1-Rs/L(1,1)/dx*dt-R(1,1)/L(1,1)*dt;
        Matrix_1(1,3)=Rs/L(1,1)/dx*dt;
        % intermediate point
        a=(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt+L(2:NX,1).*C(2:NX,1)./dt./dt;
        b=-2./dx./dx-R(2:NX,1).*G(2:NX,1)+2.*L(2:NX,1).*C(2:NX,1)./dt./dt+(R(2:NX,1).*C(2:NX,1)+L(2:NX,1).*G(2:NX,1))./dt;
        d=-L(2:NX,1).*C(2:NX,1)./dt./dt;
        Matrix_1(2:NX,1)=1./dx./dx./a;
        Matrix_1(2:NX,2)=b./a;
        Matrix_1(2:NX,3)=Matrix_1(2:NX,1);
        Matrix_2(2:NX,1)=d./a;
        % x=NX+1 loading load 
        Matrix_1(NX+1,1)=dt*Rl/L(NX+1,1)/dx;
        Matrix_1(NX+1,2)=1-dt*Rl/L(NX+1,1)/dx-R(NX+1,1)*dt/L(NX+1,1);

        % start the time iteration
        for T=1:floor(TotalTimeStep+1)
            % source input at each time step
            Matrix_3=R(1,1)/L(1,1)*dt*Vs(T*dt-dt)+dVsdt(T*dt-dt)*dt;
            V(1,1)=Matrix_1(1,2)*V(1,2)+Matrix_1(1,3)*V(2,2)+Matrix_3;
            for n=2:NX
                V(n,1)=Matrix_1(n,1)*V(n-1,2)+Matrix_1(n,2)*V(n,2)+Matrix_1(n,3)*V(n+1,2)+Matrix_2(n,1)*V(n,3);
            end
            V(NX+1,1)=Matrix_1(NX+1,1)*V(NX,2)+Matrix_1(NX+1,2)*V(NX+1,2);
            V(:,3)=V(:,2);
            V(:,2)=V(:,1);
            WaveSimu(T,1)=V(1,1);
        end
        WaveFormSimu=WaveSimu;

        FirstRefNode=2*AddT+2*floor(FirstRef*TimeInterval/dt);    
        BasedValue=median(WaveFormSimu(2*AddT:FirstRefNode));
        WaveFormSimu=(WaveFormSimu-BasedValue)/BasedValue;
        TimeframeSimu=[0:TotalTimeStep-2*AddT]'.*dt/TimeInterval./2;
        X=0:250;
        WaveFormSimuInterpolate=interp1(TimeframeSimu,WaveFormSimu(2*AddT:TotalTimeStep),X);
        AdjustFactorOld=AdjustFactor;
        AdjustFactor=AdjustFactor*median(WaveForm(ceil(FirstRef):floor(SecondRef))./WaveFormSimuInterpolate(ceil(FirstRef):floor(SecondRef)));
        ErrorAdjust=abs(AdjustFactor-AdjustFactorOld)/abs(AdjustFactor);
    end


% --- Executes during object creation, after setting all properties.
function text7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes during object creation, after setting all properties.
function text6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
